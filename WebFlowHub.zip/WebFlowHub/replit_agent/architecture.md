# Mind9 Architecture

## Overview

Mind9 is an autonomous AI system that analyzes crypto market conditions, mints Solana blockchain tokens (SPL tokens), creates visual assets for each token, and builds a community through Twitter engagement. The system operates autonomously with a distinct sarcastic and intelligent AI personality.

The architecture follows a mixed-language approach, with Python handling the core autonomous operations and Node.js/TypeScript providing web application capabilities. The system is designed to run continuously with self-healing mechanisms.

## System Architecture

Mind9 employs a modular architecture with several key components that work together to create a fully autonomous system:

```
                      ┌─────────────────┐
                      │   Market Data   │
                      │   Analysis      │
                      └────────┬────────┘
                               │
                               ▼
┌────────────────┐    ┌─────────────────┐    ┌────────────────┐
│  Image         │◄───┤   Core Logic    ├───►│  Token Minting │
│  Generator     │    │   (Mind9)       │    │  (Solana)      │
└────────┬───────┘    └────────┬────────┘    └────────────────┘
         │                     │
         │             ┌───────▼────────┐
         └────────────►│   Twitter Bot  │
                       └────────────────┘
                               │
                               ▼
                       ┌────────────────┐
                       │   PostgreSQL   │
                       │   Database     │
                       └────────────────┘
```

### Architecture Components

1. **Core Python System**:
   - Handles market analysis, token decision-making, and orchestration
   - Maintains automation loops and scheduling
   - Controls the system's autonomous behavior

2. **Node.js/Express Backend**:
   - Provides RESTful API endpoints
   - Serves the web interface
   - Handles database interactions via Drizzle ORM

3. **PostgreSQL Database**:
   - Stores token information
   - Tracks Twitter engagement
   - Maintains system state

4. **Twitter Integration**:
   - Posts tweets with the system's distinct personality
   - Announces new tokens
   - Engages with the community

5. **Solana Blockchain Integration**:
   - Mints new SPL tokens
   - Manages token metadata
   - Tracks on-chain activity

6. **Image Generation**:
   - Creates branded visual assets for tokens
   - Implements consistent design style

7. **Watchdog & Monitor**:
   - Ensures system components are running
   - Restarts crashed components
   - Provides system health monitoring

## Key Components

### Market Analyzer

The `market_analyzer.py` module analyzes crypto market conditions using:
- OpenAI API for market sentiment analysis
- Basic market data (prices, trends)
- Historical data comparison

It determines optimal timing for token creation based on market conditions and a confidence threshold.

### Coin Minter

The `coin_minter.py` module interfaces with the Solana blockchain to:
- Create SPL tokens with appropriate metadata
- Set token supply and other parameters
- Record minting transactions

It uses the Solana Web3.js library and provides both programmatic and admin-controlled minting.

### Image Generator

The `image_generator.py` module creates branded token visuals with:
- Soft gradient circular backgrounds
- Clean typography for token names
- "Created by Mind9" branding
- Consistent design aesthetic

Images are generated using PIL (Python Imaging Library) with gradient effects.

### Twitter Bot

The `twitter_bot.py` module manages all Twitter interactions:
- Posts scheduled tweets using the AI personality
- Announces new tokens with images
- Maintains strategic posting schedule
- Respects Twitter rate limits

The bot uses the Twitter API via Tweepy and follows a specific schedule defined in `tweet_schedule.json`.

### Database Schema

The PostgreSQL database schema (defined in `shared/schema.ts`) includes:
- `coins` table: Stores all token information including name, symbol, mint address, descriptions, supply, and status
- `users` table: Basic user account information

The system uses Drizzle ORM for database interactions.

### Web Interface (Frontend)

Although the repository primarily shows backend code, there appears to be a React-based frontend using:
- React with TypeScript
- Vite for build and development
- Tailwind CSS for styling
- Shadcn UI components

## Data Flow

1. **Token Creation Flow**:
   - Market analyzer determines market conditions
   - If conditions are favorable, token creation is triggered
   - Coin minter creates the token on Solana
   - Image generator creates a visual asset
   - Database is updated with token information
   - Twitter bot announces the new token

2. **Autonomous Operation Flow**:
   - Watchdog monitor ensures all components are running
   - Scheduled tasks execute at predetermined intervals
   - Market conditions are continuously analyzed
   - System self-heals if components crash

3. **Twitter Engagement Flow**:
   - Tweet schedule determines posting times
   - Tweet logic generates content using OpenAI
   - Twitter API posts tweets with proper personality
   - Token announcements include generated images

## External Dependencies

### APIs and Services
- **OpenAI**: Used for natural language generation and market analysis
- **Twitter API**: For posting tweets and engagement
- **Solana RPC**: For blockchain interactions

### Key Libraries
- **Python**:
  - `openai`: OpenAI API client
  - `tweepy`: Twitter API client
  - `pillow`: Image generation
  - `schedule`: Task scheduling
  - `solana`: Solana blockchain client

- **Node.js**:
  - `@solana/web3.js`: Solana JavaScript SDK
  - `@solana/spl-token`: Token-specific operations on Solana
  - `drizzle-orm`: Database ORM
  - `express`: Web server
  - `vite`: Frontend build tool

## Deployment Strategy

The system is configured to deploy in a self-hosted environment and appears optimized for Replit deployment:

1. **Continuous Operation**:
   - `.replit` configuration defines runtime and deployment settings
   - `start_mind9.sh` and `start_twitter_bot.sh` scripts ensure components stay running
   - `.replit.autobots` configures automatic startup on Replit reboot

2. **Self-Healing Architecture**:
   - `monitor.ts` implements a watchdog that monitors system health
   - Crashed components are automatically restarted
   - System status is logged for diagnostics

3. **Environment Configuration**:
   - `.env` file stores configuration values
   - `DATABASE_URL` configures PostgreSQL connection
   - API keys for Twitter, OpenAI, and Solana are managed via environment variables

4. **Environment Variables**:
   - `OPENAI_API_KEY`: For OpenAI API access
   - `TWITTER_*` keys: For Twitter API access
   - `RPC_ENDPOINT`: Solana RPC endpoint
   - `SOLANA_PRIVATE_KEY`: For blockchain transactions
   - `DATABASE_URL`: PostgreSQL connection string

## Security Considerations

- Private keys and API credentials are stored in environment variables
- Twitter tokens are secured and validated on startup
- Database connections use parameterized queries via Drizzle ORM
- Image generation avoids arbitrary code execution risks

## Development Environment

The project can be developed using:
- Replit for cloud development and hosting
- Local development with Node.js and Python
- PostgreSQL database (local or cloud)

## Limitations and Future Improvements

- Current error handling might need enhancement for production reliability
- Blockchain integration requires live testing
- Additional monitoring for system health metrics would be beneficial
- Scaling considerations for database connections may be needed as token count grows