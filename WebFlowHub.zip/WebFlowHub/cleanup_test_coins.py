#!/usr/bin/env python3
"""
Cleanup Test Coins Script for Mind9

This script automatically deletes test coins in the database when deployed to production.
It will only run once during the first deployment and sets a flag to avoid running again.
"""

import os
import sys
import json
import logging
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("cleanup_test_coins.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("mind9_cleanup")

# Load environment variables
load_dotenv()

# Global flag file to track if we've already run this cleanup
CLEANUP_FLAG_FILE = "cleanup_completed.json"

def cleanup_already_run():
    """Check if the cleanup has already run"""
    if os.path.exists(CLEANUP_FLAG_FILE):
        try:
            with open(CLEANUP_FLAG_FILE, 'r') as f:
                flag_data = json.load(f)
                return flag_data.get('cleanup_completed', False)
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error reading cleanup flag file: {e}")
    return False

def mark_cleanup_complete():
    """Mark that cleanup has been completed"""
    try:
        with open(CLEANUP_FLAG_FILE, 'w') as f:
            json.dump({'cleanup_completed': True}, f)
        logger.info("Cleanup marked as completed")
    except IOError as e:
        logger.error(f"Error writing cleanup flag file: {e}")

def connect_to_db():
    """Connect to the PostgreSQL database"""
    try:
        # Connect to the PostgreSQL database
        conn = psycopg2.connect(os.environ.get('DATABASE_URL'))
        logger.info("Connected to PostgreSQL database")
        return conn
    except Exception as e:
        logger.error(f"Database connection error: {e}")
        return None

def cleanup_test_coins():
    """Delete test coins from the database"""
    if cleanup_already_run():
        logger.info("Cleanup has already run, skipping.")
        return
    
    conn = connect_to_db()
    if not conn:
        logger.error("Failed to connect to database, cannot clean up test coins")
        return
    
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            # First, check if we have any test coins - use a more comprehensive search pattern
            cur.execute("""
                SELECT COUNT(*) as count FROM coins 
                WHERE symbol = 'TEST' OR symbol LIKE 'TEST%' 
                OR name LIKE '%Test%' OR name LIKE '%test%' 
                OR description LIKE '%test%' OR description LIKE '%Test%'
                OR mint_address = 'SIMULATION'
            """)
            result = cur.fetchone()
            test_coin_count = result['count'] if result else 0
            
            logger.info(f"Found {test_coin_count} test coins to remove")
            
            if test_coin_count == 0:
                logger.info("No test coins found, nothing to clean up")
                mark_cleanup_complete()
                return
                
            # Delete all test coins with expanded criteria
            cur.execute("""
                DELETE FROM coins 
                WHERE symbol = 'TEST' OR symbol LIKE 'TEST%' 
                OR name LIKE '%Test%' OR name LIKE '%test%' 
                OR description LIKE '%test%' OR description LIKE '%Test%'
                OR mint_address = 'SIMULATION'
            """)
            deleted_count = cur.rowcount
            
            # Commit the transaction
            conn.commit()
            
            logger.info(f"Successfully deleted {deleted_count} test coins")
            
            # Reset the auto-increment sequence if needed
            try:
                cur.execute("SELECT setval('coins_id_seq', 1, false)")
                conn.commit()
                logger.info("Reset ID sequence to start from 1")
            except Exception as e:
                logger.warning(f"Could not reset ID sequence: {e}")
            
            # Mark as completed
            mark_cleanup_complete()
            
    except Exception as e:
        logger.error(f"Error cleaning up test coins: {e}")
        conn.rollback()
    finally:
        conn.close()

def main():
    """Main entry point for the script"""
    logger.info("Starting Mind9 test coin cleanup script")
    
    # Only run in production mode
    if os.environ.get('NODE_ENV') == 'production' or '--force' in sys.argv:
        cleanup_test_coins()
    else:
        logger.info("Not running in production mode, skipping cleanup")
    
    logger.info("Cleanup script completed")

if __name__ == "__main__":
    main()