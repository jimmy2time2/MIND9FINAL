#!/bin/bash

# Script to properly restart the Twitter bot
# This script:
# 1. Stops any existing Twitter bot processes
# 2. Cleans up any zombie processes
# 3. Starts a fresh Twitter bot instance

echo "==========================================="
echo "     Mind9 Twitter Bot Restart"
echo "==========================================="

# Stop any existing Twitter bot process
echo "Stopping any running Twitter bot processes..."
pkill -f "python.*twitter_bot.py" || true
pkill -f "python.*run_twitter_bot.py" || true

# Wait a moment for processes to terminate
echo "Waiting for processes to terminate..."
sleep 3

# Make sure the flag file exists
touch .twitter_bot_running

# Start the Twitter bot in a way that will persist after terminal closes
echo "Starting new Twitter bot instance..."
nohup python run_twitter_bot.py > twitter_bot_output.log 2>&1 &

# Get and display the PID
TWITTER_BOT_PID=$!
echo "Twitter bot started with PID: $TWITTER_BOT_PID"

# Verify it's running
sleep 3
if ps -p $TWITTER_BOT_PID > /dev/null; then
    echo "Twitter bot is running successfully!"
else
    echo "Error: Twitter bot failed to start properly."
    echo "Check twitter_bot_output.log for details."
fi

echo ""
echo "Twitter bot restarted successfully. It will continue running"
echo "even after you close the terminal."
echo ""
echo "To monitor logs: tail -f twitter_bot_output.log"
echo "To check status: ./check_twitter_bot.sh"