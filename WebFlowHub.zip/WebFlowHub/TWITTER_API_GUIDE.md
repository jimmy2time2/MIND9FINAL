# Mind9 Twitter API Integration Guide

This guide explains how the Twitter API integration works in the Mind9 platform and how to troubleshoot common issues.

## Architecture Overview

The Mind9 Twitter integration consists of:

1. **Twitter API Module**: Handles direct API communications with Twitter
2. **Twitter Bot**: Autonomous agent that posts tweets on a schedule and announces new coins
3. **Admin API Endpoints**: For testing and managing Twitter functionality

## Required Credentials

Mind9 requires the following Twitter API credentials:

- `TWITTER_API_KEY` - API Key (Consumer Key) from Twitter Developer Portal
- `TWITTER_API_KEY_SECRET` - API Secret (Consumer Secret) from Twitter Developer Portal
- `TWITTER_ACCESS_TOKEN` - OAuth 1.0a User Access Token from Twitter Developer Portal
- `TWITTER_ACCESS_TOKEN_SECRET` - OAuth 1.0a User Access Token Secret
- `TWITTER_BEARER_TOKEN` - Optional: Bearer token for v2 endpoints if used

These values must be added to the `.env` file or environment variables.

## Required Permissions

The Twitter application must have the following permissions:

- **Read and Write** - Required for posting tweets and reading responses
- **Direct Messages** - Optional but recommended for full functionality

## Validation and Testing

### Automated Validation

Mind9 automatically validates Twitter credentials on startup and provides diagnostic endpoints:

- `GET /api/admin/twitter/diagnose` - Returns detailed diagnostic information
- `POST /api/admin/test-twitter` - Sends a test tweet
- `POST /api/admin/twitter-bot/test` - Tests the Twitter bot with a fully autonomous tweet

### Manual Testing

For manual testing, use the included test script:

```bash
node test_twitter_credentials.mjs
```

This script validates:
- Credential format
- Authentication
- Read permissions
- Write permissions

## Common Issues and Solutions

### Authentication Errors (401)

If you receive 401 errors:

1. Verify all four credentials match and are from the same Twitter app
2. Ensure you're using OAuth 1.0a tokens (not OAuth 2.0)
3. Regenerate all four credentials together
4. Verify the system time is accurate (Twitter is sensitive to time drift)

### Permission Errors (403)

If you receive 403 errors:

1. Verify your Twitter app has "Read and Write" permissions
2. After changing permissions in the Developer Portal, regenerate your Access Token
3. Check that your Developer Account has been approved for the necessary access levels

### Rate Limiting (429)

Mind9 implements rate limit handling with exponential backoff. If you encounter persistent rate limit issues:

1. Reduce the frequency of scheduled tweets
2. Ensure you're not exceeding 200 tweets per day
3. Check the Twitter bot's default schedule configuration

## Restarting/Reloading

If you update Twitter credentials, you can reload them without restarting the server:

```bash
curl -X POST http://localhost:5000/api/admin/twitter/reload-credentials
```

## Security Considerations

- Never expose Twitter credentials in client-side code
- All Twitter operations should run server-side only
- The Twitter bot operates with write permissions - ensure proper access controls

## Testing Before Deployment

Before deploying changes to the Twitter integration:

1. Validate credentials with `test_twitter_credentials.mjs`
2. Verify tweet posting with the test endpoint
3. Confirm the Twitter bot can execute scheduled tweets
4. Check coin announcement functionality with a test coin

## Support

For issues with the Twitter API integration, refer to:

- `TWITTER_TROUBLESHOOTING.md` - For detailed troubleshooting instructions
- Twitter Developer Documentation: https://developer.twitter.com/en/docs