/**
 * Coin Recovery Script for Mind9
 * 
 * This script scans the Solana blockchain for tokens owned by the creator wallet
 * and adds them to the database if they don't already exist.
 */

import { Connection, PublicKey } from '@solana/web3.js';
import { getAccount, TOKEN_PROGRAM_ID } from '@solana/spl-token';
import { db } from './server/db';
import { coins } from './shared/schema';
import { eq } from 'drizzle-orm';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Configuration
const RPC_ENDPOINT = process.env.RPC_ENDPOINT;
const CREATOR_WALLET = process.env.CREATOR_WALLET_ADDRESS;

if (!RPC_ENDPOINT || !CREATOR_WALLET) {
  console.error('Missing required environment variables: RPC_ENDPOINT, CREATOR_WALLET_ADDRESS');
  process.exit(1);
}

async function recoverCoins() {
  console.log('=================================================');
  console.log('  Mind9 Coin Recovery Tool');
  console.log('=================================================');
  console.log('This tool will scan the blockchain for tokens minted by');
  console.log('your wallet and add them to the database.\n');
  
  try {
    console.log(`Using RPC endpoint: ${RPC_ENDPOINT}`);
    console.log(`Scanning wallet: ${CREATOR_WALLET}\n`);
    
    // Connect to Solana
    const connection = new Connection(RPC_ENDPOINT, 'confirmed');
    const creatorWalletPublicKey = new PublicKey(CREATOR_WALLET);
    
    // Get all token accounts owned by the creator wallet
    console.log('Fetching token accounts from blockchain...');
    const tokenAccounts = await connection.getParsedTokenAccountsByOwner(
      creatorWalletPublicKey,
      { programId: TOKEN_PROGRAM_ID }
    );
    
    console.log(`Found ${tokenAccounts.value.length} token accounts.\n`);
    
    // Get all coins in database for comparison
    const existingCoins = await db.select().from(coins);
    const existingMintAddresses = new Set(existingCoins.map(coin => coin.mint_address));
    
    console.log(`Database has ${existingCoins.length} coins recorded.`);
    
    // Process each token account
    let addedCount = 0;
    let alreadyExistsCount = 0;
    let skipCount = 0;
    
    for (const account of tokenAccounts.value) {
      const parsedInfo = account.account.data.parsed.info;
      const mintAddress = parsedInfo.mint;
      const balance = parsedInfo.tokenAmount.uiAmount;
      
      // Skip tokens with zero balance
      if (balance === 0) {
        skipCount++;
        continue;
      }
      
      // Check if token already exists in database
      if (existingMintAddresses.has(mintAddress)) {
        console.log(`✓ Token ${mintAddress.slice(0, 6)}...${mintAddress.slice(-4)} already in database`);
        alreadyExistsCount++;
        continue;
      }
      
      // Get token information from blockchain (simplified, in production you'd use Metaplex)
      console.log(`Adding token ${mintAddress.slice(0, 6)}...${mintAddress.slice(-4)} to database...`);
      
      try {
        // Generate placeholder name and symbol
        const name = `Recovered Token ${mintAddress.slice(0, 6)}`;
        const symbol = `RT${mintAddress.slice(0, 3)}`;
        const primaryColor = "#FF7D45"; // Default color
        
        // Insert the token into the database
        await db.insert(coins).values({
          name,
          symbol,
          mint_address: mintAddress,
          description: `Recovered token from Solana blockchain`,
          tagline: `Autonomous token created by Mind9`,
          total_supply: balance.toString(),
          tokenomics: "70% Locked LP, 20% Trading Fund, 5% Creator Wallet, 3% Lucky Trader, 2% System Operations",
          liquidity_amount: (balance * 0.7).toString(),
          liquidity_sol: "0.01",
          minted: true,
          minted_at: new Date(),
          user_mintable: true,
          user_mintable_at: new Date(),
          primary_color: primaryColor
        });
        
        console.log(`✅ Successfully added token ${mintAddress} to database`);
        addedCount++;
      } catch (error) {
        console.error(`Error adding token ${mintAddress} to database:`, error);
      }
    }
    
    console.log('\n=================================================');
    console.log('  Recovery Summary');
    console.log('=================================================');
    console.log(`Total token accounts scanned: ${tokenAccounts.value.length}`);
    console.log(`Skipped zero balance tokens: ${skipCount}`);
    console.log(`Tokens already in database: ${alreadyExistsCount}`);
    console.log(`Tokens added to database: ${addedCount}`);
    console.log(`Total tokens in database now: ${existingCoins.length + addedCount}`);
    console.log('\nRecovery process complete!');
    console.log('Refresh your website to see the recovered tokens.');
    
  } catch (error) {
    console.error('Error during coin recovery:', error);
  }
}

// Run the recovery function
recoverCoins().then(() => {
  console.log('Script finished, exiting');
  process.exit(0);
}).catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});