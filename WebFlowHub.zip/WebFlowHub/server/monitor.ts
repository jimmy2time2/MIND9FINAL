/**
 * System Monitor and Watchdog Process
 * 
 * This script ensures the entire Mind9 system runs continuously by:
 * 1. Periodically checking if Twitter bot and main system are running
 * 2. Restarting any components that have crashed
 * 3. Creating a self-healing ecosystem that operates without human intervention
 * 
 * Designed to be started with the Express server and maintain system integrity
 */

import { exec } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import { log } from './vite';

// Configuration
const CHECK_INTERVAL = 10 * 60 * 1000; // 10 minutes
const LOG_FILE = path.join(process.cwd(), 'watchdog.log');
const LAST_RUN_FILE = path.join(process.cwd(), '.last_watchdog_run');
const MAX_LOG_SIZE = 10 * 1024 * 1024; // 10MB

// Startup flags
let isFirstRun = true;
let systemStarted = false;
let monitorRunning = false;

/**
 * Append a message to the watchdog log
 */
function appendToLog(message: string): void {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] ${message}\n`;
  
  // Get current log size
  let logSize = 0;
  try {
    if (fs.existsSync(LOG_FILE)) {
      const stats = fs.statSync(LOG_FILE);
      logSize = stats.size;
    }
  } catch (error: unknown) {
    // If we can't check size, proceed anyway
  }
  
  // Rotate log if too large
  if (logSize > MAX_LOG_SIZE) {
    try {
      const backupLog = `${LOG_FILE}.old`;
      if (fs.existsSync(backupLog)) {
        fs.unlinkSync(backupLog);
      }
      fs.renameSync(LOG_FILE, backupLog);
    } catch (error) {
      // If rename fails, truncate the file
      fs.writeFileSync(LOG_FILE, '');
    }
  }
  
  // Append to log
  try {
    fs.appendFileSync(LOG_FILE, logMessage);
  } catch (error) {
    // Silent failure for logging is acceptable
  }
}

/**
 * Check if a process is running by its name/command
 */
async function isProcessRunning(processName: string): Promise<boolean> {
  return new Promise((resolve) => {
    exec('ps aux', (error, stdout) => {
      if (error) {
        appendToLog(`Error checking for process ${processName}: ${error.message}`);
        resolve(false);
        return;
      }
      
      const isRunning = stdout.toLowerCase().includes(processName.toLowerCase());
      resolve(isRunning);
    });
  });
}

/**
 * Update the last run timestamp file
 */
function updateLastRunTimestamp(): void {
  try {
    fs.writeFileSync(LAST_RUN_FILE, new Date().toISOString());
  } catch (error) {
    appendToLog(`Error updating last run timestamp: ${error.message}`);
  }
}

/**
 * Check if the watchdog has been running recently
 */
function hasRunRecently(): boolean {
  try {
    if (!fs.existsSync(LAST_RUN_FILE)) {
      return false;
    }
    
    const lastRunStr = fs.readFileSync(LAST_RUN_FILE, 'utf8');
    const lastRun = new Date(lastRunStr);
    const now = new Date();
    
    // Check if last run was less than 20 minutes ago
    const timeDiff = now.getTime() - lastRun.getTime();
    return timeDiff < 20 * 60 * 1000;
  } catch (error) {
    appendToLog(`Error checking last run: ${error.message}`);
    return false;
  }
}

/**
 * Execute a command and log the output
 */
async function executeCommand(command: string, description: string): Promise<boolean> {
  return new Promise((resolve) => {
    appendToLog(`Executing: ${description}`);
    
    exec(command, (error, stdout, stderr) => {
      if (error) {
        appendToLog(`Error executing ${description}: ${error.message}`);
        resolve(false);
        return;
      }
      
      if (stderr && stderr.length > 0) {
        appendToLog(`${description} stderr: ${stderr}`);
      }
      
      if (stdout && stdout.length > 0) {
        // Only log first 200 chars of stdout to avoid huge logs
        const truncatedOutput = stdout.length > 200 
          ? `${stdout.substring(0, 200)}...` 
          : stdout;
        appendToLog(`${description} output: ${truncatedOutput}`);
      }
      
      appendToLog(`${description} completed successfully`);
      resolve(true);
    });
  });
}

/**
 * Start the Twitter bot if it's not running
 */
async function ensureTwitterBotRunning(): Promise<void> {
  const isRunning = await isProcessRunning('run_twitter_bot.py');
  
  if (!isRunning) {
    appendToLog('Twitter bot is not running, starting it...');
    
    // Make sure the script is executable
    await executeCommand('chmod +x ./start_twitter_bot.sh', 'Make Twitter bot script executable');
    
    // Start the Twitter bot
    const success = await executeCommand('./start_twitter_bot.sh', 'Start Twitter bot');
    
    if (success) {
      appendToLog('Twitter bot started successfully');
    } else {
      appendToLog('Failed to start Twitter bot');
    }
  } else {
    appendToLog('Twitter bot is already running');
  }
}

/**
 * Start the Mind9 system if it's not running
 */
async function ensureMind9Running(): Promise<void> {
  const isRunning = await isProcessRunning('main.py');
  
  if (!isRunning) {
    appendToLog('Mind9 system is not running, starting it...');
    
    // Make sure the script is executable
    await executeCommand('chmod +x ./start_mind9.sh', 'Make Mind9 script executable');
    
    // Start Mind9 in the background
    const success = await executeCommand('nohup ./start_mind9.sh > mind9_startup.log 2>&1 &', 'Start Mind9 system');
    
    if (success) {
      appendToLog('Mind9 system started successfully');
    } else {
      appendToLog('Failed to start Mind9 system');
    }
  } else {
    appendToLog('Mind9 system is already running');
  }
}

/**
 * Main monitoring function that runs on an interval
 */
async function monitorSystems(): Promise<void> {
  // Don't run multiple instances simultaneously
  if (monitorRunning) {
    return;
  }
  
  monitorRunning = true;
  
  try {
    // Log the start of monitoring
    if (isFirstRun) {
      appendToLog('====== SYSTEM MONITOR STARTING ======');
      appendToLog(`Node.js version: ${process.version}`);
      appendToLog(`Environment: ${process.env.NODE_ENV || 'development'}`);
      isFirstRun = false;
    } else {
      appendToLog('====== SYSTEM MONITOR CHECK ======');
    }
    
    // Update the last run timestamp
    updateLastRunTimestamp();
    
    // Check and start Twitter bot if needed
    await ensureTwitterBotRunning();
    
    // Check and start Mind9 system if needed
    await ensureMind9Running();
    
    // Mark system as started after first successful check
    if (!systemStarted) {
      systemStarted = true;
      log('Mind9 autonomous system monitoring initialized');
    }
    
    appendToLog('System monitor check completed');
  } catch (error: unknown) {
    const errorMsg = error instanceof Error ? error.message : 'Unknown error';
    appendToLog(`Error in system monitor: ${errorMsg}`);
  } finally {
    monitorRunning = false;
  }
}

/**
 * Start the monitoring system
 */
export async function startMonitor(): Promise<void> {
  // Check if another instance is already running
  if (hasRunRecently()) {
    appendToLog('Another monitor instance appears to be running, skipping startup');
    return;
  }
  
  appendToLog('Starting system monitor...');
  
  // Run immediately on startup
  await monitorSystems();
  
  // Then set up interval
  setInterval(monitorSystems, CHECK_INTERVAL);
  
  appendToLog(`System monitor started, checking every ${CHECK_INTERVAL / 60000} minutes`);
}

// Handle process termination
process.on('SIGINT', () => {
  appendToLog('System monitor shutting down due to SIGINT');
  process.exit(0);
});

process.on('SIGTERM', () => {
  appendToLog('System monitor shutting down due to SIGTERM');
  process.exit(0);
});