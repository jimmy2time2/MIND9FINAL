/**
 * Image utilities for handling coin image paths
 */

/**
 * Transforms the stored database image path to a proper URL path that can be used by the frontend
 * 
 * @param imagePath The raw image path from the database
 * @returns A proper URL path that can be used by the frontend
 */
export function transformImagePath(imagePath: string | null): string | null {
  console.log(`Transforming image path: ${imagePath}`);
  
  if (!imagePath) {
    return null;
  }
  
  // Check if it's already a proper URL
  if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
    console.log(`Already a URL: ${imagePath}`);
    return imagePath;
  }
  
  // Check if it's in the public directory
  if (imagePath.startsWith('/public/') || imagePath.startsWith('public/')) {
    const result = imagePath.replace(/^\/public\/|^public\//, '/public/');
    console.log(`Public dir transform: ${result}`);
    return result;
  }
  
  // Handle paths in specific generated_images directory
  if (imagePath.includes('generated_images/')) {
    // Extract just the filename from the path
    const filename = imagePath.split('/').pop();
    if (filename) {
      const result = `/img/coins/${filename}`;
      console.log(`Generated images transform: ${result}`);
      return result;
    }
  }
  
  // Default behavior for other paths
  const result = `/img/coins/${imagePath.split('/').pop()}`;
  console.log(`Default transform: ${result}`);
  return result;
}