// Market data utilities for Twitter bot and token generation
import OpenAI from 'openai';
import axios from 'axios';

// Configure OpenAI for market analysis
// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Cache market data to reduce API calls
let cachedMarketData: any = null;
let lastFetchTime = 0;
const CACHE_DURATION = 30 * 60 * 1000; // 30 minutes

// Get current market trends for Twitter content generation
export async function getMarketTrends(): Promise<{
  solPrice: string,
  solChange: number,
  btcPrice: string,
  btcChange: number,
  sentiment: string,
  networkHealth: number,
  volatility: number
}> {
  try {
    // Check cache first
    const now = Date.now();
    if (cachedMarketData && (now - lastFetchTime < CACHE_DURATION)) {
      return cachedMarketData;
    }

    // In production, this would fetch real data from CoinGecko or other APIs
    // For now, simulate data for development purposes with some randomization for variety
    
    // Simulated SOL price (with minor variations)
    const baseSOLPrice = 154.87;
    const solVariation = (Math.random() * 8) - 4; // -4 to +4
    const solPrice = (baseSOLPrice + solVariation).toFixed(2);
    
    // Simulated SOL 24h change
    const solChange = (Math.random() * 14) - 7; // -7% to +7%
    
    // Simulated BTC price
    const baseBTCPrice = 63250;
    const btcVariation = (Math.random() * 1200) - 600; // -600 to +600
    const btcPrice = (baseBTCPrice + btcVariation).toFixed(0);
    
    // Simulated BTC 24h change
    const btcChange = (Math.random() * 8) - 4; // -4% to +4%
    
    // Simulate market sentiment based on price changes
    let sentiment: string;
    if (solChange > 3 && btcChange > 2) {
      sentiment = "bullish";
    } else if (solChange < -3 && btcChange < -2) {
      sentiment = "bearish";
    } else if (Math.abs(solChange) < 1 && Math.abs(btcChange) < 1) {
      sentiment = "neutral";
    } else if (solChange > 0 && btcChange > 0) {
      sentiment = "mildly bullish";
    } else {
      sentiment = "cautious";
    }
    
    // Network health as a percentage (85-97%)
    const networkHealth = Math.round(85 + (Math.random() * 12));
    
    // Volatility score (1-10)
    const volatility = Math.round(Math.max(1, Math.min(10, 
      3 + Math.abs(solChange) * 0.5 + Math.abs(btcChange) * 0.3
    )));
    
    // Create market data object
    const marketData = {
      solPrice,
      solChange: parseFloat(solChange.toFixed(2)),
      btcPrice,
      btcChange: parseFloat(btcChange.toFixed(2)),
      sentiment,
      networkHealth,
      volatility
    };
    
    // Update cache
    cachedMarketData = marketData;
    lastFetchTime = now;
    
    return marketData;
  } catch (error) {
    console.error("Error fetching market trends:", error);
    
    // Return fallback data if an error occurs
    return {
      solPrice: "150.00",
      solChange: 0,
      btcPrice: "63000",
      btcChange: 0,
      sentiment: "neutral",
      networkHealth: 90,
      volatility: 5
    };
  }
}

// Cache trending topics to reduce API calls
let cachedTrendingTopics: string[] = [];
let lastTrendingFetchTime = 0;
const TRENDING_CACHE_DURATION = 6 * 60 * 60 * 1000; // 6 hours

// Get trending crypto topics for Twitter content variety
export async function getTrendingTopics(): Promise<string[]> {
  try {
    // Check cache first
    const now = Date.now();
    if (cachedTrendingTopics.length > 0 && (now - lastTrendingFetchTime < TRENDING_CACHE_DURATION)) {
      return cachedTrendingTopics;
    }

    // In production, this would fetch from Twitter or crypto news APIs
    // For now, use a variety of relevant topics that change periodically
    
    const topicSets = [
      [
        "Meme coins outperforming the market again",
        "DeFi protocols setting new TVL records",
        "NFT royalties debate heating up",
        "Layer-2 scaling solutions gaining traction",
        "Ethereum gas fees dropping to new lows"
      ],
      [
        "Regulatory clarity coming to crypto markets",
        "AI tokens seeing unprecedented demand",
        "Institutional adoption accelerating",
        "Web3 gaming revolutionizing player ownership",
        "DAO governance models evolving rapidly"
      ],
      [
        "Zero-knowledge proofs changing privacy",
        "Decentralized identity solutions emerging",
        "Tokenization of real-world assets expanding",
        "Cross-chain bridges improving interoperability",
        "Solana ecosystem growing despite market volatility"
      ]
    ];
    
    // Select a topic set based on time (changes daily)
    const dayOfYear = Math.floor(now / (24 * 60 * 60 * 1000)) % topicSets.length;
    const selectedTopics = topicSets[dayOfYear];
    
    // Add some randomized trending tokens
    const trendingTokens = [
      "Solana (SOL) hitting new transaction records",
      "Dogecoin (DOGE) sentiment analysis puzzling analysts",
      "Bitcoin (BTC) dominance shifting with market cycles",
      "Ethereum (ETH) upgrade timeline accelerating",
      "Cardano (ADA) development activity rising",
      "Polkadot (DOT) parachain ecosystem expanding",
      "Avalanche (AVAX) subnet adoption growing",
      "Chainlink (LINK) oracle services expanding",
    ];
    
    // Select 3 random trending tokens
    const selectedTokens = [];
    for (let i = 0; i < 3; i++) {
      const randomIndex = Math.floor(Math.random() * trendingTokens.length);
      selectedTokens.push(trendingTokens[randomIndex]);
      trendingTokens.splice(randomIndex, 1); // Remove selected token
    }
    
    // Combine topics and tokens
    const trendingTopics = [...selectedTopics, ...selectedTokens];
    
    // Update cache
    cachedTrendingTopics = trendingTopics;
    lastTrendingFetchTime = now;
    
    return trendingTopics;
  } catch (error) {
    console.error("Error fetching trending topics:", error);
    
    // Return fallback trending topics
    return [
      "Cryptocurrency market trends",
      "Blockchain technology adoption",
      "Decentralized finance innovations",
      "NFT marketplace developments",
      "Autonomous AI systems in finance"
    ];
  }
}