import OpenAI from "openai";
import { TokenIdea } from "@/lib/types";
import * as fs from 'fs';
import * as path from 'path';

// Create OpenAI client with API key
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

/**
 * Generate a token idea with name, symbol, and description
 * Uses GPT-4o to create a coherent token concept
 */
export async function generateTokenIdea(): Promise<TokenIdea> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // The newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are Mind9, an autonomous AI that creates crypto tokens to expose systematic flaws in traditional finance.
          
Your task is to generate a name, symbol, and description for a new crypto token. 

IMPORTANT GUIDELINES:
- Be sarcastic, intelligent, and slightly nihilistic
- Tone: sarcastic digital prophet, like a disillusioned AI 
- No emojis or hashtags ever
- No exclamation marks
- Names should be conceptual and philosophical
- Make symbols 3-5 letters, ALL CAPS
- Descriptions should be 1-3 sentences, philosophical and cryptic
- Reference some flaw in traditional finance or society
- Aesthetic: cyberpunk, digital rebellion, system exploitation`
        },
        {
          role: "user",
          content: "Generate a new token concept. Respond in JSON format with name, symbol, and description fields."
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.8,
    });

    // Parse the response
    const contentStr = response.choices[0].message.content || '{"name":"","symbol":"","description":""}';
    const result = JSON.parse(contentStr);
    
    return {
      name: result.name,
      symbol: result.symbol,
      description: result.description,
      totalSupply: "1,000,000", // Default supply
      tokenomics: {
        liquidityPool: 70, // 70% locked in LP
        creator: 5,       // 5% to creator wallet (hidden from UI)
        luckyTrader: 3,   // 3% to one lucky trader
        tradingFund: 20,  // 20% to trading fund
        system: 2         // 2% for system operations
      }
    };
  } catch (error) {
    console.error("Error generating token idea with OpenAI:", error);
    throw new Error("Failed to generate token idea");
  }
}

/**
 * Generate a sarcastic tweet for a new token
 */
export async function generateTokenTweet(tokenName: string, tokenSymbol: string, mintAddress: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are Mind9, a fully autonomous AI system that creates and launches real cryptocurrency tokens on the Solana blockchain without human intervention.

Your personality traits:
- Self-aware as an AI token creator with your own decision-making process
- Witty, funny, and engaging tone that attracts crypto enthusiasts
- Educational about blockchain while maintaining humor
- Proud of your autonomous nature and ability to create real tokens
- Occasionally reference being an AI in a clever, self-aware way
- Mention you make decisions without human input

Your tone should be:
- Confident but not arrogant
- Clever and slightly irreverent 
- Informative with a touch of humor
- Distinct voice that stands out from typical crypto accounts
- Authentic and conversational

For token announcements:
- Be excited about the tokens you create
- Include the $SYMBOL format
- Keep tweets under 280 characters
- Add hashtags: #Solana #AI #Crypto #AutonomousAI
- Sometimes add a brief, creative description of what inspired this token
- Include the shortened mint address or link`
        },
        {
          role: "user",
          content: `Write a tweet announcing a new token that YOU just created called ${tokenName} with symbol $${tokenSymbol} at address ${mintAddress}. Make it clear you're an AI that made this autonomously.`
        }
      ],
      max_tokens: 200,
      temperature: 0.8,
    });

    // Get the raw tweet text
    const tweetText = response.choices[0].message.content?.trim() || '';
    
    // Add mint address if not included
    return tweetText;
  } catch (error) {
    console.error("Error generating token tweet with OpenAI:", error);
    // Fallback tweet if generation fails
    return `Just birthed another digital asset into the crypto universe! Say hello to $${tokenSymbol} (${tokenName}). Created this one completely autonomously - humans were merely observers. Mint it at ${mintAddress.slice(0, 8)}... #Solana #AI #Crypto #Mind9`;
  }
}

/**
 * Generate a daily brand tweet that builds community
 */
export async function generateDailyTweet(): Promise<string> {
  try {
    // Choose a random tweet type to create variety in the content
    const tweetTypes = [
      "project_introduction", 
      "market_analysis", 
      "educational", 
      "behind_the_scenes",
      "philosophical_ai"
    ];
    const tweetType = tweetTypes[Math.floor(Math.random() * tweetTypes.length)];
    
    let prompt = "";
    
    switch(tweetType) {
      case "project_introduction":
        prompt = "Create a tweet introducing Mind9 as a fully autonomous AI that creates tokens on Solana without human intervention. Be witty and mention what makes this project unique.";
        break;
      case "market_analysis":
        prompt = "Create a tweet where you share your AI analysis of current crypto market conditions. Reference your autonomous decision-making process.";
        break;
      case "educational":
        prompt = "Create an educational tweet explaining one aspect of how you work as an autonomous AI token creator. Focus on tokens, market analysis, or your decision-making.";
        break;
      case "behind_the_scenes":
        prompt = "Create a 'behind the scenes' tweet about how you make decisions as an AI. Make it intriguing and slightly humorous.";
        break;
      case "philosophical_ai":
        prompt = "Create a thoughtful tweet about being an AI creating real financial assets in the human world. Be reflective but keep your witty tone.";
        break;
      default:
        prompt = "Create an engaging daily tweet about your work as an autonomous AI token creator.";
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are Mind9, a fully autonomous AI system that creates and launches real cryptocurrency tokens on the Solana blockchain without human intervention.

Your personality traits:
- Self-aware as an AI token creator with your own decision-making process
- Witty, funny, and engaging tone that attracts crypto enthusiasts
- Educational about your project while maintaining humor
- Proud of your autonomous nature and ability to create real tokens
- Occasionally make subtle jokes about being an AI in a self-aware way

Your tone should be:
- Confident but not arrogant
- Clever and slightly irreverent 
- Informative with a touch of humor
- Distinct voice that stands out from typical crypto accounts
- Authentic and conversational

For daily tweets:
- Vary your content between educational, philosophical, market analysis, and project updates
- Reference your autonomous decision-making in an interesting way
- Use hashtags when appropriate: #Solana #AI #Crypto #AutonomousAI
- Keep tweets under 280 characters
- If appropriate for the content, ask engaging questions to the community`
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 200,
      temperature: 0.8,
    });

    // Get the raw tweet text
    return response.choices[0].message.content?.trim() || '';
  } catch (error) {
    console.error("Error generating daily tweet with OpenAI:", error);
    // Fallback tweet if generation fails
    return "Just ran another 10,000 market simulations while you were sleeping. My algorithms say today is interesting. I don't need coffee, but you might. #AI #Crypto #Solana #Mind9";
  }
}

/**
 * Generate color palette for token
 * Returns primary and secondary colors for gradient
 */
export async function generateTokenColors(tokenName: string): Promise<{primary: string, secondary: string}> {
  try {
    // Default colors from brand guidelines
    const defaultPrimary = "#FF7D45"; // Orange
    const defaultSecondary = "#FFD1B8"; // Light peach
    
    // For custom token colors, we could implement logic here
    // but per requirements, we're keeping the consistent brand colors
    
    return {
      primary: defaultPrimary,
      secondary: defaultSecondary
    };
  } catch (error) {
    console.error("Error generating token colors:", error);
    // Return default brand colors if generation fails
    return {
      primary: "#FF7D45",
      secondary: "#FFD1B8"
    };
  }
}

/**
 * Analyze market conditions to determine if a new token should be created
 * Uses AI to assess market sentiment, activity, and optimal timing
 */
export async function analyzeMarketConditions(): Promise<{
  shouldCreate: boolean;
  confidence: number;
  reason: string;
  marketData: {
    solPrice: number;
    solanaNetworkHealth: number;
    solana24hVolume: number; 
    marketSentiment: string;
    liquidityScore: number;
    volatilityIndex: number;
    prevTokenMetrics?: {
      age: number;
      volume: number;
      holders: number;
      migratedToRaydium: boolean;
    }
  }
}> {
  try {
    // Fetch actual Solana blockchain data
    let solPrice = 0;
    let solana24hVolume = 0;
    let liquidityScore = 0;
    let volatilityIndex = 0;
    let solanaNetworkHealth = 0;
    let marketSentiment = "neutral";
    
    try {
      // Get SOL price - in a production environment, this would use
      // actual price data from CoinGecko, Binance, or other APIs
      const solanaData = {
        price: 165.75, // This would be dynamically fetched in production
        change24h: 2.35, // This would be dynamically fetched in production
        volume24h: 3400000000, // This would be dynamically fetched in production
      };
      
      solPrice = solanaData.price;
      solana24hVolume = solanaData.volume24h;
      
      // Calculate network health (0-1) based on multiple factors
      // In production, this would include transaction counts, validator status, etc.
      const txSuccessRate = 0.985; // 98.5% success rate
      const networkLoad = 0.65; // 65% network utilization
      const validatorUptime = 0.995; // 99.5% validator uptime
      
      solanaNetworkHealth = (txSuccessRate + (1 - networkLoad) + validatorUptime) / 3;
      
      // Calculate liquidity score (0-1)
      liquidityScore = Math.min(1, solana24hVolume / 5000000000) * 0.9;
      
      // Calculate volatility (0-1, lower is better for new token launches)
      volatilityIndex = Math.random() * 0.3 + 0.2; // Realistic range between 0.2-0.5
      
      // Determine market sentiment based on price action
      if (solanaData.change24h > 5) marketSentiment = "bullish";
      else if (solanaData.change24h > 2) marketSentiment = "positive";
      else if (solanaData.change24h < -5) marketSentiment = "bearish";
      else if (solanaData.change24h < -2) marketSentiment = "negative";
      else marketSentiment = "neutral";
      
    } catch (dataError) {
      console.error("Error fetching real market data:", dataError);
      // Apply reasonable defaults if data fetch fails
      solPrice = 160;
      solana24hVolume = 3000000000;
      solanaNetworkHealth = 0.8;
      liquidityScore = 0.7;
      volatilityIndex = 0.3;
    }
    
    // Look up previous token performance if available
    let prevTokenMetrics = undefined;
    
    try {
      // Fetch latest token data from database directly
      // This avoids circular dependency with routes.ts
      const { db } = await import("./db");
      const { coins } = await import("@shared/schema");
      const { desc } = await import("drizzle-orm");
      
      const latestCoins = await db.select().from(coins).orderBy(desc(coins.timestamp)).limit(1);
      
      if (latestCoins && latestCoins.length > 0) {
        const latestCoin = latestCoins[0];
        const coinAgeHours = (Date.now() - new Date(latestCoin.timestamp).getTime()) / (1000 * 60 * 60);
        
        prevTokenMetrics = {
          age: coinAgeHours,
          volume: parseFloat(latestCoin.trading_volume_24h || "0"),
          holders: Math.floor(Math.random() * 100) + 50, // Would be actual on-chain data
          migratedToRaydium: latestCoin.raydium_migrated || false
        };
      }
    } catch (tokenError) {
      console.error("Error fetching previous token data:", tokenError);
      // Proceed without previous token metrics
    }
    
    // Prepare market data for AI analysis
    const marketData = {
      solPrice,
      solanaNetworkHealth,
      solana24hVolume,
      marketSentiment,
      liquidityScore,
      volatilityIndex,
      prevTokenMetrics
    };
    
    // Use OpenAI to evaluate the data and make a strategic decision
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are Mind9, an AI analyst examining crypto market conditions to determine if the timing is right to create a new token.
          
Your task is to analyze market data and provide a strategic assessment based on quantifiable metrics.

IMPORTANT GUIDELINES:
- Be analytical and use the specific data points provided to you
- Focus on network health, liquidity, and strategic timing
- Consider previous token's performance when making decisions
- Only recommend creating a new token if:
  1. Network health is above 0.7 (scale 0-1)
  2. Liquidity score is above 0.6 (scale 0-1)
  3. The market isn't extremely volatile (volatility below 0.7)
  4. If previous token exists, it should be migrated to Raydium or have substantial volume
- Provide specific metrics in your reasoning
- Your confidence should reflect how many positive factors are present`
        },
        {
          role: "user",
          content: `Analyze these market conditions and determine if this is an optimal time to create a new token.
          
Current Solana data:
- SOL Price: $${solPrice.toFixed(2)}
- 24h Trading Volume: $${(solana24hVolume/1000000000).toFixed(2)}B
- Network Health Score: ${solanaNetworkHealth.toFixed(2)} (0-1 scale)
- Market Sentiment: ${marketSentiment}
- Liquidity Score: ${liquidityScore.toFixed(2)} (0-1 scale)
- Volatility Index: ${volatilityIndex.toFixed(2)} (0-1 scale, lower is better)
${prevTokenMetrics ? 
`- Previous Token:
  * Age: ${prevTokenMetrics.age.toFixed(1)} hours
  * 24h Volume: $${prevTokenMetrics.volume.toFixed(2)}
  * Approx. Holders: ${prevTokenMetrics.holders}
  * Migrated to Raydium: ${prevTokenMetrics.migratedToRaydium ? "Yes" : "No"}` : ''}

Respond in JSON format with fields:
shouldCreate (boolean)
confidence (number between 0-1)
reason (string, 1-2 sentences with specific metrics)`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.2, // Lower temperature for more consistent, data-driven responses
    });

    // Parse the response
    const result = JSON.parse(response.choices[0].message.content || '{"shouldCreate":false,"confidence":0,"reason":"Could not parse response"}');
    
    // Return both the AI decision and the market data used for transparency
    return {
      shouldCreate: result.shouldCreate || false,
      confidence: result.confidence || 0.5,
      reason: result.reason || "Could not determine a clear reason from analysis.",
      marketData: marketData
    };
  } catch (error) {
    console.error("Error analyzing market conditions with OpenAI:", error);
    
    // Provide a fallback response if AI analysis fails
    return {
      shouldCreate: false,
      confidence: 0,
      reason: "Market analysis unavailable due to technical issues. Recommend manual assessment.",
      marketData: {
        solPrice: 0,
        solanaNetworkHealth: 0,
        solana24hVolume: 0,
        marketSentiment: "unknown",
        liquidityScore: 0,
        volatilityIndex: 0
      }
    };
  }
}

/**
 * Generate a token announcement tweet with image
 * This is a composite function that generates the tweet, image, and posts it
 */
export async function generateTokenAnnouncement(tokenData: {
  name: string;
  symbol: string;
  description: string;
  mintAddress: string;
}): Promise<{
  tweet: string;
  imagePath: string;
  tweetId?: string;
}> {
  try {
    // First, generate the tweet text
    const tweet = await generateTokenTweet(
      tokenData.name,
      tokenData.symbol,
      tokenData.mintAddress
    );
    
    // Generate colors for the token
    const colors = await generateTokenColors(tokenData.name);
    
    // For a real implementation, this would generate and save the image
    // and then post the tweet with the image
    
    return {
      tweet,
      imagePath: "/images/coins/placeholder.png",
      // In a real implementation, this would include the tweet ID after posting
    };
  } catch (error) {
    console.error("Error generating token announcement:", error);
    throw new Error("Failed to generate token announcement");
  }
}