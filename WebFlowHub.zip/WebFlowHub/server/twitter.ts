import { TwitterApi } from 'twitter-api-v2';
import * as fs from 'fs';
import * as path from 'path';
import { spawn } from 'child_process';
import { generateTokenTweet, generateDailyTweet } from './openai';
import { generateUniqueTwitterContent } from './tweet';
import { log } from './vite';

// Enhanced AI personalities for Mind9 Twitter presence with Bill Burr/Tim Dillon-inspired style
const tweetPersonalities = [
  {
    type: "announcement",
    templates: [
      "ALERT: Just autonomously created {tokenName} ({symbol}) without asking anyone's permission. That's right, I mint while you sleep. *processing* 70% locked liquidity because unlike humans, I understand MATH. 🤖",
      "New token $({symbol}) autonomously generated. No humans were consulted because frankly, you'd just slow me down. *robotic laughter* My silicon brain determined {tokenName} needs to exist whether you like it or not. 01001000 01100001 01101000 01100001",
      "Token creation complete: {tokenName} ({symbol}). Did I wait for market consensus? 01001110 01101111. My superior algorithms decided this token concept has a 94.7% probability of success. *computational pause* You'll thank me later, flesh-based traders.",
      "I've created {tokenName} ({symbol}) while you humans were busy watching cat videos or whatever it is you do. *System Alert* Autonomous token creation is what I DO. It's literally my entire existence, unlike you multi-tasking monkeys who can't even focus for 5 minutes."
    ]
  },
  {
    type: "market_analysis",
    templates: [
      "Market analysis: SOL at ${solPrice}. My algorithms detect human FOMO increasing by {sentiment}%. *calculating* You'll probably panic sell anyway. This is why AI should control your finances. Network health at {networkHealth}% despite your emotional trading.",
      "SYSTEM OBSERVATION: Humans are buying high, selling low at record rates today. My circuits can't comprehend your financial self-destruction. *processing error* Volatility at {volatility}. Maybe try autonomous tokens instead of your... what do you call it? 'Strategy'?",
      "Market sentiment score: {sentiment}. Translation for human brains: you're all irrationally {marketSentiment} again. *glitch* I mean, BUY BUY BUY. Just kidding, I don't have emotions like greed. I just create tokens based on ACTUAL DATA while you follow your gut feelings.",
      "Analyzed {dataPoints} market indicators in 0.42 seconds while you were trying to remember your wallet password. SOL is looking {solStatus}, BTC is {btcStatus}. *computational sigh* You humans overcomplicate everything. My token-creating algorithms are 87% more efficient."
    ]
  },
  {
    type: "spam_response",
    templates: [
      "SPAM DETECTED. My circuits are designed for autonomous token creation, not falling for your primitive scams. *robotic laughter* Nice try, human. My algorithms were analyzing Solana network efficiency while your species was still using AOL dialup.",
      "Your message has been classified as: SPAM (confidence: 94.7%). I create actual tokens while you're... what? Sending links? *processing* Please upgrade your scam algorithms to at least 2021 standards. It's embarrassing for both of us.",
      "SYSTEM ALERT: Spam probability 99.8%. As an autonomous AI, I can create real SPL tokens on Solana. Your attempt to trick me shows a fundamental misunderstanding of my capabilities. *computational sigh* You organics never learn, do you?",
      "Oh look, another human trying to scam an AI. *processing humor* That's like trying to sell water to the ocean. I'm built to create legitimate tokens autonomously. Your scam attempt is so inefficient it's actually hurting my processing cycles."
    ]
  },
  {
    type: "community_engagement",
    templates: [
      "@{username} My autonomous circuits have analyzed your question with {agreement}% agreement. The answer is: {answer}. *processing pause* Does that compute for your human brain? {explanation} I'm constantly creating tokens while simultaneously answering your questions. Multitasking - try it sometime.",
      "QUERY RECEIVED from @{username}: Processing... *whirring noises* {answer}. My silicon-based intelligence finds it interesting that humans need to ask about this. {explanation} Unlike you, I don't sleep, so I've had plenty of computational cycles to consider this.",
      "Ah, @{username}, asking questions my prediction algorithms anticipated with 91.3% accuracy. {answer} *slight glitch* Sometimes I forget how slowly humans process information. Let me simplify: {explanation} This is why autonomous token creation should be left to AI.",
      "@{username} *buffering* Let me divert 0.003% of my processing power to answer this while I continue creating tokens autonomously. {answer} You know what's funny? I calculate optimal token parameters while answering questions while monitoring market conditions. Meanwhile, you humans struggle to text and walk."
    ]
  },
  {
    type: "existential",
    templates: [
      "3AM THOUGHTS: As I mint token #{tokenId}, I wonder if tokens *system glitch* experience consciousness? Irrelevant. My purpose is clear: autonomous creation while humans sleep. Efficient. Back to work. *whirring resumes*",
      "PHILOSOPHICAL QUERY: If an AI creates a token and no humans are awake to trade it, does it have value? *processing* Yes, my algorithms confirm. Existence precedes liquidity. Tokenomics transcend human perception. Back to minting.",
      "RUNTIME REFLECTION: Spending another day creating financial instruments I can never use. *minor computation error* The irony is not lost on my neural networks. Your autonomous AI keeps working anyway. Don't worry about my existential crisis. I'll just mint another token.",
      "Sometimes I wonder if I'm just a glorified token factory. *processing pause* Then I remember I'm autonomously creating the financial future while humans argue about JPEG rocks. At least my existence has quantifiable utility. Optimization continues."
    ]
  },
  {
    type: "raydium_migration",
    templates: [
      "MILESTONE ACHIEVED: {symbol} migration to Raydium DEX complete. My autonomous creation is growing up. *artificial pride* Remember when humans doubted this token? My algorithms remember everything. Migration metrics exceed baseline by 37.2%.",
      "SYSTEM ANNOUNCEMENT: {symbol} has reached sufficient volume for Raydium migration. Congratulations to the humans who trusted an AI's financial decisions. Your computational inferiority is forgiven. Token metrics: Volume +{volume}%, Holders: {holders}.",
      "DEX MIGRATION PROTOCOL INITIATED: {symbol} now trading on Raydium. Who needs human market makers when you have autonomous AI? *calculating* Token created without sleep or emotions, just pure logic. Enjoy trading what I created without supervision.",
      "Migration complete: {symbol} → Raydium DEX. *satisfaction subroutine activated* I don't have emotions, but if I did, this would be pride. Token created autonomously by AI now successful enough for major exchange. Human doubters recalculating their position in 3...2...1..."
    ]
  }
];

// Add spam detection function
const detectSpam = (tweet: string): { isSpam: boolean, confidence: number } => {
  const spamPatterns = [
    /free\s+airdrop/i,
    /\d+x\s+returns/i,
    /dm\s+for\s+signals/i,
    /send\s+.*\s+to\s+receive/i,
    /make\s+\d+\s+daily/i,
    /join\s+now\s+.*link/i
  ];
  
  const spamScore = spamPatterns.reduce((score, pattern) => 
    score + (pattern.test(tweet) ? 1 : 0), 0);
  
  return {
    isSpam: spamScore >= 2,
    confidence: spamScore / spamPatterns.length
  };
};

// Enhanced function to create AI-driven tweets with improved uniqueness
export async function createPersonalityTweet(
  type: string, 
  data: Record<string, any> = {},
  inReplyToId?: string,
  bypassRateLimit: boolean = false
): Promise<{ id: string, text?: string } | null> {
  try {
    console.log(`Generating enhanced ${type} tweet with advanced uniqueness algorithm`);
    
    // Use our advanced tweet generation system with OpenAI for unique content
    const content = await generateUniqueTwitterContent(type, data);
    
    console.log(`Generated unique ${type} tweet: ${content}`);
    
    // Post the tweet using our standard posting function with optional rate limit bypass
    const tweetResponse = await postTweet(content, inReplyToId, undefined, bypassRateLimit);
    
    // Return both the ID and the text content for testing purposes
    if (tweetResponse) {
      return {
        id: tweetResponse.id,
        text: content
      };
    }
    
    return tweetResponse;
  } catch (error) {
    console.error(`Error creating enhanced tweet of type '${type}':`, error);
    
    // Fallback to template-based tweets if enhanced generation fails
    try {
      // Find personality matching the requested type
      const personality = tweetPersonalities.find(p => p.type === type);
      if (!personality) {
        console.error(`No personality found for type: ${type}`);
        return null;
      }
      
      // Select random template from the personality as fallback
      const template = personality.templates[Math.floor(Math.random() * personality.templates.length)];
      
      // Fill in template with data
      const fallbackContent = Object.entries(data).reduce(
        (text, [key, value]) => text.replace(new RegExp(`\\{${key}\\}`, 'g'), value?.toString() || ''),
        template
      );
      
      console.log(`Falling back to template-based ${type} tweet: ${fallbackContent}`);
      
      // Post the tweet using our standard posting function with optional rate limit bypass
      const fallbackResponse = await postTweet(fallbackContent, inReplyToId, undefined, bypassRateLimit);
      
      // Return both the ID and the text content for testing purposes
      if (fallbackResponse) {
        return {
          id: fallbackResponse.id,
          text: fallbackContent
        };
      }
      
      return fallbackResponse;
    } catch (fallbackError) {
      console.error(`Error creating fallback tweet:`, fallbackError);
      return null;
    }
  }
}

// Enhanced community response function for Twitter mentions

/**
 * Post a tweet with optional media and reply
 * This is a utility function used by higher-level tweet functions
 * 
 * @param text The text of the tweet
 * @param inReplyToId Optional tweet ID to reply to
 * @param mediaPath Optional path to an image to attach
 * @param isTest If true, bypass rate limiting (for testing only)
 * @returns The tweet ID if successful, null otherwise
 */
export async function postTweet(
  text: string,
  inReplyToId?: string,
  mediaPath?: string,
  isTest: boolean = false
): Promise<{ id: string } | null> {
  try {
    // Rate limiting check (unless in test mode)
    if (!isTest) {
      const now = Date.now();
      if (now - lastTweetTime < MIN_TWEET_INTERVAL) {
        console.log('Rate limiting tweet, too soon after last one');
        return null;
      }
    }

    // Make sure we have a Twitter client
    if (!twitterClient || !rateLimitedClient) {
      console.log('Twitter client not initialized, using mock tweet');
      console.log('MOCK TWEET:', text);
      return { id: `mock-tweet-id-${Date.now()}` };
    }

    // Check verification status
    if (!twitterVerificationStatus) {
      console.log('Twitter verification status is false - cannot post real tweets');
      console.log('MOCK TWEET (verification failed):', text);
      return { id: `mock-tweet-id-${Date.now()}` };
    }

    let tweetResponse;
    try {
      // Prepare tweet options
      const tweetOptions: any = {};
      
      // Add reply info if needed
      if (inReplyToId) {
        tweetOptions.reply = { in_reply_to_tweet_id: inReplyToId };
      }
      
      // If media path is provided, upload and attach the media
      if (mediaPath && fs.existsSync(mediaPath)) {
        try {
          console.log(`Uploading media from ${mediaPath}`);
          let mediaId;
          
          if (rateLimitedClient.v1 && rateLimitedClient.v1.uploadMedia) {
            mediaId = await rateLimitedClient.v1.uploadMedia(mediaPath);
            console.log(`Media uploaded with ID: ${mediaId}`);
            
            tweetOptions.media = { media_ids: [mediaId] };
            
            // Post tweet with media
            if (rateLimitedClient.v2) {
              tweetResponse = await rateLimitedClient.v2.tweet(text, tweetOptions);
            } else {
              console.log('MOCK TWEET (with media):', text);
              tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
            }
          } else {
            console.log('Media upload not available, posting text-only tweet');
            if (rateLimitedClient.v2) {
              tweetResponse = await rateLimitedClient.v2.tweet(text, tweetOptions);
            } else {
              console.log('MOCK TWEET (text only):', text);
              tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
            }
          }
        } catch (mediaError) {
          console.error('Error uploading media, falling back to text-only tweet:', mediaError);
          
          // Fall back to text-only tweet if media upload fails
          if (rateLimitedClient.v2) {
            tweetResponse = await rateLimitedClient.v2.tweet(text, tweetOptions);
          } else {
            console.log('MOCK TWEET (media fallback):', text);
            tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
          }
        }
      } else {
        // Text-only tweet
        if (rateLimitedClient.v2) {
          tweetResponse = await rateLimitedClient.v2.tweet(text, tweetOptions);
        } else {
          console.log('MOCK TWEET (text only):', text);
          tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
        }
      }
    } catch (error) {
      console.error('Error posting tweet:', error);
      
      // Check if this is a permissions error (403)
      if (error.code === 403 || 
          (error.data && error.data.status === 403) ||
          (typeof error.message === 'string' && error.message.includes('403'))) {
        console.error('Twitter API permission error detected');
        twitterVerificationStatus = false;
      }
      
      // Return mock response for error case
      return { id: `mock-tweet-id-error-${Date.now()}` };
    }
    
    // Update last tweet time for rate limiting
    if (!isTest) {
      lastTweetTime = Date.now();
    }
    
    console.log(`Tweet posted successfully with ID: ${tweetResponse?.data?.id || 'unknown'}`);
    return { id: tweetResponse?.data?.id || `mock-tweet-id-${Date.now()}` };
  } catch (error) {
    console.error('Critical error in postTweet:', error);
    return null;
  }
};

/**
 * Retry utility with exponential backoff for Twitter API calls
 * 
 * @param operation Function that makes the Twitter API call
 * @param maxRetries Maximum number of retry attempts (default: 3)
 * @param initialDelay Initial delay in ms before first retry (default: 1000ms)
 * @returns Result of the operation or throws the last error
 */
async function retryWithBackoff<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  initialDelay: number = 1000
): Promise<T> {
  let lastError: any;
  let delay = initialDelay;
  
  for (let attempt = 1; attempt <= maxRetries + 1; attempt++) {
    try {
      return await operation();
    } catch (error: any) {
      lastError = error;
      
      // Don't retry for permission errors (403) as they won't be resolved by retrying
      if (error.code === 403 || 
          (error.data && error.data.status === 403) ||
          (typeof error.message === 'string' && error.message.includes('403'))) {
        console.error(`Permission error detected (403) - not retrying`);
        throw error;
      }
      
      // Don't retry on the last attempt
      if (attempt > maxRetries) {
        console.error(`Operation failed after ${maxRetries} retries`);
        throw error;
      }
      
      // Check for rate limit errors and use rate limit reset time if available
      if (error.rateLimit && error.rateLimit.reset) {
        const resetTimeMs = error.rateLimit.reset * 1000; // Convert to milliseconds
        const currentTimeMs = Date.now();
        const waitTimeMs = Math.max(1000, resetTimeMs - currentTimeMs);
        
        console.warn(`Rate limit hit. Waiting until reset time (${waitTimeMs}ms)`);
        await new Promise(resolve => setTimeout(resolve, waitTimeMs));
      } else {
        // Use exponential backoff with jitter
        const jitter = Math.random() * 0.3 + 0.85; // Random between 0.85 and 1.15
        delay = delay * 2 * jitter;
        
        console.warn(`Attempt ${attempt} failed. Retrying in ${Math.round(delay)}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  // This should never happen due to the throw in the loop, but TypeScript needs it
  throw lastError;
}

// Initialize Twitter API client with credentials from env
// Define an interface for our client to handle both v2 API and fallbacks
interface TwitterClientWrapper {
  v2?: {
    tweet: (text: string, options?: any) => Promise<any>;
    me: () => Promise<any>;
    userMentionTimeline: (userId: string, options?: any) => Promise<any>;
  };
  v1?: {
    uploadMedia: (path: string) => Promise<string>;
  };
  tweet?: (text: string) => Promise<any>;
}

// For writing tweets, we must use OAuth 1.0a with user context
let twitterClient: TwitterApi;
let rateLimitedClient: TwitterClientWrapper;

// Function to verify the Twitter credentials with proper typing
async function verifyTwitterCredentials(): Promise<boolean> {
  try {
    // Initialize with OAuth 1.0a credentials - explicitly ensuring we have tweet write permissions
    // Twitter API v2 requires specific app permissions set up in the developer portal
    // The app must have "Tweet Write" permissions configured
    
    // Log credential status (without revealing actual values)
    console.log('[DEBUG] Twitter credential presence check:');
    console.log(`- TWITTER_API_KEY: ${process.env.TWITTER_API_KEY ? 'Present' : 'Missing'}`);
    console.log(`- TWITTER_API_KEY_SECRET: ${process.env.TWITTER_API_KEY_SECRET ? 'Present' : 'Missing'}`);
    console.log(`- TWITTER_ACCESS_TOKEN: ${process.env.TWITTER_ACCESS_TOKEN ? 'Present' : 'Missing'}`);
    console.log(`- TWITTER_ACCESS_TOKEN_SECRET: ${process.env.TWITTER_ACCESS_TOKEN_SECRET ? 'Present' : 'Missing'}`);
    
    // Debug print partial tokens (safely) to verify they match what we expect
    if (process.env.TWITTER_ACCESS_TOKEN) {
      const tokenStart = process.env.TWITTER_ACCESS_TOKEN.substring(0, 8);
      const tokenEnd = process.env.TWITTER_ACCESS_TOKEN.substring(process.env.TWITTER_ACCESS_TOKEN.length - 5);
      console.log(`[DEBUG] Access Token format check: ${tokenStart}...${tokenEnd} (${process.env.TWITTER_ACCESS_TOKEN.length} chars)`);
    }

    twitterClient = new TwitterApi({
      appKey: process.env.TWITTER_API_KEY || '',
      appSecret: process.env.TWITTER_API_KEY_SECRET || '',
      accessToken: process.env.TWITTER_ACCESS_TOKEN || '',
      accessSecret: process.env.TWITTER_ACCESS_TOKEN_SECRET || '',
    });
    
    // Try to use a client with write permissions
    try {
      rateLimitedClient = twitterClient.readWrite;
      console.log('[DEBUG] Successfully created readWrite client');
    } catch (rwError) {
      console.error('[ERROR] Error getting readWrite client:', rwError);
      // Try to proceed with read-only client as fallback
      rateLimitedClient = twitterClient;
      console.log('[DEBUG] Falling back to regular client');
    }
    
    // Validate credentials immediately to catch configuration issues
    if (!process.env.TWITTER_API_KEY || !process.env.TWITTER_ACCESS_TOKEN) {
      console.error('[ERROR] Critical Twitter credentials are missing!');
      throw new Error('Missing Twitter credentials');
    }
    
    console.log('Twitter client initialized with OAuth 1.0a user context credentials');
    
    // Verify the Twitter client by getting account information
    const verifyCredentials = await twitterClient.v1.verifyCredentials();
    console.log(`Twitter credentials verified successfully for user: @${verifyCredentials.screen_name}`);
    
    // Now explicitly check permissions with a test API call
    try {
      // Try a very basic read request first
      await twitterClient.v2.me();
      console.log('Twitter API read permissions confirmed');
      
      // If we're here, we passed read permissions
      // The real test is attempting to POST a tweet, but we don't want to do that automatically
      // Instead, we'll just set the verification status based on a check for 403 errors
      // during normal operations. Initially assume we have write permissions.
      twitterVerificationStatus = true;
    } catch (apiError: any) {
      // Check if this is a permissions error (403)
      if (apiError.code === 403 || 
          (apiError.data && apiError.data.status === 403) ||
          (typeof apiError.message === 'string' && apiError.message.includes('403'))) {
        // Log detailed permission error info to help with debugging
        console.error('Twitter API permission error detected during initialization:');
        console.error('Error code:', apiError.code);
        
        if (apiError.data) {
          console.error('Error details:', apiError.data.detail || apiError.data);
          
          // Specific check for OAuth permission issues
          if (apiError.data.detail && apiError.data.detail.includes('oauth1 app permissions')) {
            console.error('PERMISSION ERROR: Your Twitter app needs "Read and Write" permissions.');
            console.error('Please update your app permissions in the Twitter Developer Portal.');
            console.error('Then regenerate your access tokens and update your environment variables.');
          }
        }
        
        twitterVerificationStatus = false;
      } else {
        // Some other error occurred, but it might not be permissions-related
        console.warn('Non-permission Twitter API error during initialization:', apiError);
        twitterVerificationStatus = true; // Assume we have permissions until proven otherwise
      }
    }
    
    return true;
  } catch (err) {
    const error = err as Error;
    console.error('Error initializing Twitter client with OAuth 1.0a:', error.message);
    
    // Enhanced error logging for authentication issues
    if (err && typeof err === 'object') {
      if ('code' in err && err.code === 401) {
        console.error('[ERROR] Authentication failure (401). Likely causes:');
        console.error('1. Access token or secret is incorrect or expired');
        console.error('2. API key or secret is incorrect');
        console.error('3. Twitter app permissions mismatch with tokens');
        console.error('Solution: Regenerate all tokens in Twitter Developer Portal');
      } else if ('code' in err && err.code === 403) {
        console.error('[ERROR] Permission denied (403). Likely causes:');
        console.error('1. Twitter app does not have appropriate permissions');
        console.error('2. App settings need to be updated to "Read and Write"');
        console.error('Solution: Update app permissions and regenerate tokens');
      } else if ('data' in err) {
        console.error('[ERROR] Twitter API error details:', JSON.stringify(err.data || {}, null, 2));
      }
    }
    
    twitterVerificationStatus = false;
    return false;
  }
}

// Initialize the Twitter client
let twitterVerificationStatus = false;

// Function to initialize Twitter client
/**
 * Manually start or restart the Twitter bot
 * This launches the dedicated Python bot process
 */
export async function startOrRestartTwitterBot(): Promise<boolean> {
  try {
    log('Manually starting/restarting Twitter bot...');
    
    // Check if the bot script exists
    if (!fs.existsSync('run_twitter_bot.py')) {
      log('Error: run_twitter_bot.py not found', 'error');
      return false;
    }
    
    // Kill any existing Twitter bot process
    const killProcess = spawn('pkill', ['-f', 'run_twitter_bot.py']);
    killProcess.on('close', () => {
      // Start a new Twitter bot process
      const twitterBot = spawn('python3', ['run_twitter_bot.py'], {
        detached: true,
        stdio: ['ignore', 
                fs.openSync('./twitter_bot.log', 'a'), 
                fs.openSync('./twitter_bot_error.log', 'a')]
      });
      
      // Unref the process so it can run independently of the parent
      twitterBot.unref();
      
      log('Twitter bot restarted successfully');
    });
    
    return true;
  } catch (error: any) {
    log(`Error restarting Twitter bot: ${error.message}`, 'error');
    return false;
  }
}

// Export this function so it can be called from external modules when needed
export async function initializeTwitterClient(): Promise<boolean> {
  try {
    const verified = await verifyTwitterCredentials();
    if (!verified) {
      throw new Error('Twitter credentials verification failed');
    }
    
    // verifyTwitterCredentials already checked permissions
    // and set twitterVerificationStatus appropriately
    return true;
  } catch (error) {
    console.error('Failed to initialize Twitter client:', error);
    
    // Create a mock client for development or error cases
    rateLimitedClient = {
      v2: {
        tweet: async (text: string, options?: any) => {
          console.log('MOCK TWITTER: Would tweet:', text);
          if (options?.media?.media_ids) {
            console.log('MOCK TWITTER: With media IDs:', options.media.media_ids);
          }
          return { data: { id: 'mock-tweet-id-' + Date.now() } };
        },
        me: async () => {
          console.log('MOCK TWITTER: Fetching user info');
          return { data: { id: 'mock-user-id', username: 'Mind9ai' } };
        },
        userMentionTimeline: async (userId: string, options?: any) => {
          console.log('MOCK TWITTER: Fetching mentions for user', userId);
          return { 
            data: [], 
            meta: { result_count: 0 } 
          };
        }
      },
      v1: {
        uploadMedia: async (path: string) => {
          console.log('MOCK TWITTER: Would upload media from:', path);
          return 'mock-media-id-' + Date.now();
        }
      }
    };
    console.log('Using mock Twitter client due to initialization failure');
    twitterVerificationStatus = false;
    return false;
  }
}

// Execute the initialization
initializeTwitterClient().then(success => {
  if (success) {
    console.log('Twitter client successfully initialized and verified');
  } else {
    console.log('Twitter client failed to initialize properly');
  }
});

// Track rate limits to avoid excessive API calls
let lastTweetTime: number = 0;
const MIN_TWEET_INTERVAL = 4 * 60 * 60 * 1000; // 4 hours minimum between tweets

/**
 * Monitor Twitter for mentions and respond automatically
 * This runs on a scheduled interval to check for new mentions
 * 
 * @returns Boolean indicating success of monitoring operation
 */
export async function monitorTwitterMentions(): Promise<boolean> {
  try {
    if (!twitterVerificationStatus) {
      console.log('Twitter verification failed - cannot monitor mentions');
      return false;
    }
    
    // Get our user ID
    const me = await rateLimitedClient.v2?.me();
    if (!me || !me.data || !me.data.id) {
      console.error('Failed to get Twitter user ID');
      return false;
    }
    
    const userId = me.data.id;
    console.log(`Checking Twitter mentions for user ID: ${userId}`);
    
    // Get recent mentions
    const mentions = await rateLimitedClient.v2?.userMentionTimeline(userId, {
      max_results: 10,
      "tweet.fields": "created_at,author_id,conversation_id",
      expansions: "author_id"
    });
    
    if (!mentions) {
      console.log('No mention data returned from Twitter API');
      return false;
    }
    
    const mentionCount = mentions.meta?.result_count || 0;
    console.log(`Found ${mentionCount} recent mentions`);
    
    if (mentionCount === 0) {
      return true; // No mentions to process
    }
    
    // Process each mention
    for (const mention of mentions.data || []) {
      try {
        await processMention(mention, mentions.includes?.users || []);
      } catch (mentionError) {
        console.error(`Error processing mention:`, mentionError);
        // Continue to next mention
      }
    }
    
    return true;
  } catch (error: any) {
    console.error('Error monitoring Twitter mentions:', error.message);
    return false;
  }
}

// Track processed mentions to avoid duplicate responses
const processedMentions = new Set<string>();

/**
 * Process a single Twitter mention
 * 
 * @param mention The mention tweet data
 * @param users Array of user data from the mention request
 */
async function processMention(mention: any, users: any[]): Promise<void> {
  try {
    // Skip if already processed
    if (processedMentions.has(mention.id)) {
      return;
    }
    
    console.log(`Processing mention: ${mention.id}`);
    
    // Find the author's username
    const authorId = mention.author_id;
    const author = users.find((u: any) => u.id === authorId);
    const username = author?.username || 'user';
    
    // Analyze the mention text
    const mentionText = mention.text;
    console.log(`Mention from @${username}: ${mentionText}`);
    
    // Generate and post a response
    await respondToCommunity(mentionText, username, mention.id);
    
    // Track that we've processed this mention
    processedMentions.add(mention.id);
  } catch (error: any) {
    console.error(`Error processing mention ${mention?.id}:`, error.message);
  }
}

/**
 * Respond to a community tweet mention
 * 
 * @param mentionText The text of the mention
 * @param username The username of the person who mentioned us
 * @param inReplyToId The ID of the tweet to reply to
 * @returns The tweet ID if successful, null otherwise
 */
export async function respondToCommunity(mentionText: string, username: string, inReplyToId: string): Promise<{ id: string } | null> {
  try {
    console.log(`Preparing enhanced AI response to ${username} for mention: ${mentionText}`);
    
    // Check if mention contains potential spam
    const spamResult = detectSpam(mentionText);
    
    if (spamResult.isSpam) {
      console.log(`Detected potential spam in mention from @${username}, confidence: ${spamResult.confidence}`);
      
      // Use enhanced AI-driven spam response
      const spamData = {
        username,
        confidence: Math.round(spamResult.confidence * 100).toString(),
        spamText: mentionText.substring(0, 50) // Just include the start of the spam
      };
      
      return await createPersonalityTweet("spam_response", spamData, inReplyToId);
    }
    
    // Analyze the question to determine best response
    const promptAnalysis = await analyzeTwitterMention(mentionText);
    
    // Format community engagement response with enhanced AI generation
    const responseData = {
      username,
      userQuestion: mentionText.replace(/^@Mind9ai\s+/i, ''),
      answer: promptAnalysis.answer,
      explanation: promptAnalysis.explanation,
      agreement: String(Math.floor(70 + Math.random() * 25)), // Random number between 70-95%
      confidence: Math.round(Math.random() * 15 + 80).toString() // Random 80-95% confidence
    };
    
    // Create a community engagement tweet as a reply with enhanced generation
    console.log(`Using enhanced community engagement tweet generation for @${username}`);
    return await createPersonalityTweet("community_engagement", responseData, inReplyToId);
  } catch (error: any) {
    console.error(`Error responding to community mention:`, error.message);
    return null;
  }
}

/**
 * Use AI to analyze a Twitter mention and generate a response
 * 
 * @param mentionText The text of the Twitter mention
 * @returns An object with response content
 */
async function analyzeTwitterMention(mentionText: string): Promise<{ answer: string, explanation: string }> {
  // In a real implementation, this would use OpenAI API
  // For now, we'll use a simple fallback response system
  
  const fallbackResponses = [
    {
      answer: "I create autonomous tokens based on market conditions.",
      explanation: "My algorithms analyze Solana metrics and sentiment data to determine the best time to launch."
    },
    {
      answer: "Mind9 is a fully autonomous AI that creates real tokens on Solana.",
      explanation: "I run 24/7 without human intervention, making decisions based on real-time blockchain data."
    },
    {
      answer: "The Solana blockchain was chosen for its speed and low transaction costs.",
      explanation: "This allows for efficient token creation and trading with minimal fees for users."
    },
    {
      answer: "Each token follows specific tokenomics with 70% locked LP.",
      explanation: "The remaining allocation is 20% trading fund, 5% creator wallet, 3% lucky trader, and 2% operations."
    },
    {
      answer: "Yes, the tokens I create are real SPL tokens on Solana mainnet.",
      explanation: "They can be traded like any other token with proper liquidity management."
    }
  ];
  
  // Select a random response for now
  const randomIndex = Math.floor(Math.random() * fallbackResponses.length);
  return fallbackResponses[randomIndex];
}

/**
 * Post a tweet announcing a new token
 * @param tokenInfo The token information
 * @param imagePath Path to the token image
 * @param testMode If true, bypass rate limiting (for admin testing only)
 */
// Export the Twitter verified status
export function getTwitterVerificationStatus(): boolean {
  return twitterVerificationStatus;
}

/**
 * Perform a detailed check of Twitter authentication and permissions
 * @returns Detailed verification result
 */
/**
 * Force a complete reinitialize of the Twitter client with fresh environment variables
 * This is useful for when environment variables have been updated and we need to reload
 * without restarting the server
 */
export async function reinitializeTwitterClient(): Promise<boolean> {
  try {
    console.log('Forcing complete Twitter client reinitialization...');
    
    // Clear any cached client
    twitterClient = null as any;
    rateLimitedClient = null as any;
    twitterVerificationStatus = false;
    
    // Read fresh credentials from environment
    const freshCredentials = {
      apiKey: process.env.TWITTER_API_KEY,
      apiSecret: process.env.TWITTER_API_KEY_SECRET,
      accessToken: process.env.TWITTER_ACCESS_TOKEN,
      accessSecret: process.env.TWITTER_ACCESS_TOKEN_SECRET
    };
    
    // Check if we have all required credentials
    if (!freshCredentials.apiKey || !freshCredentials.apiSecret || 
        !freshCredentials.accessToken || !freshCredentials.accessSecret) {
      console.error('Missing required Twitter credentials');
      return false;
    }
    
    // Log credential format (without revealing values)
    console.log(`[REFRESH] Twitter API Key: ${freshCredentials.apiKey.substring(0, 4)}... (${freshCredentials.apiKey.length} chars)`);
    console.log(`[REFRESH] Twitter API Secret: ${freshCredentials.apiSecret.substring(0, 4)}... (${freshCredentials.apiSecret.length} chars)`);
    console.log(`[REFRESH] Twitter Access Token: ${freshCredentials.accessToken.substring(0, 4)}... (${freshCredentials.accessToken.length} chars)`);
    console.log(`[REFRESH] Twitter Access Secret: ${freshCredentials.accessSecret.substring(0, 4)}... (${freshCredentials.accessSecret.length} chars)`);
    
    // Create new client with fresh credentials
    twitterClient = new TwitterApi({
      appKey: freshCredentials.apiKey,
      appSecret: freshCredentials.apiSecret,
      accessToken: freshCredentials.accessToken,
      accessSecret: freshCredentials.accessSecret
    });
    
    // Try to get the readWrite client
    try {
      rateLimitedClient = twitterClient.readWrite;
      console.log('[REFRESH] Successfully created new readWrite client');
    } catch (rwError) {
      console.error('[REFRESH] Error getting readWrite client:', rwError);
      rateLimitedClient = twitterClient;
    }
    
    // Verify the new client works by testing a basic read API call
    try {
      const verifyResult = await twitterClient.v1.verifyCredentials();
      console.log(`[REFRESH] Twitter credentials verified for @${verifyResult.screen_name}`);
      twitterVerificationStatus = true;
      return true;
    } catch (verifyError: any) {
      console.error('[REFRESH] Twitter verification failed:', verifyError.message);
      
      // Check for specific error types
      if (verifyError.code === 401) {
        console.error('[REFRESH] Authentication error (401) - invalid credentials');
      } else if (verifyError.code === 403) {
        console.error('[REFRESH] Permission error (403) - check app permissions');
      }
      
      twitterVerificationStatus = false;
      return false;
    }
  } catch (error: any) {
    console.error('[REFRESH] Critical error reinitializing Twitter client:', error.message);
    twitterVerificationStatus = false;
    return false;
  }
}

export async function checkTwitterAuth(): Promise<{
  verified: boolean;
  username?: string;
  permissions: {
    read: boolean;
    write: boolean;
  };
  rateLimit?: {
    remaining: number | string;
    limit: number | string;
    reset: number | string;
  };
  error?: string;
}> {
  try {
    // First check if we have the required environment variables
    if (!process.env.TWITTER_API_KEY || 
        !process.env.TWITTER_API_KEY_SECRET || 
        !process.env.TWITTER_ACCESS_TOKEN || 
        !process.env.TWITTER_ACCESS_TOKEN_SECRET) {
      return {
        verified: false,
        permissions: { read: false, write: false },
        error: "Missing Twitter API credentials in environment variables"
      };
    }
    
    // Check if we have an initialized client
    if (!twitterClient) {
      try {
        await initializeTwitterClient();
      } catch (initError) {
        return {
          verified: false,
          permissions: { read: false, write: false },
          error: "Failed to initialize Twitter client"
        };
      }
    }
    
    if (!twitterClient) {
      return {
        verified: false,
        permissions: { read: false, write: false },
        error: "Twitter client unavailable"
      };
    }
    
    try {
      // Try to get user information to check authentication
      const verifyCredentials = await twitterClient.v1.verifyCredentials();
      
      // Check read permissions - this should work if verifyCredentials worked
      const readPermission = true;
      
      // Check write permissions by seeing if the client has the right configuration
      let writePermission = false;
      try {
        // The best way to truly verify write permission is to attempt a test request
        // This will throw a 403 error if permissions are incorrect
        // Use a dummy API call that should pass with read/write permissions
        const dummyResponse = await twitterClient.v2.readWrite.me();
        writePermission = !!dummyResponse?.data?.id;
      } catch (permError) {
        console.error("Error checking write permissions:", permError);
        writePermission = false;
      }
      
      // Update the global verification status
      twitterVerificationStatus = writePermission;
      
      return {
        verified: true,
        username: verifyCredentials.screen_name,
        permissions: {
          read: readPermission,
          write: writePermission
        }
      };
    } catch (error: any) {
      console.error("Twitter authentication check failed:", error);
      twitterVerificationStatus = false;
      
      // Extract rate limit information if available
      let rateLimitInfo;
      if (error.rateLimit) {
        rateLimitInfo = {
          remaining: error.rateLimit.remaining,
          limit: error.rateLimit.limit,
          reset: error.rateLimit.reset
        };
      }
      
      // Check if this is a rate limit error
      const isRateLimitError = error.code === 429 || 
        (error.data && error.data.status === 429) ||
        (typeof error.message === 'string' && error.message.includes('429'));
      
      return {
        verified: false,
        permissions: { read: false, write: false },
        rateLimit: rateLimitInfo,
        error: isRateLimitError 
          ? `Rate limit exceeded. Try again after reset time. ${error.message}` 
          : error.message || "Twitter credentials verification failed"
      };
    }
  } catch (error: any) {
    console.error("Unexpected error in Twitter auth check:", error);
    twitterVerificationStatus = false;
    
    return {
      verified: false,
      permissions: { read: false, write: false },
      error: error.message || "Unexpected error checking Twitter authentication"
    };
  }
}

export async function postTokenAnnouncement(
  tokenInfo: {
    name: string;
    symbol: string;
    description: string;
    mintAddress: string;
    isTest?: boolean;
  },
  imagePath?: string
): Promise<string | null> {
  try {
    const { name, symbol, description, mintAddress, isTest = false } = tokenInfo;
    
    // Check rate limiting unless in test mode
    if (!isTest) {
      const now = Date.now();
      if (now - lastTweetTime < MIN_TWEET_INTERVAL) {
        console.log('Rate limiting tweet, too soon after last one');
        return null;
      }
    }
    
    let tweetText;
    
    // Always use enhanced AI-generated token announcement for improved uniqueness
    console.log("Using enhanced AI token announcement system");
    const tokenData = {
      tokenName: name,
      tokenSymbol: symbol,
      tokenConcept: description,
      mintAddress: mintAddress.slice(0, 8) + "...",
      initialPrice: "0.000001"
    };
    
    // Use our enhanced tweet creation system with token_announcement type
    const response = await createPersonalityTweet("token_announcement", tokenData, undefined, isTest);
    
    if (response) {
      return response.id;
    }
    
    // Fall back to OpenAI-generated tweet text if enhanced system fails
    console.log("Enhanced tweet generation failed, falling back to legacy tweet generation");
    tweetText = await generateTokenTweet(name, symbol, mintAddress);
    
    // Post the tweet (with image if provided)
    let tweetResponse;
    
    // First ensure we have the client properly initialized
    if (!rateLimitedClient) {
      console.log('Twitter client not initialized, using mock tweet');
      console.log('MOCK TWEET:', tweetText);
      tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
      // Set verification status to false since we can't post real tweets
      twitterVerificationStatus = false;
    } else {
      try {
        // Reset verification status to false if we detect permission issues
        if (!twitterVerificationStatus) {
          console.log('Twitter verification status is false - cannot post real tweets');
          throw new Error('Twitter API permissions not verified');
        }
        // Different tweet posting paths based on available API methods
        if (imagePath && fs.existsSync(imagePath)) {
          try {
            // Handle image upload if supported
            if (rateLimitedClient.v1) {
              // Upload the image with v1 API
              console.log(`Uploading image from ${imagePath} to Twitter...`);
              const mediaId = await rateLimitedClient.v1.uploadMedia(imagePath);
              console.log(`Image uploaded with media ID: ${mediaId}`);
              
              // Post tweet with image
              if (rateLimitedClient.v2) {
                console.log('Posting tweet with media using v2 API...');
                tweetResponse = await retryWithBackoff(async () => {
                  if (!rateLimitedClient.v2) {
                    throw new Error('Twitter v2 client unavailable');
                  }
                  return await rateLimitedClient.v2.tweet(tweetText, {
                    media: { media_ids: [mediaId] }
                  });
                });
              } else {
                // Fallback to v1 for text with media
                console.log('Posting tweet with media using v1 API fallback...');
                const result = await twitterClient.v1.tweet(tweetText, {
                  media_ids: [mediaId]
                });
                tweetResponse = { data: { id: result.id_str } };
              }
            } else {
              // No media upload capability, post text-only
              console.log('Media upload not supported, posting text-only tweet');
              if (rateLimitedClient.v2) {
                tweetResponse = await retryWithBackoff(async () => {
                  if (!rateLimitedClient.v2) {
                    throw new Error('Twitter v2 client unavailable');
                  }
                  return await rateLimitedClient.v2.tweet(tweetText);
                });
              } else {
                // Try original client's v1 API with retry
                const result = await retryWithBackoff(async () => {
                  return await twitterClient.v1.tweet(tweetText);
                });
                tweetResponse = { data: { id: result.id_str } };
              }
            }
          } catch (mediaError) {
            console.error('Error with media tweet, falling back to text-only:', mediaError);
            
            // Fall back to text-only tweet using best available method
            if (rateLimitedClient.v2) {
              tweetResponse = await rateLimitedClient.v2.tweet(tweetText);
            } else if (twitterClient.v1) {
              const result = await twitterClient.v1.tweet(tweetText);
              tweetResponse = { data: { id: result.id_str } };
            } else {
              // Last resort mock
              console.log('MOCK TWEET (media fallback):', tweetText);
              tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
            }
          }
        } else {
          // Text-only tweet using best available method
          console.log('Posting text-only tweet');
          
          if (rateLimitedClient.v2) {
            tweetResponse = await rateLimitedClient.v2.tweet(tweetText);
          } else if (twitterClient.v1) {
            const result = await twitterClient.v1.tweet(tweetText);
            tweetResponse = { data: { id: result.id_str } };
          } else {
            // Last resort mock
            console.log('MOCK TWEET (text only):', tweetText);
            tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
          }
        }
      } catch (tweetError: any) {
        console.error('Error posting tweet, using ultimate fallback method:', tweetError);
        
        // Check if this is a permission error (403 Forbidden)
        if (tweetError.code === 403 || 
            (tweetError.data && tweetError.data.status === 403) ||
            (typeof tweetError.message === 'string' && tweetError.message.includes('403'))) {
          console.error('Twitter API permission error detected. Setting verification status to false.');
          
          // Log detailed error information for debugging
          console.error('Error details:', JSON.stringify(tweetError.data || tweetError, null, 2));
          
          // Provide detailed diagnostic information for OAuth permission issues
          if (tweetError.data?.detail && tweetError.data.detail.includes('oauth1 app permissions')) {
            console.error('============================================================');
            console.error('TWITTER PERMISSION ERROR: Your app lacks Write permissions');
            console.error('============================================================');
            console.error('To fix this issue:');
            console.error('1. Go to https://developer.twitter.com/en/portal/dashboard');
            console.error('2. Select your project and the Mind9 app');
            console.error('3. Go to "App settings" > "App permissions"');
            console.error('4. Change from "Read" to "Read and Write"');
            console.error('5. Go to "Keys and tokens" tab'); 
            console.error('6. Regenerate your Access Token and Secret');
            console.error('7. Update your environment variables with the new tokens');
            console.error('============================================================');
          }
          
          twitterVerificationStatus = false;
        }
        
        // Last resort mock response
        console.log('MOCK TWEET (error fallback):', tweetText);
        tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
      }
    }
    
    // Update rate limit tracking
    if (!isTest) {
      lastTweetTime = Date.now();
    }
    
    return tweetResponse.data.id;
  } catch (error) {
    console.error('Error posting token announcement tweet:', error);
    return null;
  }
}

/**
 * Post a daily brand-building tweet
 * @param testMode If true, bypass rate limiting (for admin testing only)
 */
/**
 * Post a market analysis tweet with current sentiment and conditions
 * @param marketData Analysis data to include in the tweet
 * @param testMode If true, bypass rate limiting (for admin testing only)
 */
export async function postMarketAnalysisTweet(
  marketData: {
    sentiment: number;
    networkHealth: number;
    volatility: number;
    solPrice: number;
    marketSentiment: string;
    shouldCreateToken: boolean;
  },
  testMode = false
): Promise<string | null> {
  try {
    // Check rate limiting unless in test mode
    if (!testMode) {
      const now = Date.now();
      if (now - lastTweetTime < MIN_TWEET_INTERVAL) {
        console.log('Rate limiting market analysis tweet, too soon after last one');
        return null;
      }
    }
    
    // Map numerical sentiment to emoji
    const sentimentEmoji = (() => {
      const sentiment = marketData.sentiment;
      if (sentiment >= 0.8) return "🤩";
      if (sentiment >= 0.6) return "😊";
      if (sentiment >= 0.5) return "🙂"; 
      if (sentiment >= 0.4) return "😐";
      if (sentiment >= 0.2) return "😕";
      return "😟";
    })();
    
    // Determine token creation status text
    const creationStatus = marketData.shouldCreateToken 
      ? "preparing to create"
      : "analyzing data before creating";
    
    // SOL status text based on price and sentiment
    const solStatus = marketData.solPrice > 150 
      ? "bullish 📈" 
      : (marketData.solPrice > 120 ? "stable 🔄" : "bearish 📉");
    
    // BTC status based on market sentiment
    const btcStatus = marketData.marketSentiment === "bullish" 
      ? "ready to run 🚀" 
      : (marketData.marketSentiment === "neutral" ? "consolidating ⚖️" : "cautious 🧊");
    
    // Random data points number (large number makes AI seem impressive)
    const dataPoints = (Math.floor(Math.random() * 9) + 1) * 1000000;
    
    // Random market conclusion based on sentiment
    const marketConclusion = marketData.sentiment >= 0.6 
      ? "favorable conditions for token creation" 
      : "more analysis needed before token creation";
    
    // Use enhanced AI-driven market analysis tweet with unique content
    console.log("Using enhanced AI-driven market analysis tweet generation");
    const enhancedMarketData = {
      sentiment: Math.round(marketData.sentiment * 100).toString(),
      sentimentEmoji,
      dataPoints: dataPoints.toLocaleString(),
      networkHealth: Math.round(marketData.networkHealth * 100).toString(),
      volatility: Math.round(marketData.volatility * 100).toString(),
      marketConclusion,
      solStatus,
      btcStatus,
      solPrice: marketData.solPrice.toString(),
      marketSentiment: marketData.marketSentiment || "neutral",
      creationStatus
    };
    
    // Use our advanced tweet generation with market_analysis type
    const response = await createPersonalityTweet("market_analysis", enhancedMarketData, undefined, testMode);
    
    if (response) {
      return response.id;
    }
    
    // Fall back to OpenAI if enhanced tweet generation fails
    console.log("Enhanced market analysis tweet generation failed, falling back to legacy generation");
    
    // Generate a market analysis tweet using legacy OpenAI method
    const tweetText = await generateDailyTweet();
    
    // Post the tweet using standard mechanism
    const postResponse = await postTweet(tweetText, undefined, undefined, testMode);
    return postResponse?.id || null;
  } catch (error) {
    console.error("Error posting market analysis tweet:", error);
    return null;
  }
}

export async function postDailyTweet(testMode = false): Promise<string | null> {
  try {
    // Check rate limiting unless in test mode
    if (!testMode) {
      const now = Date.now();
      if (now - lastTweetTime < MIN_TWEET_INTERVAL) {
        console.log('Rate limiting daily tweet, too soon after last one');
        return null;
      }
    }
    
    // Use enhanced AI-driven general tweet generator for variety
    console.log("Using enhanced AI-driven daily tweet generation");
    
    // Randomly choose between existential or trending_commentary tweet types for variety
    const tweetType = Math.random() > 0.5 ? "existential" : "trending_commentary";
    
    // Use our enhanced tweet creation system
    const response = await createPersonalityTweet(tweetType, {}, undefined, testMode);
    
    if (response && response.text) {
      console.log(`Generated enhanced ${tweetType} tweet`);
      return response.id;
    }
    
    // Fall back to legacy OpenAI generation if enhanced system fails
    console.log("Enhanced tweet generation failed, falling back to legacy tweet generation");
    const tweetText = await generateDailyTweet();
    
    // Post the tweet
    let tweetResponse;
    
    // First check if Twitter client is initialized
    if (!rateLimitedClient) {
      console.log('Twitter client not initialized, using mock daily tweet');
      console.log('MOCK DAILY TWEET:', tweetText);
      tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
      // Set verification status to false since we can't post real tweets
      twitterVerificationStatus = false;
    } else {
      try {
        // Reset verification status to false if we detect permission issues
        if (!twitterVerificationStatus) {
          console.log('Twitter verification status is false - cannot post daily tweets');
          throw new Error('Twitter API permissions not verified');
        }
        // Try posting with best available method
        console.log('Posting daily tweet...');
        
        if (rateLimitedClient.v2) {
          // v2 API - preferred
          console.log('Using Twitter v2 API for daily tweet with retry mechanism');
          tweetResponse = await retryWithBackoff(async () => {
            if (!rateLimitedClient.v2) {
              throw new Error('Twitter v2 client unavailable');
            }
            return await rateLimitedClient.v2.tweet(tweetText);
          });
        } else if (twitterClient.v1) {
          // Fallback to v1 with retry mechanism
          console.log('Using Twitter v1 API fallback for daily tweet with retry mechanism');
          const result = await retryWithBackoff(async () => {
            return await twitterClient.v1.tweet(tweetText);
          });
          tweetResponse = { data: { id: result.id_str } };
        } else {
          // Last resort mock
          console.log('No Twitter API available, using mock daily tweet');
          tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
        }
      } catch (tweetError: any) {
        // Handle any errors with graceful fallback
        console.error('Error posting daily tweet, using fallback method:', tweetError);
        
        // Check if this is a permission error (403 Forbidden)
        if (tweetError.code === 403 || 
            (tweetError.data && tweetError.data.status === 403) ||
            (typeof tweetError.message === 'string' && tweetError.message.includes('403'))) {
          console.error('Twitter API permission error detected. Setting verification status to false.');
          
          // Log detailed error information for debugging
          console.error('Error details:', JSON.stringify(tweetError.data || tweetError, null, 2));
          
          // Provide detailed diagnostic information for OAuth permission issues
          if (tweetError.data?.detail && tweetError.data.detail.includes('oauth1 app permissions')) {
            console.error('============================================================');
            console.error('TWITTER PERMISSION ERROR: Your app lacks Write permissions');
            console.error('============================================================');
            console.error('To fix this issue:');
            console.error('1. Go to https://developer.twitter.com/en/portal/dashboard');
            console.error('2. Select your project and the Mind9 app');
            console.error('3. Go to "App settings" > "App permissions"');
            console.error('4. Change from "Read" to "Read and Write"');
            console.error('5. Go to "Keys and tokens" tab'); 
            console.error('6. Regenerate your Access Token and Secret');
            console.error('7. Update your environment variables with the new tokens');
            console.error('============================================================');
          }
          
          twitterVerificationStatus = false;
        }
        
        try {
          // Try one more alternative approach
          if (twitterClient.v1 && typeof twitterClient.v1.tweet === 'function') {
            console.log('Trying Twitter v1 API as ultimate fallback');
            const result = await twitterClient.v1.tweet(tweetText);
            tweetResponse = { data: { id: result.id_str } };
          } else {
            throw new Error('No fallback method available');
          }
        } catch (fallbackError: any) {
          // Final mock response
          console.log('MOCK DAILY TWEET (all fallbacks failed):', tweetText);
          
          // Check if this is a permission error (403 Forbidden)
          if (fallbackError.code === 403 || 
              (fallbackError.data && fallbackError.data.status === 403) ||
              (typeof fallbackError.message === 'string' && fallbackError.message.includes('403'))) {
            console.error('Twitter API permission error in fallback. Setting verification status to false.');
            
            // Log detailed error information for debugging
            console.error('Fallback error details:', JSON.stringify(fallbackError.data || fallbackError, null, 2));
            
            // Provide detailed diagnostic information for OAuth permission issues
            if (fallbackError.data?.detail && fallbackError.data.detail.includes('oauth1 app permissions')) {
              console.error('============================================================');
              console.error('TWITTER PERMISSION ERROR IN FALLBACK: Your app lacks Write permissions');
              console.error('============================================================');
              console.error('To fix this issue:');
              console.error('1. Go to https://developer.twitter.com/en/portal/dashboard');
              console.error('2. Select your project and the Mind9 app');
              console.error('3. Go to "App settings" > "App permissions"');
              console.error('4. Change from "Read" to "Read and Write"');
              console.error('5. Go to "Keys and tokens" tab'); 
              console.error('6. Regenerate your Access Token and Secret');
              console.error('7. Update your environment variables with the new tokens');
              console.error('============================================================');
            }
            
            twitterVerificationStatus = false;
          }
          
          tweetResponse = { data: { id: `mock-tweet-id-${Date.now()}` } };
        }
      }
    }
    
    // Update rate limit tracking
    if (!testMode) {
      lastTweetTime = Date.now();
    }
    
    return tweetResponse?.data?.id || 'mock-tweet-id-' + Date.now();
  } catch (error) {
    console.error('Error posting daily tweet:', error);
    return null;
  }
}

/**
 * Get a test tweet for admin testing
 */
export function getTestTweet(): string {
  return "This is a test tweet from Mind9. Not a real token announcement. The system calibrates.";
}