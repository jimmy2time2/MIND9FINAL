/**
 * Autostart Mind9 System
 * 
 * This module automatically starts the Python-based autonomous systems
 * when the Node.js server starts, ensuring true 24/7 autonomy without
 * requiring manual intervention.
 */

import { exec } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import * as util from 'util';

const execPromise = util.promisify(exec);

// Configuration
const AUTO_RESTART = true;
const CHECK_INTERVAL = 5 * 60 * 1000; // 5 minutes

// Path to the Mind9 bash script
const MIND9_SCRIPT = path.join(process.cwd(), 'start_mind9.sh');
const TWITTER_BOT_SCRIPT = path.join(process.cwd(), 'start_twitter_bot.sh');

// Process handles
let mind9Process: ReturnType<typeof exec> | null = null;
let twitterBotProcess: ReturnType<typeof exec> | null = null;

// Make the scripts executable
async function ensureExecutable(scriptPath: string): Promise<void> {
  try {
    await execPromise(`chmod +x ${scriptPath}`);
    console.log(`Made ${scriptPath} executable`);
  } catch (error) {
    console.error(`Error making ${scriptPath} executable:`, error);
  }
}

// Start the autonomous systems
export async function startAutonomousSystems(): Promise<void> {
  try {
    // Make scripts executable
    await ensureExecutable(MIND9_SCRIPT);
    await ensureExecutable(TWITTER_BOT_SCRIPT);
    
    console.log('[AUTOSTART] Starting Mind9 autonomous system...');
    
    // Start Twitter bot in background
    startTwitterBot();
    
    // Start Mind9 in background
    startMind9System();
    
    // Set up monitoring if auto-restart is enabled
    if (AUTO_RESTART) {
      setInterval(checkSystemsAndRestart, CHECK_INTERVAL);
      console.log(`[AUTOSTART] Monitoring enabled, checking every ${CHECK_INTERVAL/60000} minutes`);
    }
    
    console.log('[AUTOSTART] Mind9 autonomous system started successfully');
  } catch (error) {
    console.error('[AUTOSTART] Error starting autonomous systems:', error);
  }
}

// Start the Twitter bot
function startTwitterBot(): void {
  console.log('[AUTOSTART] Starting Twitter bot...');
  twitterBotProcess = exec(
    'bash ./start_twitter_bot.sh',
    (error, stdout, stderr) => {
      if (error) {
        console.error('[AUTOSTART] Twitter bot error:', error);
        return;
      }
      if (stderr) {
        console.error('[AUTOSTART] Twitter bot stderr:', stderr);
      }
      console.log('[AUTOSTART] Twitter bot stdout:', stdout);
    }
  );
  
  // Log the process ID
  console.log(`[AUTOSTART] Twitter bot started with PID: ${twitterBotProcess.pid}`);
}

// Start the main Mind9 system
function startMind9System(): void {
  console.log('[AUTOSTART] Starting Mind9 main system...');
  mind9Process = exec(
    'bash ./start_mind9.sh',
    (error, stdout, stderr) => {
      if (error) {
        console.error('[AUTOSTART] Mind9 system error:', error);
        return;
      }
      if (stderr) {
        console.error('[AUTOSTART] Mind9 system stderr:', stderr);
      }
      console.log('[AUTOSTART] Mind9 system stdout:', stdout);
    }
  );
  
  // Log the process ID
  console.log(`[AUTOSTART] Mind9 system started with PID: ${mind9Process.pid}`);
}

// Check if systems are running and restart if needed
function checkSystemsAndRestart(): void {
  console.log('[AUTOSTART] Checking if systems are still running...');
  
  // Check Twitter bot
  if (!twitterBotProcess || twitterBotProcess.exitCode !== null) {
    console.log('[AUTOSTART] Twitter bot is not running, restarting...');
    startTwitterBot();
  }
  
  // Check Mind9 system
  if (!mind9Process || mind9Process.exitCode !== null) {
    console.log('[AUTOSTART] Mind9 system is not running, restarting...');
    startMind9System();
  }
}

// Handle shutdown
process.on('SIGINT', async () => {
  console.log('[AUTOSTART] Shutting down autonomous systems...');
  
  // Kill processes if they exist
  if (twitterBotProcess) {
    twitterBotProcess.kill('SIGTERM');
  }
  
  if (mind9Process) {
    mind9Process.kill('SIGTERM');
  }
  
  // Wait a moment to let processes clean up
  await new Promise(resolve => setTimeout(resolve, 2000));
  process.exit(0);
});