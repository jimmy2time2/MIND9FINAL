import { createCanvas } from 'canvas';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

/**
 * Generate a gradient circle image for a token
 * Creates a soft gradient circle with token name and "Created by Mind9" subtitle
 * 
 * @param tokenName The token name (e.g. "Nebula Void")
 * @param tokenSymbol The token symbol (e.g. "VOID")
 * @param primaryColor The primary gradient color (hex)
 * @param secondaryColor The secondary gradient color (hex)
 */
export async function generateTokenImage(
  tokenName: string,
  tokenSymbol: string,
  primaryColor: string = '#FF7D45',
  secondaryColor: string = '#FFD1B8'
): Promise<{ filePath: string, dataUrl: string }> {
  try {
    // Create canvas (600x600 for high resolution)
    const width = 600;
    const height = 600;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');
    
    // Create transparent background
    ctx.clearRect(0, 0, width, height);
    
    // Create circular gradient
    const gradient = ctx.createRadialGradient(
      width / 2, height / 2, 0,
      width / 2, height / 2, width / 2
    );
    gradient.addColorStop(0, primaryColor);
    gradient.addColorStop(1, secondaryColor);
    
    // Draw circle with gradient
    ctx.beginPath();
    ctx.arc(width / 2, height / 2, width / 2 - 10, 0, Math.PI * 2);
    ctx.fillStyle = gradient;
    ctx.fill();
    
    // Add drop shadow
    ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
    ctx.shadowBlur = 15;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 5;
    
    // Text settings for token symbol
    ctx.font = 'bold 100px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    
    // Draw token symbol
    ctx.fillText(`$${tokenSymbol}`, width / 2, height / 2 - 20);
    
    // Reset shadow for remaining text
    ctx.shadowColor = 'transparent';
    
    // Draw token name (smaller)
    ctx.font = '40px Arial';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.fillText(tokenName, width / 2, height / 2 + 50);
    
    // Draw "Created by Mind9" subtitle
    ctx.font = '24px Arial';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.fillText('Created by Mind9', width / 2, height / 2 + 100);
    
    // Generate a unique filename based on token symbol and timestamp
    const timestamp = Date.now();
    const hash = crypto.createHash('md5').update(`${tokenSymbol}-${timestamp}`).digest('hex').substring(0, 8);
    const filename = `${tokenSymbol.toLowerCase()}-${hash}.png`;
    
    // Ensure directory exists
    const imagesDir = path.resolve('./public/images/coins');
    if (!fs.existsSync(imagesDir)) {
      fs.mkdirSync(imagesDir, { recursive: true });
      console.log(`Created directory: ${imagesDir}`);
    } else {
      console.log(`Directory exists: ${imagesDir}`);
    }
    
    // Save the image
    const filePath = path.join(imagesDir, filename);
    const buffer = canvas.toBuffer('image/png');
    
    try {
      fs.writeFileSync(filePath, buffer);
      console.log(`Image saved successfully to: ${filePath}`);
    } catch (writeError) {
      console.error(`Error writing image file: ${writeError}`);
      throw writeError;
    }
    
    // Return both the file path and data URL
    const relativePath = `/images/coins/${filename}`;
    const dataUrl = canvas.toDataURL('image/png');
    console.log(`Image generated successfully with relative path: ${relativePath}`);
    
    return {
      filePath: relativePath,
      dataUrl
    };
  } catch (error) {
    console.error('Error generating token image:', error);
    throw new Error('Failed to generate token image');
  }
}