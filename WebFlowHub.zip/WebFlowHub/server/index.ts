import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import dotenv from "dotenv";
import { startAutonomousSystems as startAutoSystems } from "./autostart";
import { startMonitor } from "./monitor";
import { setupStaticRoutes } from "./static-routes";

// Load environment variables from .env file
dotenv.config();

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Set up static routes for serving images
  setupStaticRoutes(app);
  
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
    
    // Run cleanup script for test coins on production startup
    if (process.env.NODE_ENV === 'production') {
      log('Production environment detected, running cleanup script...');
      runCleanupScript();
    }
    
    // Auto-start the autonomous systems using both the original and enhanced approaches
    // This dual-approach ensures the system runs even if one method fails
    startAutonomousSystems();
    
    // Also use the enhanced auto-start system with auto-recovery
    startAutoSystems().catch(err => {
      log(`Error in enhanced autonomous system startup: ${err.message}`, 'error');
      // If enhanced system fails, the original system will still be running
    });
    
    // Start the persistent system monitor that runs continuously
    // This ensures processes are restarted if they crash, even after server restarts
    startMonitor().catch(err => {
      log(`Error starting system monitor: ${err instanceof Error ? err.message : 'Unknown error'}`, 'error');
    });
    
    log('Mind9 TRULY AUTONOMOUS system is now operational');
  });
})();

/**
 * Start the autonomous systems including Twitter bot and token creation
 */
function startAutonomousSystems() {
  // Start the Twitter bot
  startTwitterBot();
  
  // Start the autonomous token monitor
  startAutonomousTokenMonitor();
}

/**
 * Run cleanup script for test coins
 */
function runCleanupScript() {
  try {
    import('child_process').then(({ spawn }) => {
      log('Running test coin cleanup script...');
      
      // Force the cleanup with --force flag regardless of NODE_ENV
      const cleanupProcess = spawn('python3', ['cleanup_test_coins.py', '--force'], {
        stdio: 'inherit'
      });
      
      cleanupProcess.on('close', (code: number) => {
        if (code === 0) {
          log('Test coin cleanup completed successfully');
        } else {
          log(`Test coin cleanup failed with code ${code}`, 'error');
        }
      });
    }).catch(err => {
      log(`Error starting cleanup script: ${err.message}`, 'error');
    });
  } catch (error: unknown) {
    if (error instanceof Error) {
      log(`Error running cleanup script: ${error.message}`, 'error');
    } else {
      log('Unknown error during cleanup', 'error');
    }
  }
}

/**
 * Start the autonomous token monitor that creates tokens based on market analysis
 */
function startAutonomousTokenMonitor() {
  try {
    import('child_process').then(({ spawn }) => {
      import('fs').then((fs) => {
        // Check if the process is already running
        const checkProcess = spawn('ps', ['aux']);
        let processData = '';
        
        checkProcess.stdout.on('data', (data: Buffer) => {
          processData += data.toString();
        });
        
        checkProcess.on('close', (_code: number) => {
          // If no existing mind9 autonomous process is running
          if (!processData.includes('main.py')) {
            log('Starting Mind9A autonomous token system...');
            
            // Start the autonomous system as a detached process
            const autonomousSystem = spawn('python3', ['main.py'], {
              detached: true,
              stdio: ['ignore', 
                      fs.openSync('./mind9.log', 'a'), 
                      fs.openSync('./mind9_error.log', 'a')]
            });
            
            // Unref the process so it can run independently of the parent
            autonomousSystem.unref();
            
            log('Mind9 autonomous system started successfully');
          } else {
            log('Mind9 autonomous system is already running');
          }
        });
      }).catch(err => {
        log(`Error importing fs module: ${err.message}`, 'error');
      });
    }).catch(err => {
      log(`Error importing child_process module: ${err.message}`, 'error');
    });
  } catch (error: unknown) {
    if (error instanceof Error) {
      log(`Error starting autonomous system: ${error.message}`, 'error');
    } else {
      log('Unknown error during autonomous system startup', 'error');
    }
  }
}

/**
 * Start the Twitter bot as a background process
 */
function startTwitterBot() {
  try {
    import('child_process').then(({ spawn }) => {
      import('fs').then((fs) => {
        // Check if there's an existing bot process running
        const checkProcess = spawn('ps', ['aux']);
        let processData = '';
        
        checkProcess.stdout.on('data', (data: Buffer) => {
          processData += data.toString();
        });
        
        checkProcess.on('close', (_code: number) => {
          // If there's no existing twitter bot process running
          if (!processData.includes('run_twitter_bot.py')) {
            log('Starting Twitter bot in background...');
            
            // Start the Twitter bot as a detached process
            const twitterBot = spawn('python3', ['run_twitter_bot.py'], {
              detached: true,
              stdio: ['ignore', 
                      fs.openSync('./twitter_bot.log', 'a'), 
                      fs.openSync('./twitter_bot_error.log', 'a')]
            });
            
            // Unref the process so it can run independently of the parent
            twitterBot.unref();
            
            log('Twitter bot started successfully');
          } else {
            log('Twitter bot is already running');
          }
        });
      }).catch(err => {
        log(`Error importing fs module: ${err.message}`, 'error');
      });
    }).catch(err => {
      log(`Error importing child_process module: ${err.message}`, 'error');
    });
  } catch (error: unknown) {
    if (error instanceof Error) {
      log(`Error starting Twitter bot: ${error.message}`, 'error');
    } else {
      log('Unknown error starting Twitter bot', 'error');
    }
  }
}
