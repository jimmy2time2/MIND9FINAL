import express from 'express';
import path from 'path';
import fs from 'fs';

/**
 * Sets up routes for serving static assets including generated coin images
 * 
 * @param app Express application instance
 */
export function setupStaticRoutes(app: express.Express) {
  // Set up the route to serve generated coin images
  const generatedImagesDir = path.resolve(process.cwd(), 'generated_images');
  
  // Create the directory if it doesn't exist
  if (!fs.existsSync(generatedImagesDir)) {
    fs.mkdirSync(generatedImagesDir, { recursive: true });
  }
  
  // Serve generated images under /img/coins path
  app.use('/img/coins', express.static(generatedImagesDir));
  
  // Set up shared routes for serving the public directory content
  const publicDir = path.resolve(process.cwd(), 'public');
  app.use('/public', express.static(publicDir));
  
  console.log(`Static routes set up for generated images: ${generatedImagesDir}`);
}