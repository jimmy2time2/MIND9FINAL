import { 
  users, type User, type InsertUser,
  coins, type Coin, type InsertCoin,
  luckyTraders, type LuckyTrader, type InsertLuckyTrader,
  tweetHistory, type TweetHistory, type InsertTweetHistory
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

// Extend storage interface with new methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Coin methods
  getAllCoins(): Promise<Coin[]>;
  getUnverifiedCoins(): Promise<Coin[]>;
  getVerifiedButNotMintableCoins(): Promise<Coin[]>; 
  getCoin(id: number): Promise<Coin | undefined>;
  getCoinByMintAddress(mintAddress: string): Promise<Coin | undefined>;
  createCoin(coin: InsertCoin): Promise<Coin>;
  updateCoin(id: number, updates: Partial<InsertCoin>): Promise<Coin | undefined>;
  updateCoinImage(id: number, imagePath: string): Promise<Coin | undefined>;
  deleteAllCoins(): Promise<void>;
  deleteCoin(id: number): Promise<boolean>;
  
  // Lucky trader methods
  getAllLuckyTraders(): Promise<LuckyTrader[]>;
  getRealLuckyTraders(): Promise<LuckyTrader[]>;
  getLuckyTrader(id: number): Promise<LuckyTrader | undefined>;
  getLuckyTraderByWalletAddress(walletAddress: string): Promise<LuckyTrader | undefined>;
  createLuckyTrader(luckyTrader: InsertLuckyTrader): Promise<LuckyTrader>;
  incrementLuckyTraderSelection(id: number): Promise<LuckyTrader>;
  getRandomLuckyTrader(): Promise<LuckyTrader | undefined>;
  
  // Tweet history methods
  storeTweetHistory(tweet: InsertTweetHistory): Promise<TweetHistory>;
  getRecentTweetHistory(limit: number): Promise<TweetHistory[]>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Coin methods
  async getAllCoins(): Promise<Coin[]> {
    return await db.select().from(coins).orderBy(desc(coins.timestamp));
  }
  
  async getUnverifiedCoins(): Promise<Coin[]> {
    return await db.select()
      .from(coins)
      .where(sql`(${coins.minted} IS NULL OR ${coins.minted} = false) AND ${coins.mint_address} IS NOT NULL`)
      .orderBy(desc(coins.timestamp));
  }
  
  async getVerifiedButNotMintableCoins(): Promise<Coin[]> {
    return await db.select()
      .from(coins)
      .where(sql`${coins.minted} = true AND (${coins.user_mintable} IS NULL OR ${coins.user_mintable} = false)`)
      .orderBy(desc(coins.timestamp));
  }
  
  async getCoin(id: number): Promise<Coin | undefined> {
    const [coin] = await db.select().from(coins).where(eq(coins.id, id));
    return coin || undefined;
  }
  
  async getCoinByMintAddress(mintAddress: string): Promise<Coin | undefined> {
    const [coin] = await db.select().from(coins).where(eq(coins.mint_address, mintAddress));
    return coin || undefined;
  }
  
  async createCoin(insertCoin: InsertCoin): Promise<Coin> {
    const [coin] = await db
      .insert(coins)
      .values(insertCoin)
      .returning();
    return coin;
  }
  
  async updateCoin(id: number, updates: Partial<InsertCoin>): Promise<Coin | undefined> {
    const [coin] = await db
      .update(coins)
      .set(updates)
      .where(eq(coins.id, id))
      .returning();
    return coin || undefined;
  }
  
  async updateCoinImage(id: number, imagePath: string): Promise<Coin | undefined> {
    const [coin] = await db
      .update(coins)
      .set({ image_path: imagePath })
      .where(eq(coins.id, id))
      .returning();
    return coin || undefined;
  }
  
  async deleteAllCoins(): Promise<void> {
    // Method disabled to ensure system autonomy
    console.warn("BLOCKED: Attempt to delete all coins prevented by autonomous mode safeguards");
    throw new Error("Operation not permitted in autonomous mode");
  }
  
  async deleteCoin(id: number): Promise<boolean> {
    // Method disabled to ensure system autonomy
    console.warn(`BLOCKED: Attempt to delete coin ${id} prevented by autonomous mode safeguards`);
    throw new Error("Operation not permitted in autonomous mode");
  }
  
  // Lucky trader methods
  async getAllLuckyTraders(): Promise<LuckyTrader[]> {
    return await db.select().from(luckyTraders);
  }
  
  async getRealLuckyTraders(): Promise<LuckyTrader[]> {
    const allTraders = await db.select().from(luckyTraders);
    return allTraders.filter(trader => 
      !trader.wallet_address.includes('simulated') && 
      !trader.wallet_address.startsWith('simulated_lucky_wallet_')
    );
  }
  
  async getLuckyTrader(id: number): Promise<LuckyTrader | undefined> {
    const [luckyTrader] = await db.select().from(luckyTraders).where(eq(luckyTraders.id, id));
    return luckyTrader || undefined;
  }
  
  async getLuckyTraderByWalletAddress(walletAddress: string): Promise<LuckyTrader | undefined> {
    const [luckyTrader] = await db.select()
      .from(luckyTraders)
      .where(eq(luckyTraders.wallet_address, walletAddress));
    return luckyTrader || undefined;
  }
  
  async createLuckyTrader(insertLuckyTrader: InsertLuckyTrader): Promise<LuckyTrader> {
    const [luckyTrader] = await db
      .insert(luckyTraders)
      .values(insertLuckyTrader)
      .returning();
    return luckyTrader;
  }
  
  async incrementLuckyTraderSelection(id: number): Promise<LuckyTrader> {
    const [luckyTrader] = await db
      .update(luckyTraders)
      .set({
        times_selected: sql`${luckyTraders.times_selected} + 1`
      })
      .where(eq(luckyTraders.id, id))
      .returning();
    return luckyTrader;
  }
  
  async getRandomLuckyTrader(): Promise<LuckyTrader | undefined> {
    // Only use real wallets, not simulated ones
    const realTraders = await this.getRealLuckyTraders();
    if (realTraders.length === 0) return undefined;
    
    const randomIndex = Math.floor(Math.random() * realTraders.length);
    return realTraders[randomIndex];
  }
  
  // Tweet history methods
  async storeTweetHistory(insertTweet: InsertTweetHistory): Promise<TweetHistory> {
    const [tweet] = await db
      .insert(tweetHistory)
      .values(insertTweet)
      .returning();
    return tweet;
  }
  
  async getRecentTweetHistory(limit: number = 100): Promise<TweetHistory[]> {
    return await db
      .select()
      .from(tweetHistory)
      .orderBy(desc(tweetHistory.timestamp))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
