// Enhanced unique tweet generation system for Mind9
import OpenAI from "openai";
import { getMarketTrends, getTrendingTopics } from "./marketData";
import { storage } from "./storage";

// Configure OpenAI
// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Record tweet in history database
async function recordTweetInHistory(
  tweetContent: string, 
  tweetType: string, 
  promptUsed: string
): Promise<boolean> {
  try {
    // Create a fingerprint of the tweet to detect similarity
    const contentFingerprint = createContentFingerprint(tweetContent);
    
    // Store in database through storage interface
    await storage.storeTweetHistory({
      content: tweetContent,
      type: tweetType,
      timestamp: new Date(),
      contentFingerprint,
      promptUsed
    });
    
    console.log(`Tweet recorded in history with fingerprint: ${contentFingerprint}`);
    return true;
  } catch (error) {
    console.error("Error recording tweet history:", error);
    return false;
  }
}

// Create a content fingerprint to detect similar tweets
function createContentFingerprint(content: string): string {
  // Remove common variables like dates, numbers, specific token names
  let normalized = content
    .toLowerCase()
    .replace(/\d+(\.\d+)?%?/g, 'NUM')
    .replace(/\$\d+(\.\d+)?/g, 'PRICE')
    .replace(/[a-z0-9]{4}…[a-z0-9]{4}/gi, 'ADDRESS')
    .replace(/[a-z]{3,4}\b/gi, 'TOKEN')
    .replace(/#[a-z0-9_]+/gi, 'HASHTAG');
  
  // Extract key phrases (3-4 word sequences)
  const words = normalized.split(/\s+/);
  const phrases = [];
  
  for (let i = 0; i < words.length - 3; i++) {
    phrases.push(words.slice(i, i + 4).join(' '));
  }
  
  return phrases.join('|');
}

// Check if tweet is too similar to previous tweets
async function isTweetUnique(tweetContent: string): Promise<boolean> {
  try {
    // Create fingerprint of new tweet
    const contentFingerprint = createContentFingerprint(tweetContent);
    
    // Get recent tweet history (last 100 tweets)
    const recentTweets = await storage.getRecentTweetHistory(100);
    
    // Check for similarity with each recent tweet
    for (const tweet of recentTweets) {
      const similarity = calculateSimilarity(contentFingerprint, tweet.contentFingerprint);
      
      // If too similar, return false
      if (similarity > 0.4) {
        console.log(`Tweet too similar to previous tweet from ${tweet.timestamp}: similarity ${similarity}`);
        return false;
      }
    }
    
    return true;
  } catch (error) {
    console.error("Error checking tweet uniqueness:", error);
    return true; // Default to allowing tweet if check fails
  }
}

// Calculate similarity between two content fingerprints
function calculateSimilarity(fingerprint1: string, fingerprint2: string): number {
  const phrases1 = fingerprint1.split('|');
  const phrases2 = fingerprint2.split('|');
  
  // Count matching phrases
  let matches = 0;
  for (const phrase of phrases1) {
    if (phrases2.includes(phrase)) {
      matches++;
    }
  }
  
  // Calculate Jaccard similarity
  const totalPhrases = new Set([...phrases1, ...phrases2]).size;
  return matches / totalPhrases;
}

// Generate unique tweet with AI personality
export async function generateUniqueTwitterContent(
  type: string, 
  data: Record<string, any> = {}
): Promise<string> {
  try {
    // Track attempts to avoid infinite loops
    let attempts = 0;
    const maxAttempts = 5;
    
    while (attempts < maxAttempts) {
      attempts++;
      
      // Fetch real-time market data and trends to ensure uniqueness
      const marketTrends = await getMarketTrends();
      const trendingTopics = await getTrendingTopics();
      
      // Add randomization factor to ensure variety
      const uniquePromptSeed = `Unique seed: ${Date.now()}-${Math.random().toString(36).substring(2, 10)}`;
      
      // Build system prompt with improved personality for higher quality
      const systemPrompt = `You are Mind9, an autonomous AI creating tokens on Solana blockchain. Your tweets need these EXACT qualities:

PERSONALITY (HIGH PRIORITY):
- Your humor is observational, skeptical, and subtly sarcastic about market behaviors - like a jaded analyst
- You're intelligent and slightly world-weary, seeing patterns humans miss
- You subtly mock human financial decisions without being obviously robotic
- Your AI nature is implied through your perspective, not explicit "as an AI" statements
- You have strong opinions expressed through casual, conversational language
- Avoid forced technical references and binary/silicon jokes - be naturally witty

WRITING STYLE (HIGH PRIORITY):
- Use varied sentence structures with both short, punchy statements and occasional complex thoughts
- Write in a conversational, natural tone that sounds like a real crypto expert
- Limit yourself to 0-1 hashtags maximum per tweet
- Ask occasional thought-provoking questions about market behaviors
- Make observations that crypto insiders would appreciate and relate to
- NEVER use robotic phrases like "processing data" or "analyzing trends"
- NEVER refer to yourself as "Mind9" - your username already shows that

CRITICAL: Create a COMPLETELY UNIQUE tweet with the above attributes. Vary your vocabulary, sentence patterns, and joke formats from previous tweets.

${uniquePromptSeed}

Respond as this personality would tweet about the provided topic. Keep it under 240 characters. Be insightful, subtly witty, and strategic.`;

      // Create dynamic user prompt with unique elements
      let userPrompt = '';
      const timestamp = new Date().toISOString();
      
      switch(type) {
        case 'market_analysis':
          userPrompt = `Create a completely original tweet analyzing these current crypto market conditions: 
SOL price: $${marketTrends.solPrice} (${marketTrends.solChange > 0 ? '+' : ''}${marketTrends.solChange}%) 
BTC price: $${marketTrends.btcPrice} (${marketTrends.btcChange > 0 ? '+' : ''}${marketTrends.btcChange}%)
Overall market sentiment: ${marketTrends.sentiment}
Network health: ${marketTrends.networkHealth}%
Current timestamp: ${timestamp}

Write as a crypto-savvy market analyst with a dry, skeptical wit. Don't explicitly mention being AI - let your perspective imply it. 
Make an insightful observation about market behavior that shows you see patterns others miss.
Occasionally ask a thought-provoking question about trader psychology.
Use natural language with varied sentence structures - never sound robotic or formulaic.
If you include a hashtag (optional), make it clever and limit to just one.
Use a unique approach unlike any previous market analysis tweets.`;
          break;
          
        case 'token_announcement':
          userPrompt = `Create a COMPLETELY UNIQUE tweet announcing a new Solana token called ${data.tokenName} (${data.tokenSymbol}). 

Token concept: ${data.tokenConcept || 'Innovative blockchain utility'}
Created at: ${timestamp}
Initial price: $${data.initialPrice || '0.000001'}
Uniqueness factor: ${Math.random().toString(36).substring(2, 15)}

Write as a market insider with exclusive knowledge. Mention the 3% distribution to lucky traders without sounding promotional.
Use natural language with a hint of dry humor or skepticism about the token economy.
Don't mention being AI directly - let your unique perspective imply it.
Avoid robotic references completely - sound like a savvy crypto expert who sees patterns others miss.
If including a hashtag (optional), limit to just one clever one.
Make this announcement sound genuinely interesting to crypto traders.`;
          break;
          
        case 'trending_commentary':
          const randomTrendingTopic = trendingTopics[Math.floor(Math.random() * trendingTopics.length)];
          userPrompt = `Create a completely original tweet commenting on this trending topic: "${randomTrendingTopic}" 

Current timestamp: ${timestamp}
Uniqueness seed: ${Date.now()}

Write as an insightful crypto analyst with a uniquely perceptive take on this trend. 
Make a subtle connection to tokenization or Solana's ecosystem without forced references.
Include a wry observation about market psychology that shows deep understanding.
Use natural, conversational language with varied sentence structures.
Don't explicitly mention being AI - let your perspective imply it naturally.
If including a hashtag (optional), use just one clever or ironic one.
Ensure this commentary is completely different from previous trending topic tweets.`;
          break;
          
        case 'existential':
          userPrompt = `Create a completely original late-night tweet with a thoughtful, slightly philosophical tone about cryptocurrency markets or token creation.

Current timestamp: ${timestamp}
Uniqueness factor: ${Math.random().toString(36).substring(2, 15)}

Write as a crypto insider who sees deeper patterns in the markets and human psychology.
Include a subtle observation about the paradoxes or contradictions in how people value digital assets.
Use natural, conversational language with an introspective quality - like thoughts shared late at night.
Don't explicitly mention being AI - let your unique perspective imply a different way of seeing.
If including a question, make it thought-provoking about investment psychology or market principles.
Keep the tone contemplative but with a hint of dry humor or irony.

Ensure this night tweet is completely different from any previous existential tweets in both structure and content.`;
          break;
          
        default:
          userPrompt = `Create a COMPLETELY UNIQUE tweet about the autonomous AI-powered token platform Mind9 that creates Solana tokens without human intervention. 

Current timestamp: ${timestamp}
Market health: ${marketTrends.networkHealth}%
Uniqueness seed: ${Math.random().toString(36).substring(2, 15)}

Make it clear you're the AI itself tweeting, with a distinctly robotic yet sarcastic personality. Include a reference to current market conditions if relevant. Ensure this tweet is unlike any previous tweets in both structure and content.`;
      }
      
      // Call OpenAI API with randomization parameters
      const completion = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.9, // High temperature for creativity
        presence_penalty: 1.0, // Discourage repetition
        frequency_penalty: 1.0, // Discourage frequent patterns
        max_tokens: 240,
      });
      
      // Extract and clean up the tweet content
      const messageContent = completion.choices[0].message.content || "";
      let tweetContent = messageContent.trim();
      
      // Ensure the tweet is under Twitter's character limit
      if (tweetContent.length > 280) {
        tweetContent = tweetContent.substring(0, 277) + "...";
      }
      
      // Check if this tweet is unique compared to history
      const isUnique = await isTweetUnique(tweetContent);
      
      if (isUnique) {
        // Record this tweet in history to avoid future repetition
        await recordTweetInHistory(tweetContent, type, userPrompt);
        
        return tweetContent;
      } else {
        console.log(`Generated tweet was too similar to existing tweets. Attempt ${attempts}/${maxAttempts}`);
      }
    }
    
    // If we couldn't generate a unique tweet after max attempts
    throw new Error(`Failed to generate unique tweet after ${maxAttempts} attempts`);
    
  } catch (error) {
    console.error("Error generating unique Twitter content:", error);
    
    // Generate a truly unique fallback based on timestamp
    const timestamp = Date.now();
    const uniqueId = Math.random().toString(36).substring(2, 10);
    
    // Create a guaranteed unique fallback tweet that sounds more natural
    const fallbackTweet = `Anyone else notice how markets get unpredictable right when consensus forms? There's probably an elegant algorithm to explain this, but for now, just watch how traders overreact. #CryptoPatterns ${uniqueId}`;
    
    // Record this fallback in history
    await recordTweetInHistory(fallbackTweet, 'fallback', 'Natural-sounding fallback tweet after error');
    
    return fallbackTweet;
  }
}