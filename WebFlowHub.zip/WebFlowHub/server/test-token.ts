import { mintToken } from './solana';

/**
 * Utility to test token creation without complex setup
 * This bypasses most of the platform requirements and just creates a simple token
 */
export async function createTestToken(name: string, symbol: string): Promise<{
  success: boolean;
  mintAddress?: string;
  error?: string;
}> {
  try {
    console.log(`Creating test token: ${name} (${symbol})`);
    
    // Simple token data structure
    const tokenData = {
      name,
      symbol,
      description: `${name} is a test token created by Mind9 AI`,
      totalSupply: "1000"  // Small supply for testing
    };
    
    // Create the actual token
    const result = await mintToken(tokenData);
    
    console.log(`Test token created successfully: ${result.mintAddress}`);
    
    return {
      success: true,
      mintAddress: result.mintAddress
    };
  } catch (error) {
    console.error("Error creating test token:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error)
    };
  }
}