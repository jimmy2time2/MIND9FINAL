"""
Database adapter for connecting to the Mind9 platform database.
This module integrates with the existing Mind9 database to monitor for new coins.
"""

import os
import json
import logging
from datetime import datetime
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('mind9_db_adapter')

# Try to import PostgreSQL connector
try:
    from psycopg2 import pool
    POSTGRES_AVAILABLE = True
except ImportError:
    logger.warning("psycopg2 not available. Will use SQLite for local development only.")
    POSTGRES_AVAILABLE = False
    import sqlite3

class Mind9DatabaseAdapter:
    def __init__(self):
        """Initialize database adapter for Mind9 platform"""
        self.db_url = os.getenv("DATABASE_URL")
        self.connection_pool = None
        self.tracked_coins_file = "tracked_coins.json"
        self.tracked_coins = self.load_tracked_coins()
        
        # Connect to database
        self.connect_to_db()
    
    def load_tracked_coins(self):
        """Load list of coins that have already been announced"""
        try:
            if os.path.exists(self.tracked_coins_file):
                with open(self.tracked_coins_file, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            logger.error(f"Error loading tracked coins: {e}")
            return []
    
    def save_tracked_coins(self):
        """Save list of tracked coins to avoid duplicate announcements"""
        try:
            with open(self.tracked_coins_file, 'w') as f:
                json.dump(self.tracked_coins, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving tracked coins: {e}")
    
    def connect_to_db(self):
        """Connect to the Mind9 database"""
        if self.db_url and POSTGRES_AVAILABLE:
            try:
                # Create a connection pool for efficiency
                self.connection_pool = pool.SimpleConnectionPool(1, 10, self.db_url)
                logger.info("Connected to Mind9 PostgreSQL database")
                return True
            except Exception as e:
                logger.error(f"Error connecting to PostgreSQL database: {e}")
                self.connection_pool = None
        else:
            logger.warning("Using SQLite for local development (not connected to Mind9 database)")
            # Create a local SQLite database for testing
            try:
                self.conn = sqlite3.connect("mind9_local.db")
                self.create_local_tables()
                return True
            except Exception as e:
                logger.error(f"Error creating local SQLite database: {e}")
                self.conn = None
        
        return False
    
    def create_local_tables(self):
        """Create local tables for testing when not connected to production database"""
        if hasattr(self, 'conn') and self.conn:
            try:
                cursor = self.conn.cursor()
                # Create a simplified version of the coins table
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS coins (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    mint_address TEXT NOT NULL,
                    description TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                ''')
                self.conn.commit()
                logger.info("Created local testing tables")
            except Exception as e:
                logger.error(f"Error creating local tables: {e}")
    
    def get_connection(self):
        """Get a database connection"""
        if self.connection_pool:
            return self.connection_pool.getconn()
        elif hasattr(self, 'conn') and self.conn:
            return self.conn
        return None
    
    def release_connection(self, conn):
        """Release a connection back to the pool"""
        if self.connection_pool and conn:
            self.connection_pool.putconn(conn)
    
    def check_for_new_coins(self):
        """Check for new coins in the database"""
        new_coins = []
        conn = None
        
        try:
            conn = self.get_connection()
            if not conn:
                logger.error("No database connection available")
                return []
            
            cursor = conn.cursor()
            
            if self.connection_pool:  # PostgreSQL
                # Query the actual Mind9 database
                query = """
                SELECT id, name, symbol, mint_address, description, timestamp
                FROM coins
                ORDER BY timestamp DESC
                LIMIT 10
                """
            else:  # SQLite
                query = """
                SELECT id, name, symbol, mint_address, description, timestamp
                FROM coins
                ORDER BY timestamp DESC
                LIMIT 10
                """
            
            cursor.execute(query)
            rows = cursor.fetchall()
            
            for row in rows:
                if self.connection_pool:  # PostgreSQL
                    coin = {
                        "id": row[0],
                        "name": row[1],
                        "symbol": row[2],
                        "mint_address": row[3],
                        "description": row[4],
                        "timestamp": row[5].isoformat() if row[5] else None
                    }
                else:  # SQLite
                    coin = {
                        "id": row[0],
                        "name": row[1],
                        "symbol": row[2],
                        "mint_address": row[3],
                        "description": row[4],
                        "timestamp": row[5]
                    }
                
                # Check if this coin has already been tracked
                if coin["mint_address"] not in [c["mint_address"] for c in self.tracked_coins]:
                    new_coins.append(coin)
                    # Add to tracked coins
                    self.tracked_coins.append({
                        "id": coin["id"],
                        "mint_address": coin["mint_address"],
                        "tracked_at": datetime.now().isoformat()
                    })
            
            # Save updated tracked coins
            if new_coins:
                self.save_tracked_coins()
            
        except Exception as e:
            logger.error(f"Error checking for new coins: {e}")
        finally:
            if conn and self.connection_pool:
                self.release_connection(conn)
        
        return new_coins
    
    def add_test_coin(self, name, symbol, description="A test coin"):
        """Add a test coin for local testing"""
        conn = None
        
        try:
            conn = self.get_connection()
            if not conn:
                logger.error("No database connection available")
                return None
            
            cursor = conn.cursor()
            mint_address = f"Sol{int(time.time())}"  # Generate a fake mint address
            
            if self.connection_pool:  # PostgreSQL
                query = """
                INSERT INTO coins (name, symbol, mint_address, description, timestamp)
                VALUES (%s, %s, %s, %s, NOW())
                RETURNING id
                """
                cursor.execute(query, (name, symbol, mint_address, description))
                id = cursor.fetchone()[0]
            else:  # SQLite
                query = """
                INSERT INTO coins (name, symbol, mint_address, description)
                VALUES (?, ?, ?, ?)
                """
                cursor.execute(query, (name, symbol, mint_address, description))
                conn.commit()
                id = cursor.lastrowid
            
            logger.info(f"Added test coin: {name} ({symbol})")
            
            return {
                "id": id,
                "name": name,
                "symbol": symbol,
                "mint_address": mint_address,
                "description": description,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error adding test coin: {e}")
            return None
        finally:
            if conn and self.connection_pool:
                self.release_connection(conn)


# For testing
if __name__ == "__main__":
    adapter = Mind9DatabaseAdapter()
    
    # Add a test coin
    test_coin = adapter.add_test_coin("TestCoin", "TEST", "A test coin for the Mind9 system")
    if test_coin:
        print(f"Added test coin: {test_coin}")
    
    # Check for new coins
    new_coins = adapter.check_for_new_coins()
    if new_coins:
        print(f"Found {len(new_coins)} new coins:")
        for coin in new_coins:
            print(f"- {coin['name']} ({coin['symbol']}): {coin['mint_address']}")
    else:
        print("No new coins found")