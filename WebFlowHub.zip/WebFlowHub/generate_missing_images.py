#!/usr/bin/env python3
"""
Generate Missing Images for Mind9 Coins

This script automatically identifies coins without images in the database
and generates appropriate images for them using the CoinImageGenerator.
"""

import os
import sys
import logging
import psycopg2
from dotenv import load_dotenv
from image_generator import CoinImageGenerator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("missing_images.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("missing_images")

def connect_to_db():
    """Connect to the PostgreSQL database"""
    load_dotenv()
    
    # Get database connection info from environment variables
    db_url = os.getenv("DATABASE_URL")
    
    if not db_url:
        logger.error("DATABASE_URL environment variable not set")
        sys.exit(1)
    
    try:
        conn = psycopg2.connect(db_url)
        logger.info("Connected to database successfully")
        return conn
    except Exception as e:
        logger.error(f"Error connecting to database: {e}")
        sys.exit(1)

def get_coins_without_images(conn):
    """Get all coins without images from the database"""
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT id, name, symbol FROM coins WHERE image_path IS NULL OR image_path = ''")
            return cur.fetchall()
    except Exception as e:
        logger.error(f"Error fetching coins without images: {e}")
        return []

def update_coin_image(conn, coin_id, image_path):
    """Update coin record with image path"""
    try:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE coins SET image_path = %s WHERE id = %s",
                (image_path, coin_id)
            )
            conn.commit()
            logger.info(f"Updated coin ID {coin_id} with image path: {image_path}")
            return True
    except Exception as e:
        logger.error(f"Error updating coin ID {coin_id} with image: {e}")
        conn.rollback()
        return False

def generate_unique_colors_for_symbol(symbol):
    """Generate unique gradient colors based on the coin symbol"""
    # Create a deterministic hash from the symbol to generate consistent colors
    symbol_hash = sum(ord(c) * (i + 1) for i, c in enumerate(symbol)) % 1000
    
    # Use the hash to determine the hue in HSV color space
    # This ensures visually distinctive colors for different symbols
    hue = (symbol_hash % 360) / 360.0
    
    # Convert HSV to RGB for primary color (more saturated, bright)
    import colorsys
    r1, g1, b1 = colorsys.hsv_to_rgb(hue, 0.8, 0.95)
    
    # Secondary color is a lighter version of the same hue
    r2, g2, b2 = colorsys.hsv_to_rgb(hue, 0.4, 0.98)
    
    # Convert to hex
    primary = "#{:02x}{:02x}{:02x}".format(int(r1*255), int(g1*255), int(b1*255))
    secondary = "#{:02x}{:02x}{:02x}".format(int(r2*255), int(g2*255), int(b2*255))
    
    return primary, secondary

def generate_all_missing_images():
    """Generate images for all coins missing images in the database"""
    conn = connect_to_db()
    coins_without_images = get_coins_without_images(conn)
    
    if not coins_without_images:
        logger.info("No coins missing images found")
        return
    
    logger.info(f"Found {len(coins_without_images)} coins without images")
    
    # Create image generator
    generator = CoinImageGenerator()
    
    # Process each coin
    for coin_id, name, symbol in coins_without_images:
        logger.info(f"Generating image for coin: {symbol} ({name})")
        
        # Format the coin name for the image
        display_name = f"${symbol}"
        
        # Generate unique colors based on the symbol
        primary_color, secondary_color = generate_unique_colors_for_symbol(symbol)
        
        try:
            # Generate the image
            file_path, _ = generator.generate_coin_image(
                display_name, 
                primary_color=primary_color,
                secondary_color=secondary_color
            )
            
            # Update the database with the new image path
            update_coin_image(conn, coin_id, file_path)
            
        except Exception as e:
            logger.error(f"Error generating image for {symbol}: {e}")
    
    logger.info("Image generation complete")
    conn.close()

if __name__ == "__main__":
    logger.info("Starting generation of missing coin images")
    generate_all_missing_images()
    logger.info("Finished generating missing coin images")