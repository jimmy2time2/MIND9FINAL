#!/bin/bash

# Health check script for Mind9
# This script checks if all Mind9 services are running and restarts them if not

echo "Mind9 Health Monitor Started"
echo "Checking services every 5 minutes..."

# Function to check and restart a service
check_and_restart() {
  local service_name=$1
  local service_pattern=$2
  local restart_command=$3
  
  if ! pgrep -f "$service_pattern" > /dev/null; then
    echo "[$(date)] $service_name not running, attempting restart..."
    eval "$restart_command"
    echo "[$(date)] $service_name restarted"
    return 1
  else
    echo "[$(date)] $service_name health check: OK"
    return 0
  fi
}

# Create file to track successful run
touch .health_monitor_running

# Set flag to indicate monitor is running
echo "$(date)" > .monitor_last_run

while true; do
  # Check if website is responding
  if ! curl -s http://localhost:5000 > /dev/null; then
    echo "[$(date)] Website not responding, attempting restart..."
    
    # Check if PM2 is installed
    if command -v pm2 &> /dev/null; then
      # Restart using PM2
      pm2 restart mind9-web
      echo "[$(date)] Website restarted with PM2"
    else
      # Restart using traditional method
      ./start_mind9.sh
      echo "[$(date)] Website restarted with traditional script"
    fi
  else
    echo "[$(date)] Website health check: OK"
  fi
  
  # Check if Twitter bot is running
  check_and_restart "Twitter bot" "python.*twitter_bot.py" "./restart_twitter_bot.sh > /dev/null 2>&1"
  
  # Check if Coin Promoter is running
  check_and_restart "Coin Promoter" "python.*coin_promoter.py" "./start_coin_promoter.sh > /dev/null 2>&1"
  
  # Check if main Mind9 system is running
  check_and_restart "Mind9 System" "python.*main.py" "nohup python main.py > mind9_autonomous.log 2>&1 &"
  
  # Update last run timestamp for other monitoring systems
  echo "$(date)" > .monitor_last_run
  
  # Wait 5 minutes before next check
  sleep 300
done