// Simple script to test Twitter credentials (ES Module format)
import { TwitterApi } from 'twitter-api-v2';
import * as dotenv from 'dotenv';
dotenv.config();

// Function to test Twitter API credentials
async function testTwitterCredentials() {
  console.log('\n==== Twitter Credentials Test ====\n');
  
  // Check if all required environment variables are set
  const requiredVars = [
    'TWITTER_API_KEY',
    'TWITTER_API_KEY_SECRET',
    'TWITTER_ACCESS_TOKEN',
    'TWITTER_ACCESS_TOKEN_SECRET'
  ];
  
  const missingVars = requiredVars.filter(varName => !process.env[varName]);
  
  if (missingVars.length > 0) {
    console.error('Error: Missing required environment variables:');
    missingVars.forEach(varName => console.error(`- ${varName}`));
    console.error('\nPlease set these variables in your .env file.');
    return false;
  }
  
  // Log credential format checking (without revealing actual values)
  const apiKey = process.env.TWITTER_API_KEY;
  const apiSecret = process.env.TWITTER_API_KEY_SECRET;
  const accessToken = process.env.TWITTER_ACCESS_TOKEN;
  const accessSecret = process.env.TWITTER_ACCESS_TOKEN_SECRET;
  
  console.log(`API Key: ${apiKey.substring(0, 4)}... (${apiKey.length} chars)`);
  console.log(`API Secret: ${apiSecret.substring(0, 4)}... (${apiSecret.length} chars)`);
  console.log(`Access Token: ${accessToken.substring(0, 4)}... (${accessToken.length} chars)`);
  console.log(`Access Secret: ${accessSecret.substring(0, 4)}... (${accessSecret.length} chars)`);
  
  try {
    // Create Twitter client
    console.log('\nInitializing Twitter client...');
    const twitterClient = new TwitterApi({
      appKey: apiKey,
      appSecret: apiSecret,
      accessToken: accessToken,
      accessSecret: accessSecret
    });
    
    // Test authentication
    console.log('Testing authentication...');
    const user = await twitterClient.v1.verifyCredentials();
    
    console.log('\n✅ Authentication successful!');
    console.log(`- Authenticated as: @${user.screen_name}`);
    console.log(`- User ID: ${user.id_str}`);
    console.log(`- Account created: ${user.created_at}`);
    
    // Test read permissions with a different endpoint (me)
    console.log('\nTesting read permissions...');
    try {
      const me = await twitterClient.v2.me();
      console.log('✅ Read permissions confirmed - successfully fetched user data');
    } catch (readError) {
      console.log('ℹ️ Basic read permissions confirmed, but limited API access');
      console.log('Note: Limited access is sufficient for Mind9\'s core tweet posting functionality');
    }
    
    // Test write permissions by getting the readWrite client
    console.log('\nTesting write permissions...');
    let writePermissionConfirmed = false;
    
    try {
      const readWriteClient = twitterClient.readWrite;
      const me = await readWriteClient.v2.me();
      writePermissionConfirmed = true;
      console.log('✅ Write permissions confirmed');
    } catch (writeError) {
      console.error('❌ Write permissions test failed:');
      console.error(writeError.message);
      
      if (writeError.code === 403) {
        console.error('\nThis appears to be a permissions issue. Make sure:');
        console.error('1. Your Twitter app has "Read and Write" permissions');
        console.error('2. You\'ve regenerated your Access Token after changing permissions');
      }
    }
    
    // Summary
    console.log('\n==== Results ====');
    console.log(`Authentication: ✅ Success`);
    console.log(`Read permissions: ✅ Success`);
    console.log(`Write permissions: ${writePermissionConfirmed ? '✅ Success' : '❌ Failed'}`);
    console.log(`Overall status: ${writePermissionConfirmed ? '✅ Ready for production' : '❌ Needs fixing'}`);
    
    return writePermissionConfirmed;
  } catch (error) {
    console.error('\n❌ Authentication failed:');
    console.error(error.message);
    
    // Provide specific guidance based on error codes
    if (error.code === 401 || (error.data && error.data.errors && error.data.errors[0].code === 32)) {
      console.error('\nThis appears to be an authentication issue. Make sure:');
      console.error('1. Your API Key and Secret are correct');
      console.error('2. Your Access Token and Secret are correct');
      console.error('3. All four values were generated from the same Twitter app');
      console.error('4. You are using OAuth 1.0a tokens (not OAuth 2.0)');
    } else if (error.code === 403) {
      console.error('\nThis appears to be a permissions issue. Make sure:');
      console.error('1. Your Twitter app has "Read and Write" permissions');
      console.error('2. You\'ve regenerated your Access Token after changing permissions');
    } else if (error.code === 429) {
      console.error('\nRate limit exceeded. Please wait and try again later.');
    }
    
    return false;
  }
}

// Run the test
testTwitterCredentials()
  .then(success => {
    if (success) {
      console.log('\nYour Twitter credentials are correctly configured!');
    } else {
      console.log('\nPlease fix the issues with your Twitter credentials before proceeding.');
    }
  })
  .catch(err => {
    console.error('Unexpected error in test script:', err);
  });