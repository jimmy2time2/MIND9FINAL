#!/bin/bash

# Deployment Fix Script for Mind9
# This script applies all necessary changes for proper 24/7 Replit Reserved VM deployment

echo "=================================================="
echo "  Mind9 24/7 Deployment Fix Script"
echo "=================================================="
echo ""

# Step 1: Remove duplicate deployment spec
echo "Step 1: Removing duplicate deployment spec..."
if [ -f ".replit.deploy" ]; then
  rm .replit.deploy
  echo "✓ Deleted .replit.deploy"
else
  echo "✓ No .replit.deploy file found"
fi

# Step 2: Create proper .replit file
echo "Step 2: Creating proper .replit file..."
cat > .replit.new << 'EOL'
run = "node dist/index.js"

[deployment]
deploymentTarget = "reservedvm"
build = ["sh", "-c", "npm ci && npm run build"]
run   = ["sh", "-c", "./start_persistent.sh"]

[[ports]]
localPort     = 5000
externalPort  = 80
name          = "Mind9-App"
protocol      = "http"
EOL
echo "✓ Created .replit.new (you will need to manually replace .replit with this file)"

# Step 3: Create persistent start script
echo "Step 3: Creating start_persistent.sh script..."
cat > start_persistent.sh << 'EOL'
#!/usr/bin/env bash
# Keep background workers + web server alive
npx pm2-runtime dist/index.js
EOL
chmod +x start_persistent.sh
echo "✓ Created and made executable start_persistent.sh"

# Step 4: Create proper replit.nix file
echo "Step 4: Creating proper replit.nix file..."
cat > replit.nix.new << 'EOL'
{ pkgs }: {
  deps = [
    pkgs.nodejs-20
    pkgs.libpng pkgs.cairo pkgs.pango pkgs.librsvg
    pkgs.pkg-config
  ];
}
EOL
echo "✓ Created replit.nix.new (you will need to manually replace replit.nix with this file)"

# Step 5: Show npm command to swap canvas
echo "Step 5: Instructions to swap canvas for pre-built binary..."
echo "Run this command to replace canvas with the pre-built version:"
echo "npm uninstall canvas && npm install --save npm:@napi-rs/canvas@^0.1.37 --force"

# Step 6: Show instructions for secrets
echo ""
echo "Step 6: Instructions for adding secrets..."
echo "Go to Replit → Secrets and add these keys:"
echo "OPENAI_API_KEY    = <your key>"
echo "SOLANA_PRIVATEKEY = <base58>"
echo "TWITTER_BEARER    = <token>"
echo ""

# Step 7: Commit instructions
echo "Step 7: Instructions to commit changes..."
echo "After applying all changes, commit them with:"
echo 'git add -A'
echo 'git commit -m "♻️  One-file manifest, Reserved VM, nix libs, prebuilt canvas"'
echo ""

# Step 8: Redeploy instructions
echo "Step 8: Redeployment instructions..."
echo "Click Deploy → Reserved VM → 0.5 GB tier → Redeploy now"
echo "Wait for log line: ✓ Deployment succeeded"
echo ""

# Step 9: Health check instructions
echo "Step 9: Post-deploy health check instructions..."
echo "Curl the public URL: curl -I https://<project>.replit.app | head -n1"
echo "Should return HTTP/1.1 200"
echo "Confirm background worker logs appear in: npm run pm2 logs"
echo ""

echo "=================================================="
echo "  Manual Steps Required"
echo "=================================================="
echo ""
echo "Since the tool doesn't allow direct editing of .replit and package.json,"
echo "you'll need to manually:"
echo ""
echo "1. Replace .replit with the contents of .replit.new"
echo "2. Replace replit.nix with the contents of replit.nix.new"
echo "3. Run the npm command to swap canvas for the pre-built version"
echo "4. Add the required secrets in the Replit Secrets panel"
echo ""
echo "After completing these steps, proceed with deployment."
echo "=================================================="