"""
Tweet embeddings utility for Mind9 Twitter bot.
Uses OpenAI embeddings to calculate similarity between tweets.
"""

import os
import json
import logging
import numpy as np
from openai import OpenAI

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('tweet_embeddings')

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def get_embedding(text):
    """
    Get embedding for a text using OpenAI's embeddings API.
    
    Args:
        text: The text to embed
        
    Returns:
        List of floats representing the embedding
    """
    try:
        response = client.embeddings.create(
            model="text-embedding-3-small",
            input=text
        )
        return response.data[0].embedding
    except Exception as e:
        logger.error(f"Error getting embedding: {e}")
        # Return a random embedding as fallback (not ideal but prevents crashes)
        fallback = np.random.randn(1536)
        return fallback / np.linalg.norm(fallback)  # Normalize

def compute_similarity(text1, text2):
    """
    Compute cosine similarity between two text snippets.
    
    Args:
        text1: First text
        text2: Second text
        
    Returns:
        Similarity score between 0 and 1
    """
    try:
        embedding1 = get_embedding(text1)
        embedding2 = get_embedding(text2)
        
        # Calculate cosine similarity
        similarity = np.dot(embedding1, embedding2) / (np.linalg.norm(embedding1) * np.linalg.norm(embedding2))
        return similarity
    except Exception as e:
        logger.error(f"Error computing similarity: {e}")
        return 0.0

# For testing
if __name__ == "__main__":
    test_text1 = "Bitcoin is showing strong resistance at the $65k level."
    test_text2 = "BTC has found support at $65,000, looking bullish."
    test_text3 = "The weather is really nice today in San Francisco."
    
    sim1 = compute_similarity(test_text1, test_text2)
    sim2 = compute_similarity(test_text1, test_text3)
    
    print(f"Similarity between similar crypto texts: {sim1:.3f}")
    print(f"Similarity between unrelated texts: {sim2:.3f}")