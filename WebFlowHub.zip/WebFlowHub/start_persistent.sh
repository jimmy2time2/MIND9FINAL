#!/usr/bin/env bash
# Keeps HTTP server + workers alive inside the Reserved VM
npx pm2-runtime dist/index.js