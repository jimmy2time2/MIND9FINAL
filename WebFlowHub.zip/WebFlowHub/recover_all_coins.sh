#!/bin/bash

# Script to recover all coins minted by your wallet but not showing in database

echo "==========================================="
echo "     Mind9 Coin Recovery Tool"
echo "==========================================="

# Compile and run the TypeScript recovery script
echo "Running coin recovery tool..."
echo ""

npx tsx recover_coins.ts

echo ""
echo "If you see errors above, try running:"
echo "npm install -g tsx"
echo "tsx recover_coins.ts"
echo ""
echo "Recovery complete!"