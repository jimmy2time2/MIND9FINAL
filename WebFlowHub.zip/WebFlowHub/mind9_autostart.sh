#!/bin/bash

# Mind9 Auto-Start Script
# This script is meant to be run at system boot to ensure complete persistence
# It can be added to /etc/rc.local or configured with crontab @reboot

# Record start time
echo "Mind9 autostart initiated at $(date)" > mind9_startup.log

# Change to the Mind9 directory
cd "$(dirname "$0")"
MIND9_DIR=$(pwd)
echo "Mind9 directory: $MIND9_DIR" >> mind9_startup.log

# Wait for network to be available
echo "Waiting for network..." >> mind9_startup.log
for i in {1..30}; do
  if ping -c 1 8.8.8.8 > /dev/null 2>&1; then
    echo "Network is available" >> mind9_startup.log
    break
  fi
  sleep 2
done

# Wait for database to be available
echo "Waiting for database..." >> mind9_startup.log
for i in {1..30}; do
  if pg_isready -h $PGHOST -p $PGPORT -U $PGUSER > /dev/null 2>&1; then
    echo "Database is available" >> mind9_startup.log
    break
  fi
  sleep 2
done

# Check for PM2
if command -v pm2 &> /dev/null; then
  echo "Using PM2 for process management" >> mind9_startup.log
  
  # Ensure PM2 is running its saved processes
  pm2 resurrect || pm2 start ecosystem.config.cjs
  
  echo "PM2 processes started:" >> mind9_startup.log
  pm2 list >> mind9_startup.log
else
  echo "PM2 not found, using traditional scripts" >> mind9_startup.log
  
  # Use traditional startup script
  bash ./start_all_services.sh >> mind9_startup.log 2>&1
fi

# Start health monitor in background
echo "Starting health monitor..." >> mind9_startup.log
nohup ./health_monitor.sh >> monitor.log 2>&1 &

echo "Mind9 startup completed at $(date)" >> mind9_startup.log
echo "All services should now be running persistently"