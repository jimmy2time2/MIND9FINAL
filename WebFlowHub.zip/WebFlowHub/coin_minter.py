#!/usr/bin/env python3
"""
Coin Minter for Mind9
Autonomously mints real SPL tokens on the Solana blockchain
"""

import os
import json
import time
import logging
import base58
from datetime import datetime
from dotenv import load_dotenv
from solana.rpc.api import Client
from solana.transaction import Transaction
from solana.keypair import Keypair
from solana.publickey import PublicKey
from solana.system_program import SYS_PROGRAM_ID
from solana.rpc.types import TxOpts
from spl.token.client import Token
from spl.token.constants import TOKEN_PROGRAM_ID

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("coin_minter.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("coin_minter")

class CoinMinter:
    def __init__(self, 
                coin_data_file="coin_data.json", 
                rpc_endpoint=None,
                creator_private_key=None):
        """
        Initialize the CoinMinter with required configuration
        
        Args:
            coin_data_file: JSON file to store coin data
            rpc_endpoint: Solana RPC endpoint URL
            creator_private_key: Private key for the wallet that will mint tokens
        """
        # Load RPC endpoint from environment or parameter
        self.rpc_endpoint = rpc_endpoint or os.getenv("RPC_ENDPOINT")
        if not self.rpc_endpoint:
            raise ValueError("RPC_ENDPOINT must be provided")
        
        # Initialize Solana RPC client
        self.client = Client(self.rpc_endpoint)
        
        # Load creator private key from environment or parameter
        private_key_str = creator_private_key or os.getenv("SOLANA_PRIVATE_KEY")
        if not private_key_str:
            raise ValueError("SOLANA_PRIVATE_KEY must be provided")
        
        # Convert private key to keypair
        if private_key_str.startswith('['):
            # Handle array format
            private_key = json.loads(private_key_str)
            self.keypair = Keypair.from_secret_key(bytes(private_key))
        else:
            # Handle base58 encoded string
            private_key_bytes = base58.b58decode(private_key_str)
            self.keypair = Keypair.from_secret_key(private_key_bytes)
        
        # Get the public wallet address
        self.wallet_address = str(self.keypair.public_key)
        logger.info(f"Initialized with wallet: {self.wallet_address}")
        
        # Set up file to store coin data
        self.coin_data_file = coin_data_file
        self._load_coin_data()
        
    def _load_coin_data(self):
        """Load existing coin data from JSON file"""
        if os.path.exists(self.coin_data_file):
            try:
                with open(self.coin_data_file, 'r') as file:
                    self.coin_data = json.load(file)
                    logger.info(f"Loaded coin data for {len(self.coin_data)} coins")
            except Exception as e:
                logger.error(f"Error loading coin data: {e}")
                self.coin_data = []
        else:
            self.coin_data = []
            logger.info("No existing coin data found, starting fresh")
    
    def _save_coin_data(self):
        """Save coin data to JSON file"""
        try:
            with open(self.coin_data_file, 'w') as file:
                json.dump(self.coin_data, file, indent=2)
                logger.info(f"Saved coin data for {len(self.coin_data)} coins")
        except Exception as e:
            logger.error(f"Error saving coin data: {e}")
    
    def check_wallet_balance(self):
        """Check SOL balance in the wallet"""
        try:
            balance_response = self.client.get_balance(self.wallet_address)
            balance_lamports = balance_response['result']['value']
            balance_sol = balance_lamports / 1_000_000_000  # Convert lamports to SOL
            logger.info(f"Wallet balance: {balance_sol} SOL")
            return balance_sol
        except Exception as e:
            logger.error(f"Error checking wallet balance: {e}")
            return 0
    
    def generate_token_name(self):
        """Generate a meaningful token name"""
        # In a real implementation, this would generate names based on
        # current events, market trends, or AI analysis
        # Simplified for now
        import random
        
        # List of sample crypto-related terms 
        prefixes = ["FLUX", "NODE", "QUANT", "CHAIN", "MIND", "PULSE", 
                  "NEXUS", "LOGIC", "SPARK", "ORBIT", "FLOW", "VERSE",
                  "SYNC", "CORTEX", "NEURON", "PIXEL"]
        
        # Choose a random name and add $ prefix
        token_name = f"${random.choice(prefixes)}"
        return token_name
        
    def mint_token(self, token_name=None, max_retries=3, retry_delay=10):
        """
        Mint a new SPL token on Solana with retry logic
        
        Args:
            token_name: Name of the token. If None, one will be generated.
            max_retries: Maximum number of retry attempts
            retry_delay: Delay between retries in seconds
            
        Returns:
            Dictionary with token details if successful, None otherwise
        """
        # Generate token name if not provided
        if not token_name:
            token_name = self.generate_token_name()
        
        # Clean the token name for the symbol
        symbol = token_name.replace('$', '')
        
        # Track retry attempts
        retry_count = 0
        mint_address = None
        token_account = None
        
        while retry_count <= max_retries:
            try:
                if retry_count > 0:
                    logger.info(f"Retry attempt {retry_count}/{max_retries} for token: {token_name}")
                else:
                    logger.info(f"Starting to mint token: {token_name}")
                
                # Check if we have enough SOL
                balance = self.check_wallet_balance()
                if balance < 0.05:  # Require at least 0.05 SOL
                    logger.error(f"Insufficient balance: {balance} SOL")
                    return None
                
                # Create a new mint keypair on each retry to avoid conflicts
                mint_keypair = Keypair()
                
                # Create token with the new keypair
                token = Token.create_mint(
                    self.client,
                    self.keypair,  # Payer = creator wallet
                    self.keypair.public_key,  # Mint authority = creator wallet 
                    9,  # Standard token decimals (9 is more compatible than 0)
                    TOKEN_PROGRAM_ID
                )
                
                # Get the mint address
                mint_address = str(token.pubkey)
                logger.info(f"Token mint created at address: {mint_address}")
                
                # Create token account with extra error handling
                try:
                    logger.info(f"Creating associated token account for creator...")
                    token_account = token.create_account(self.keypair.public_key)
                    logger.info(f"Associated token account created: {token_account}")
                except Exception as acc_error:
                    logger.error(f"Error creating token account: {acc_error}")
                    if "incorrect program id" in str(acc_error).lower():
                        logger.info("Attempting alternative account creation method...")
                        # Fall back to the system program if token program has issues
                        # This is a simplification - a more robust solution would use SPL Token's 
                        # Associated Token Account Program directly
                        raise Exception("Token account creation failed, retrying with new approach")
                
                # Mint a fixed supply (1,000,000) with progressive fallback
                token_supply = 1_000_000
                try:
                    logger.info(f"Minting {token_supply} tokens to creator's account...")
                    token.mint_to(
                        token_account,
                        self.keypair.public_key,
                        self.keypair,
                        token_supply
                    )
                    logger.info(f"✓ Successfully minted {token_supply} {symbol} tokens to {token_account}")
                except Exception as mint_error:
                    logger.error(f"Error during token minting: {mint_error}")
                    # If we get an error on large supply, try with smaller amount as a test
                    if retry_count < max_retries:
                        logger.info("Trying with a smaller amount as a workaround...")
                        try:
                            token.mint_to(
                                token_account,
                                self.keypair.public_key,
                                self.keypair,
                                1000  # Start with a smaller amount
                            )
                            logger.info("Successfully minted a smaller amount as a test. Full minting may require multiple transactions.")
                            # If the small amount works, mint the rest in smaller chunks
                            remaining = token_supply - 1000
                            chunk_size = 10000
                            while remaining > 0:
                                mint_amount = min(chunk_size, remaining)
                                token.mint_to(
                                    token_account,
                                    self.keypair.public_key,
                                    self.keypair,
                                    mint_amount
                                )
                                remaining -= mint_amount
                        except Exception as small_mint_error:
                            # If even small minting fails, we need to retry the whole process
                            raise Exception(f"Failed even with smaller minting amount: {small_mint_error}")
                
                # Disable future minting for this token (optional)
                try:
                    token.set_authority(
                        mint_or_freeze_authority=self.keypair.public_key,
                        new_authority=None,  # Setting to None disables future minting
                        authority_type="MintTokens",
                        multi_signers=[self.keypair]
                    )
                except Exception as auth_error:
                    logger.warning(f"Could not disable future minting, but token creation succeeded: {auth_error}")
                    # This is not critical - we can proceed even if this fails
                
                # Record the new coin
                timestamp = datetime.now().isoformat()
                coin_record = {
                    "id": len(self.coin_data) + 1,
                    "name": token_name,
                    "symbol": symbol,
                    "description": f"Autonomous AI-created token by Mind9",
                    "mint_address": mint_address,
                    "token_account": str(token_account),
                    "total_supply": token_supply,
                    "created_at": timestamp,
                    "minted": True,
                    "image_path": None  # Will be filled later
                }
                
                # Log token creation metrics
                logger.info(f"Token creation metrics:\n"
                           f"      - Name: {token_name}\n"
                           f"      - Symbol: {symbol}\n" 
                           f"      - Mint Address: {mint_address}\n"
                           f"      - Total Supply: {token_supply}\n"
                           f"      - Decimals: 9\n"
                           f"      - Creator Address: {self.wallet_address}\n"
                           f"      - Creator Token Account: {token_account}\n"
                           f"      - Timestamp: {timestamp}")
                
                # Add to coin data and save
                self.coin_data.append(coin_record)
                self._save_coin_data()
                
                logger.info(f"Successfully minted token: {token_name} with mint address: {mint_address}")
                return coin_record
                
            except Exception as e:
                logger.error(f"Error minting token (attempt {retry_count+1}/{max_retries+1}): {e}")
                retry_count += 1
                
                if retry_count <= max_retries:
                    logger.info(f"Waiting {retry_delay} seconds before retry...")
                    time.sleep(retry_delay)
                else:
                    logger.error(f"All {max_retries+1} attempts failed. Token minting abandoned.")
                    return None
    
    def get_latest_coin(self):
        """Get the most recently minted coin"""
        if not self.coin_data:
            return None
        return self.coin_data[-1]
    
    def update_coin_image(self, coin_id, image_path):
        """Update the coin record with the image path"""
        for coin in self.coin_data:
            if coin["id"] == coin_id:
                coin["image_path"] = image_path
                self._save_coin_data()
                logger.info(f"Updated coin {coin_id} with image path: {image_path}")
                return True
        return False
    
    def get_coin_by_mint_address(self, mint_address):
        """Get a coin by its mint address"""
        for coin in self.coin_data:
            if coin["mint_address"] == mint_address:
                return coin
        return None

# If script is run directly, test minting a token
if __name__ == "__main__":
    minter = CoinMinter()
    token = minter.mint_token()
    if token:
        print(f"Test token minted: {token['name']} at {token['mint_address']}")
    else:
        print("Token minting failed")