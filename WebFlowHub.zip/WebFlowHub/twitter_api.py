#!/usr/bin/env python3
"""
Twitter API Integration for Mind9
Handles posting tweets with images
"""

import os
import logging
import tweepy
import time
import json
import random
from datetime import datetime, timedelta
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("twitter_api.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("twitter_api")

class TwitterAPI:
    def __init__(self):
        """Initialize Twitter API with credentials"""
        # Load Twitter API credentials
        self.api_key = os.getenv("TWITTER_API_KEY")
        self.api_key_secret = os.getenv("TWITTER_API_KEY_SECRET")
        self.access_token = os.getenv("TWITTER_ACCESS_TOKEN")
        self.access_token_secret = os.getenv("TWITTER_ACCESS_TOKEN_SECRET")
        self.bearer_token = os.getenv("TWITTER_BEARER_TOKEN")
        
        # Check if credentials are available
        self._check_credentials()
        
        # Initialize API client
        self._init_api()
        
        # Initialize tweet tracking
        self.last_tweet_time = None
        self.daily_tweet_count = 0
        self.reset_day = datetime.now().day
        
        logger.info("Twitter API initialized")
    
    def _check_credentials(self):
        """Check if all required credentials are available"""
        missing = []
        if not self.api_key:
            missing.append("TWITTER_API_KEY")
        if not self.api_key_secret:
            missing.append("TWITTER_API_KEY_SECRET")
        if not self.access_token:
            missing.append("TWITTER_ACCESS_TOKEN")
        if not self.access_token_secret:
            missing.append("TWITTER_ACCESS_TOKEN_SECRET")
        if not self.bearer_token:
            missing.append("TWITTER_BEARER_TOKEN")
            
        if missing:
            error_msg = f"Missing Twitter credentials: {', '.join(missing)}"
            logger.error(error_msg)
            raise ValueError(error_msg)
    
    def _init_api(self):
        """Initialize Twitter API client"""
        # OAuth 1.0a authentication
        auth = tweepy.OAuth1UserHandler(
            self.api_key, 
            self.api_key_secret,
            self.access_token,
            self.access_token_secret
        )
        
        # Initialize Tweepy API v1.1 and v2
        self.api_v1 = tweepy.API(auth)
        self.api_v2 = tweepy.Client(
            bearer_token=self.bearer_token,
            consumer_key=self.api_key,
            consumer_secret=self.api_key_secret,
            access_token=self.access_token,
            access_token_secret=self.access_token_secret
        )
        
        try:
            # Verify credentials by getting the authenticated user
            me = self.api_v1.verify_credentials()
            logger.info(f"Authenticated as: @{me.screen_name}")
        except Exception as e:
            logger.error(f"Authentication failed: {e}")
            raise
    
    def _check_rate_limits(self):
        """Check and respect Twitter rate limits"""
        # Check if we're currently rate limited by Twitter API
        rate_limit_file = 'twitter_rate_limit.json'
        if os.path.exists(rate_limit_file):
            try:
                with open(rate_limit_file, 'r') as f:
                    rate_limit_info = json.load(f)
                    
                if rate_limit_info.get('rate_limited', False):
                    reset_time_str = rate_limit_info.get('reset_time')
                    if reset_time_str:
                        try:
                            reset_time = datetime.fromisoformat(reset_time_str)
                            now = datetime.now()
                            
                            if now < reset_time:
                                wait_time = (reset_time - now).total_seconds()
                                logger.warning(f"Twitter API rate limited. Reset at {reset_time_str} ({int(wait_time/60)} minutes from now)")
                                return False
                            else:
                                # Time has passed, we can try again
                                logger.info("Rate limit reset time has passed, attempting to clear rate limit status")
                                try:
                                    with open(rate_limit_file, 'w') as f:
                                        json.dump({'rate_limited': False}, f)
                                except Exception as e:
                                    logger.error(f"Error clearing rate limit status: {e}")
                        except:
                            logger.error(f"Could not parse reset time: {reset_time_str}")
            except:
                logger.error("Error reading rate limit file")
        
        if self.last_tweet_time:
            # Ensure at least 120 minutes (2 hours) between tweets to respect Twitter's daily limits
            elapsed = datetime.now() - self.last_tweet_time
            if elapsed < timedelta(minutes=120):
                wait_time = timedelta(minutes=120) - elapsed
                logger.info(f"Internal rate limit: waiting {int(wait_time.total_seconds()/60)} minutes")
                return False
        
        # Reset daily counter if it's a new day
        current_day = datetime.now().day
        if current_day != self.reset_day:
            logger.info(f"New day: resetting tweet counter")
            self.daily_tweet_count = 0
            self.reset_day = current_day
        
        # Check if we've reached the daily limit (max 10 tweets per day, well below Twitter's 17 limit)
        if self.daily_tweet_count >= 10:
            logger.warning("Daily tweet limit reached (10 tweets)")
            return False
        
        return True
    
    def post_tweet(self, text, image_path=None, max_retries=3):
        """
        Post a tweet with optional image and enhanced rate limit handling
        
        Args:
            text: Tweet text content
            image_path: Optional path to image file
            max_retries: Maximum number of retry attempts for rate limits
            
        Returns:
            Tweet ID if successful, None otherwise
        """
        # Check internal rate limits
        if not self._check_rate_limits():
            return None
            
        # Trim text if it's too long (Twitter limit is 280 chars)
        if len(text) > 280:
            text = text[:277] + "..."
            
        # Add jitter to avoid exact timing of requests
        jitter_seconds = random.uniform(1, 10)
        time.sleep(jitter_seconds)
            
        retry_count = 0
        base_wait_time = 120  # 2 minutes base wait time
        
        while retry_count <= max_retries:
            try:
                if image_path and os.path.exists(image_path):
                    # Upload image first (using v1 API)
                    media = self.api_v1.media_upload(image_path)
                    media_id = media.media_id
                    
                    # Post tweet with media (using v2 API)
                    response = self.api_v2.create_tweet(
                        text=text,
                        media_ids=[media_id]
                    )
                    tweet_id = response.data['id']
                    logger.info(f"Posted tweet with image: {tweet_id}")
                else:
                    # Post text-only tweet
                    response = self.api_v2.create_tweet(text=text)
                    tweet_id = response.data['id']
                    logger.info(f"Posted text tweet: {tweet_id}")
                
                # Update tracking
                self.last_tweet_time = datetime.now()
                self.daily_tweet_count += 1
                
                # Clear any saved rate limit info since we succeeded
                if os.path.exists('twitter_rate_limit.json'):
                    try:
                        with open('twitter_rate_limit.json', 'w') as f:
                            json.dump({'rate_limited': False}, f)
                    except:
                        pass
                
                return tweet_id
                
            except tweepy.TooManyRequests as e:
                # Handle rate limiting specifically
                retry_count += 1
                reset_time = None
                wait_seconds = base_wait_time * (2 ** retry_count)  # Exponential backoff
                
                try:
                    # Try to extract reset time from headers
                    if hasattr(e.response, 'headers') and 'x-rate-limit-reset' in e.response.headers:
                        reset_timestamp = int(e.response.headers['x-rate-limit-reset'])
                        reset_time = datetime.fromtimestamp(reset_timestamp)
                        reset_wait_seconds = max(1, (reset_time - datetime.now()).total_seconds())
                        
                        # Use the longer of calculated wait time or reset time
                        wait_seconds = max(wait_seconds, reset_wait_seconds + 10)  # Add 10s buffer
                        
                        logger.warning(f"Rate limit exceeded. Twitter API will reset at {reset_time}. Retry {retry_count}/{max_retries} in {wait_seconds/60:.1f} minutes")
                    else:
                        logger.warning(f"Rate limit exceeded. No reset time available. Retry {retry_count}/{max_retries} in {wait_seconds/60:.1f} minutes")
                    
                    # Save state indicating we're rate limited
                    with open('twitter_rate_limit.json', 'w') as f:
                        wait_until = (datetime.now() + timedelta(seconds=wait_seconds)).isoformat()
                        json.dump({
                            'rate_limited': True,
                            'reset_time': reset_time.isoformat() if reset_time else wait_until,
                            'retry': retry_count,
                            'max_retries': max_retries,
                            'last_error': str(e),
                            'pending_tweet': text[:50] + '...' if len(text) > 50 else text
                        }, f)
                except Exception as inner_e:
                    logger.error(f"Error processing rate limit information: {inner_e}")
                
                if retry_count <= max_retries:
                    logger.info(f"Waiting {wait_seconds} seconds before retry {retry_count}")
                    time.sleep(wait_seconds)
                else:
                    logger.error(f"Maximum retries ({max_retries}) reached, giving up")
                    return None
                    
            except Exception as e:
                # Handle any other errors including API errors
                logger.error(f"Error posting tweet: {e}")
                
                # Check if this might be a rate limit issue not caught by the tweepy exception
                if hasattr(e, 'response') and hasattr(e.response, 'status_code') and e.response.status_code == 429:
                    retry_count += 1
                    wait_seconds = base_wait_time * (2 ** retry_count)
                    
                    logger.warning(f"Detected rate limit (429) error not caught by tweepy.TooManyRequests. Retry {retry_count}/{max_retries}")
                    
                    # Save rate limit info
                    with open('twitter_rate_limit.json', 'w') as f:
                        wait_until = (datetime.now() + timedelta(seconds=wait_seconds)).isoformat()
                        json.dump({
                            'rate_limited': True,
                            'reset_time': wait_until,
                            'retry': retry_count,
                            'max_retries': max_retries,
                            'last_error': str(e),
                            'pending_tweet': text[:50] + '...' if len(text) > 50 else text
                        }, f)
                    
                    if retry_count <= max_retries:
                        logger.info(f"Waiting {wait_seconds} seconds before retry {retry_count}")
                        time.sleep(wait_seconds)
                    else:
                        logger.error(f"Maximum retries ({max_retries}) reached, giving up")
                        return None
                else:
                    # Non-rate limit error, log and return None
                    return None
        
        # If we get here, we've exceeded our retries
        return None
    
    def post_reply(self, text, tweet_id_to_reply_to, image_path=None, max_retries=3):
        """
        Post a reply to another tweet with enhanced rate limit handling
        
        Args:
            text: Reply text content
            tweet_id_to_reply_to: ID of tweet to reply to
            image_path: Optional path to image file
            max_retries: Maximum number of retry attempts for rate limits
            
        Returns:
            Tweet ID if successful, None otherwise
        """
        # Check internal rate limits
        if not self._check_rate_limits():
            return None
            
        # Trim text if it's too long (Twitter limit is 280 chars)
        if len(text) > 280:
            text = text[:277] + "..."
            
        # Add jitter to avoid exact timing of requests
        jitter_seconds = random.uniform(1, 10)
        time.sleep(jitter_seconds)
            
        retry_count = 0
        base_wait_time = 120  # 2 minutes base wait time
        
        while retry_count <= max_retries:
            try:
                if image_path and os.path.exists(image_path):
                    # Upload image first (using v1 API)
                    media = self.api_v1.media_upload(image_path)
                    media_id = media.media_id
                    
                    # Post reply with media (using v2 API)
                    response = self.api_v2.create_tweet(
                        text=text,
                        media_ids=[media_id],
                        in_reply_to_tweet_id=tweet_id_to_reply_to
                    )
                    tweet_id = response.data['id']
                    logger.info(f"Posted reply with image: {tweet_id}")
                else:
                    # Post text-only reply
                    response = self.api_v2.create_tweet(
                        text=text,
                        in_reply_to_tweet_id=tweet_id_to_reply_to
                    )
                    tweet_id = response.data['id']
                    logger.info(f"Posted text reply: {tweet_id}")
                
                # Update tracking
                self.last_tweet_time = datetime.now()
                self.daily_tweet_count += 1
                
                return tweet_id
                
            except tweepy.TooManyRequests as e:
                # Handle rate limiting specifically
                retry_count += 1
                reset_time = None
                wait_seconds = base_wait_time * (2 ** retry_count)  # Exponential backoff
                
                try:
                    # Try to extract reset time from headers
                    if hasattr(e.response, 'headers') and 'x-rate-limit-reset' in e.response.headers:
                        reset_timestamp = int(e.response.headers['x-rate-limit-reset'])
                        reset_time = datetime.fromtimestamp(reset_timestamp)
                        reset_wait_seconds = max(1, (reset_time - datetime.now()).total_seconds())
                        
                        # Use the longer of calculated wait time or reset time
                        wait_seconds = max(wait_seconds, reset_wait_seconds + 10)  # Add 10s buffer
                        
                        logger.warning(f"Rate limit exceeded. Twitter API will reset at {reset_time}. Retry {retry_count}/{max_retries} in {wait_seconds/60:.1f} minutes")
                    else:
                        logger.warning(f"Rate limit exceeded. No reset time available. Retry {retry_count}/{max_retries} in {wait_seconds/60:.1f} minutes")
                except Exception as inner_e:
                    logger.error(f"Error processing rate limit information: {inner_e}")
                
                if retry_count <= max_retries:
                    logger.info(f"Waiting {wait_seconds} seconds before retry {retry_count}")
                    time.sleep(wait_seconds)
                else:
                    logger.error(f"Maximum retries ({max_retries}) reached, giving up")
                    return None
                    
            except Exception as e:
                # Handle any other errors including API errors
                logger.error(f"Error posting reply: {e}")
                
                # Check if this might be a rate limit issue not caught by the tweepy exception
                if hasattr(e, 'response') and hasattr(e.response, 'status_code') and e.response.status_code == 429:
                    retry_count += 1
                    wait_seconds = base_wait_time * (2 ** retry_count)
                    
                    logger.warning(f"Detected rate limit (429) error not caught by tweepy.TooManyRequests. Retry {retry_count}/{max_retries}")
                    
                    if retry_count <= max_retries:
                        logger.info(f"Waiting {wait_seconds} seconds before retry {retry_count}")
                        time.sleep(wait_seconds)
                    else:
                        logger.error(f"Maximum retries ({max_retries}) reached, giving up")
                        return None
                else:
                    # Non-rate limit error, log and return None
                    return None
        
        # If we get here, we've exceeded our retries
        return None
    
    def get_account_mentions(self, count=10, max_retries=2):
        """
        Get recent mentions of the account with retry logic for rate limits
        
        Args:
            count: Maximum number of mentions to retrieve
            max_retries: Maximum number of retry attempts
            
        Returns:
            List of mentions if successful, empty list otherwise
        """
        retry_count = 0
        while retry_count <= max_retries:
            try:
                # Get user ID first
                me = self.api_v1.verify_credentials()
                user_id = me.id_str
                
                # Get mentions using v2 API
                mentions = self.api_v2.get_users_mentions(
                    id=user_id,
                    max_results=count
                )
                
                # Return data if available, empty list otherwise
                return mentions.data or []
                
            except tweepy.TooManyRequests as e:
                retry_count += 1
                if retry_count <= max_retries:
                    # Calculate wait time with exponential backoff
                    wait_seconds = 60 * (2 ** retry_count)
                    logger.warning(f"Rate limit hit when getting mentions. Retry {retry_count}/{max_retries} in {wait_seconds}s")
                    time.sleep(wait_seconds)
                else:
                    logger.error("Max retries reached when getting mentions")
                    return []
            except Exception as e:
                logger.error(f"Error getting mentions: {e}")
                
                # Check if this might be a rate limit issue
                if hasattr(e, 'response') and hasattr(e.response, 'status_code') and e.response.status_code == 429:
                    retry_count += 1
                    if retry_count <= max_retries:
                        wait_seconds = 60 * (2 ** retry_count)
                        logger.warning(f"Rate limit (429) when getting mentions. Retry {retry_count}/{max_retries} in {wait_seconds}s")
                        time.sleep(wait_seconds)
                    else:
                        return []
                else:
                    # Non-rate limit error
                    return []
                
        return []
    
    def get_tweet_by_id(self, tweet_id):
        """Get a tweet by its ID"""
        try:
            tweet = self.api_v2.get_tweet(tweet_id)
            return tweet.data
        except Exception as e:
            logger.error(f"Error getting tweet: {e}")
            return None

# If script is run directly, test authentication
if __name__ == "__main__":
    try:
        twitter = TwitterAPI()
        print("Twitter API authentication successful")
        
        # Post a test tweet
        test_tweet = twitter.post_tweet("This is a test tweet from Mind9 AI at " + 
                                        datetime.now().strftime("%Y-%m-%d %H:%M:%S") + 
                                        " - Please ignore.")
        if test_tweet:
            print(f"Test tweet posted with ID: {test_tweet}")
        else:
            print("Test tweet failed")
            
    except Exception as e:
        print(f"Error: {e}")