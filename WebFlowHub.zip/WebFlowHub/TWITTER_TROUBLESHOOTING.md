# Twitter API Troubleshooting Guide for Mind9

This guide provides detailed troubleshooting steps for common Twitter API issues in the Mind9 platform.

## Initial Diagnostics

Always start with the diagnostic endpoint to identify specific issues:

```bash
curl http://localhost:5000/api/admin/twitter/diagnose | json_pp
```

The response includes:
- Verification status
- Permission issues
- Username
- Read/write permission status
- Rate limit information
- Credential format validation

## Common Error Codes

### 401 Unauthorized

This indicates authentication problems with your credentials.

**Symptoms:**
- "Could not authenticate you" error message
- Failed initialization of Twitter client
- Unable to post tweets

**Solutions:**
1. **Regenerate all credentials together:**
   - Go to Twitter Developer Portal > Projects & Apps > Your App > Keys and tokens
   - Regenerate both Consumer Keys (API Key and Secret)
   - Regenerate Access Token and Secret
   - Update all four values in your `.env` file

2. **Check credential format:**
   - API Key: Usually 25 characters
   - API Secret: Usually 50 characters
   - Access Token: Usually 50 characters and numeric at the beginning
   - Access Secret: Usually 45 characters

3. **Verify OAuth version:**
   - Ensure you're using OAuth 1.0a tokens
   - Do not use OAuth 2.0 tokens for the Twitter bot

4. **Check system time:**
   - Twitter API is sensitive to time drift
   - Ensure server time is synchronized with NTP

### 403 Forbidden

This indicates permission problems with your app.

**Symptoms:**
- "Forbidden" error message
- Authentication works but posting fails
- Read operations work but write operations fail

**Solutions:**
1. **Update app permissions:**
   - Go to Twitter Developer Portal > Projects & Apps > Your App > App permissions
   - Change to "Read and Write" or "Read, Write, and Direct Messages"
   - Save changes
   - **Important:** After changing permissions, regenerate your Access Token and Secret

2. **Check app approval:**
   - Ensure your Twitter Developer Account has been approved for the necessary access levels
   - Basic tier accounts have limited API access

3. **Verify user context:**
   - The account that generated the Access Token must have appropriate permissions

### 429 Too Many Requests

This indicates rate limiting by Twitter.

**Symptoms:**
- "Rate limit exceeded" error message
- Works sometimes but fails during high activity periods

**Solutions:**
1. **Implement rate limit handling:**
   - Mind9 includes exponential backoff for rate limits
   - Review the retry logic in `server/twitter.ts`

2. **Adjust tweet frequency:**
   - Reduce scheduled tweets in `twitter_bot.py`
   - Ensure you're not exceeding Twitter's limits (currently ~200 tweets/day)

3. **Monitor rate limit headers:**
   - The diagnostics endpoint includes rate limit information
   - Track remaining requests to avoid hitting limits

## Specific Functional Issues

### Bot Not Posting Scheduled Tweets

**Check:**
1. Verify bot is running (`ps aux | grep twitter_bot`)
2. Check logs in `twitter_bot.log`
3. Validate schedule configuration in `tweet_schedule.json`
4. Test manual tweet posting with:
   ```bash
   curl -X POST http://localhost:5000/api/admin/test-twitter
   ```

### Coin Announcements Not Working

**Check:**
1. Verify database connection in `coin_checker.py`
2. Check if coin data format matches expected format
3. Test announcement with a manual coin entry
4. Verify image generation pipeline in `image_generator.py`

## Advanced Debugging

### Enable Debug Logging

For detailed logging:

1. Modify `.env` to include:
   ```
   TWITTER_DEBUG=true
   LOG_LEVEL=debug
   ```

2. Restart the server or reload with:
   ```bash
   curl -X POST http://localhost:5000/api/admin/twitter/reload-credentials
   ```

### Test Individual Components

1. **Twitter API only:**
   ```bash
   node test_twitter_credentials.mjs
   ```

2. **Twitter Bot only:**
   ```bash
   python test_twitter_bot.py
   ```

3. **Image generation only:**
   ```bash
   python image_generator.py test
   ```

## Recovering from Critical Failures

If Twitter integration is completely broken:

1. **Reset credentials:**
   - Regenerate all Twitter credentials
   - Update in `.env`
   - Run `curl -X POST http://localhost:5000/api/admin/twitter/reload-credentials`

2. **Check Python environment:**
   - Ensure all required packages are installed
   - Verify Python version compatibility (3.8+)

3. **Restart entire system:**
   - Stop all processes
   - Restart the Mind9 server
   - Restart the Twitter bot separately if needed

## Getting Help

If all troubleshooting steps fail:

1. Gather diagnostic information:
   ```bash
   curl http://localhost:5000/api/admin/twitter/diagnose > twitter_diagnostic.json
   ```

2. Collect logs:
   - `twitter_bot.log`
   - `twitter_api.log`
   - `twitter_bot_error.log`

3. Check Twitter API status: https://api.twitterstat.us/