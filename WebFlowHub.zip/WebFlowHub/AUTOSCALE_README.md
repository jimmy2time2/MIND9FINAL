
# Mind9 Autoscale Deployment Guide

## Important Information About Autoscale

Autoscale deployments require your application to:
1. Listen on a single port (5000 in our case)
2. Run in the foreground (not as background processes)
3. Not run background processes outside of request handling

## Current Configuration

The deployment has been configured to:
- Run only the web server component in the foreground
- Expose port 5000 and map it to external port 80
- Focus solely on the web application

## Background Services

For your autonomous systems (Twitter bot, coin promoter, etc.), you should:
1. Create a separate Reserved VM deployment for background processes
2. Move the autonomous systems to that deployment
3. Configure both deployments to share the same database

## Troubleshooting

If deployment still fails:
1. Check server logs for any errors
2. Ensure the server is binding to 0.0.0.0:5000
3. Verify the server starts quickly (under 60 seconds)
