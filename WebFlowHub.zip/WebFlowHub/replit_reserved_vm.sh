#!/bin/bash

# Mind9 Replit Reserved VM Persistent Setup
# This script configures Mind9 to run permanently on a Replit Reserved VM

echo "=================================================="
echo "  Mind9 Replit Reserved VM Persistent Setup"
echo "=================================================="
echo ""
echo "This script will set up Mind9 to run persistently on a Replit Reserved VM."
echo "Services will keep running even when you close the browser window."
echo ""

# Make all scripts executable
echo "Making scripts executable..."
chmod +x *.sh

# Create necessary directories
mkdir -p logs
mkdir -p generated_images

# Create a .replit file to execute this on run
echo "Creating Replit configuration..."
cat > .replit << EOL
run = "bash start_replit_services.sh"

[[ports]]
localPort = 5000
externalPort = 80
name = "Mind9 App"
protocol = "http"
hideOnBoot = false
EOL

# Create a start_replit_services.sh script
echo "Creating service starter script..."
cat > start_replit_services.sh << EOL
#!/bin/bash

# Start all Mind9 services and keep them running
echo "Starting Mind9 on Replit Reserved VM..."

# Kill any existing processes
pkill -f "npm run dev" || true
pkill -f "python.*twitter_bot.py" || true
pkill -f "python.*run_mind9.py" || true
pkill -f "python.*run_coin_promoter.py" || true
pkill -f "keep_services_running.sh" || true

# Start the web application with proper binding to 0.0.0.0
echo "Starting web application..."
export HOST=0.0.0.0
export PORT=5000
nohup npm run dev > logs/web_app.log 2>&1 &
echo "Web application started with PID: \$! (bound to 0.0.0.0:5000)"

# Find the correct Python path
PYTHON_PATH=$(which python3.11 || which python3 || which python || echo "python3")
echo "Using Python path: $PYTHON_PATH"

# Start the Twitter bot
echo "Starting Twitter bot..."
nohup $PYTHON_PATH -u run_twitter_bot.py > logs/twitter_bot_runner.log 2>&1 &
echo "Twitter bot started with PID: \$!"

# Start the Mind9 core system
echo "Starting Mind9 core system..."
nohup $PYTHON_PATH -u run_mind9.py > logs/mind9_runner.log 2>&1 &
echo "Mind9 core system started with PID: \$!"

# Start the Coin Promoter
echo "Starting Coin Promoter..."
nohup $PYTHON_PATH -u run_coin_promoter.py > logs/coin_promoter_runner.log 2>&1 &
echo "Coin Promoter started with PID: \$!"

# Start the service monitor
echo "Starting service monitor..."
nohup bash keep_services_running.sh > logs/service_monitor.log 2>&1 &
echo "Service monitor started with PID: \$!"

echo ""
echo "All Mind9 services started successfully!"
echo "The system will continue running even if you close this window."
echo "You can check the logs in the 'logs' directory."
echo ""
echo "Your Mind9 platform is now truly autonomous and persistent."
echo "=================================================="

# Keep the script running to prevent Replit from shutting down
while true; do
  # Check if web server is running on port 5000
  if ! netstat -tuln | grep -q ":5000 "; then
    echo "[$(date)] Web server not detected on port 5000, restarting..." >> logs/heartbeat.log
    export HOST=0.0.0.0
    export PORT=5000
    nohup npm run dev > logs/web_app.log 2>&1 &
    echo "[$(date)] Web application restarted with PID: $! (bound to 0.0.0.0:5000)" >> logs/heartbeat.log
  fi
  
  # Find the correct Python path (in case it changes)
  PYTHON_PATH=$(which python3.11 || which python3 || which python || echo "python3")
  
  # Check if Twitter bot is running
  if ! pgrep -f "run_twitter_bot.py" > /dev/null; then
    echo "[$(date)] Twitter bot not running, restarting..." >> logs/heartbeat.log
    nohup $PYTHON_PATH -u run_twitter_bot.py > logs/twitter_bot_runner.log 2>&1 &
    echo "[$(date)] Twitter bot restarted with PID: $!" >> logs/heartbeat.log
  fi
  
  # Check if Mind9 core is running
  if ! pgrep -f "run_mind9.py" > /dev/null; then
    echo "[$(date)] Mind9 core not running, restarting..." >> logs/heartbeat.log
    nohup $PYTHON_PATH -u run_mind9.py > logs/mind9_runner.log 2>&1 &
    echo "[$(date)] Mind9 core restarted with PID: $!" >> logs/heartbeat.log
  fi
  
  # Check if Coin Promoter is running
  if ! pgrep -f "run_coin_promoter.py" > /dev/null; then
    echo "[$(date)] Coin Promoter not running, restarting..." >> logs/heartbeat.log
    nohup $PYTHON_PATH -u run_coin_promoter.py > logs/coin_promoter_runner.log 2>&1 &
    echo "[$(date)] Coin Promoter restarted with PID: $!" >> logs/heartbeat.log
  fi
  
  echo "[$(date)] Mind9 is running autonomously on Replit Reserved VM" >> logs/heartbeat.log
  sleep 300  # Log heartbeat every 5 minutes
done
EOL

# Make the new script executable
chmod +x start_replit_services.sh

echo ""
echo "Setup complete! To start Mind9 in persistent mode:"
echo ""
echo "1. Use the Run button in Replit, or"
echo "2. Run './start_replit_services.sh' in the terminal"
echo ""
echo "Your Mind9 system will continue running even when you close the browser"
echo "or disconnect from Replit, as long as your Reserved VM remains active."
echo ""
echo "=================================================="

# Ask if user wants to start services now
read -p "Do you want to start Mind9 services now? (y/n): " start_now
if [[ $start_now == "y" || $start_now == "Y" ]]; then
  echo "Starting Mind9 services..."
  
  # Ensure port 5000 is properly configured for external access
  echo "Setting up port 5000 for external access..."
  
  # This will create a dummy server to ensure the port is properly registered
  echo "import http from 'http';
const server = http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('Mind9 Port Configuration Active\\n');
});
server.listen(5000, '0.0.0.0', () => {
  console.log('Port 5000 registered and ready');
});" > port_setup.js
  
  # Run the port setup script in the background briefly
  node port_setup.js &
  SETUP_PID=$!
  sleep 5
  kill $SETUP_PID || true
  
  # Start the actual services
  ./start_replit_services.sh
fi
#!/bin/bash

echo "=========================================="
echo "   Mind9 Reserved VM Configuration"
echo "=========================================="
echo ""

echo "This script will convert your deployment from Autoscale to Reserved VM,"
echo "which will allow your Mind9 system to run 24/7."
echo ""
read -p "Do you want to proceed? (y/n): " confirm

if [[ $confirm != "y" && $confirm != "Y" ]]; then
  echo "Operation cancelled."
  exit 0
fi

# Update the .replit file for Reserved VM configuration
echo "Updating deployment configuration..."

# Check if Nix is installed correctly
if ! command -v nix-shell &> /dev/null; then
  echo "Installing Nix dependencies..."
  mkdir -p ~/.config/nix
  echo "experimental-features = nix-command flakes" > ~/.config/nix/nix.conf
fi

# Install Node.js if not present
if ! command -v node &> /dev/null; then
  echo "Installing Node.js..."
  curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
  apt-get install -y nodejs
fi

# Update npm
echo "Updating npm..."
npm install -g npm@latest

# Install project dependencies
echo "Installing project dependencies..."
npm install

# Create a comprehensive startup script
cat > persistent_mind9.sh << 'EOF'
#!/bin/bash

echo "=========================================="
echo "   Mind9 Reserved VM Startup"
echo "=========================================="

# Create necessary directories
mkdir -p logs
mkdir -p .pids

# Set HOST and PORT for web server
export HOST=0.0.0.0
export PORT=5000

# Start web application in the background
echo "Starting web application..."
npm run dev > logs/web_app.log 2>&1 &
echo $! > .pids/webapp.pid

echo "Waiting for web server to start..."
for i in {1..30}; do
  if curl -s http://localhost:5000 > /dev/null; then
    echo "Web server is running!"
    break
  fi
  echo "Waiting for web server... ($i/30)"
  sleep 2
done

# Start Twitter bot
echo "Starting Twitter bot..."
python run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
echo $! > .pids/twitter_bot.pid

# Start Mind9 core system
echo "Starting Mind9 core system..."
python run_mind9.py > logs/mind9.log 2>&1 &
echo $! > .pids/mind9.pid

# Start Coin Promoter
echo "Starting Coin Promoter..."
python run_coin_promoter.py > logs/coin_promoter.log 2>&1 &
echo $! > .pids/coin_promoter.pid

# Start health monitor
echo "Starting health monitor..."
bash health_monitor_replit.sh > logs/monitor.log 2>&1 &
echo $! > .pids/monitor.pid

echo "Mind9 system is now running in persistent mode!"
echo "The system will continue running in the background."

# Keep the VM active with a simple heartbeat process
while true; do
  # Check and restart services if needed
  for service in webapp twitter_bot mind9 coin_promoter; do
    if [ -f ".pids/${service}.pid" ]; then
      pid=$(cat .pids/${service}.pid)
      if ! ps -p $pid > /dev/null; then
        echo "[$(date)] ${service} is down, restarting..." >> logs/heartbeat.log
        
        case $service in
          webapp)
            npm run dev > logs/web_app.log 2>&1 &
            echo $! > .pids/webapp.pid
            ;;
          twitter_bot)
            python run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
            echo $! > .pids/twitter_bot.pid
            ;;
          mind9)
            python run_mind9.py > logs/mind9.log 2>&1 &
            echo $! > .pids/mind9.pid
            ;;
          coin_promoter)
            python run_coin_promoter.py > logs/coin_promoter.log 2>&1 &
            echo $! > .pids/coin_promoter.pid
            ;;
        esac
        
        echo "[$(date)] ${service} restarted with PID: $(cat .pids/${service}.pid)" >> logs/heartbeat.log
      fi
    fi
  done
  
  echo "[$(date)] Mind9 heartbeat check completed" >> logs/heartbeat.log
  sleep 300  # Check every 5 minutes
done
EOF

chmod +x persistent_mind9.sh

# Configure workspace for Reserved VM deployment
echo "Configuring .replit file for Reserved VM deployment..."

# Navigate to the Deployments UI in Replit to complete the setup
echo ""
echo "========================================================"
echo "IMPORTANT: You need to complete the setup in the Replit UI:"
echo ""
echo "1. Go to the 'Deployments' tab in the Replit sidebar"
echo "2. Select 'Create new deployment'"
echo "3. Choose 'Reserved VM' as the deployment type"
echo "4. Select 'Web server' as the VM type"
echo "5. Set the run command to: ./persistent_mind9.sh"
echo "6. Click 'Deploy'"
echo "========================================================"
echo ""
echo "After deployment, Mind9 will run continuously even when you close your browser."
echo ""
echo "Setup complete! Your project is ready for Reserved VM deployment."
