
#!/bin/bash

# Mind9 Deployment Health Check
# This script checks the health of your deployment and logs any issues

echo "=========================================="
echo "     Mind9 Deployment Health Check"
echo "=========================================="

# Create logs directory if it doesn't exist
mkdir -p logs

# Log file
LOG_FILE="logs/deployment_health.log"

# Check Node.js environment
echo "Checking Node.js environment..." | tee -a $LOG_FILE
if command -v node &> /dev/null; then
  NODE_VERSION=$(node -v)
  echo "✅ Node.js is available: $NODE_VERSION" | tee -a $LOG_FILE
else
  echo "❌ Node.js is NOT available in PATH!" | tee -a $LOG_FILE
  echo "Current PATH: $PATH" >> $LOG_FILE
fi

if command -v npm &> /dev/null; then
  NPM_VERSION=$(npm -v)
  echo "✅ npm is available: $NPM_VERSION" | tee -a $LOG_FILE
else
  echo "❌ npm is NOT available in PATH!" | tee -a $LOG_FILE
fi

# Check for dist directory
if [ -d "dist" ]; then
  echo "✅ Build output (dist) directory exists" | tee -a $LOG_FILE
else
  echo "❌ Build output (dist) directory does NOT exist!" | tee -a $LOG_FILE
  echo "This suggests the build process failed" | tee -a $LOG_FILE
fi

# Check for port 5000 binding
if netstat -tuln 2>/dev/null | grep -q ":5000 "; then
  echo "✅ Service is listening on port 5000" | tee -a $LOG_FILE
else
  echo "❌ No service detected on port 5000!" | tee -a $LOG_FILE
  echo "The web application is not running properly" | tee -a $LOG_FILE
fi

# Check if services are running
if pgrep -f "node dist/index.js" > /dev/null; then
  echo "✅ Node.js application is running" | tee -a $LOG_FILE
else
  echo "❌ Node.js application is NOT running!" | tee -a $LOG_FILE
fi

echo "" | tee -a $LOG_FILE
echo "Health check complete. See logs/deployment_health.log for details." | tee -a $LOG_FILE
echo "To manually restart services, run: bash start_replit_services.sh" | tee -a $LOG_FILE
echo "=========================================="
