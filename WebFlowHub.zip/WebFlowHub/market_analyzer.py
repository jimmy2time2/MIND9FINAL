#!/usr/bin/env python3
"""
Market Analysis Module for Mind9
Analyzes market conditions to determine optimal timing for token creation
"""

import os
import json
import random
import logging
import time
import requests
from datetime import datetime, timedelta
import openai
from openai import OpenAI
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("market_analyzer.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("market_analyzer")

class MarketAnalyzer:
    def __init__(self):
        """Initialize market analyzer with required APIs"""
        self.openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        
        # Prepare file for storing market state
        self.market_state_file = "market_state.json"
        self.load_market_state()
        
        # Thresholds for determining if market conditions are good
        self.confidence_threshold = 0.70  # 70% confidence minimum
        self.cooldown_period = 2  # Days between token creations
        
        logger.info("Market analyzer initialized")
    
    def load_market_state(self):
        """Load saved market state from file"""
        if os.path.exists(self.market_state_file):
            try:
                with open(self.market_state_file, 'r') as file:
                    self.market_state = json.load(file)
                    logger.info("Loaded market state")
            except Exception as e:
                logger.error(f"Error loading market state: {e}")
                self.initialize_market_state()
        else:
            self.initialize_market_state()
    
    def initialize_market_state(self):
        """Create initial market state"""
        self.market_state = {
            "last_analysis_time": None,
            "last_token_creation_time": None,
            "market_sentiment": 0.5,  # Neutral sentiment
            "market_volatility": 0.5,  # Medium volatility
            "overall_confidence": 0.5,  # Neutral confidence
            "analysis_history": []
        }
        self.save_market_state()
    
    def save_market_state(self):
        """Save current market state to file"""
        try:
            with open(self.market_state_file, 'w') as file:
                json.dump(self.market_state, file, indent=2)
                logger.info("Saved market state")
        except Exception as e:
            logger.error(f"Error saving market state: {e}")
    
    def get_market_data(self):
        """
        Get current market data from various sources
        
        In a production environment, this would connect to:
        - CoinGecko/CoinMarketCap APIs for market cap, volume, and prices
        - Trading APIs for Solana-specific metrics
        - Social sentiment APIs for gauging community interest
        
        For this implementation, we'll use a simplified approach
        """
        try:
            # Get basic Bitcoin data as a market indicator
            btc_response = requests.get(
                "https://api.coingecko.com/api/v3/simple/price",
                params={
                    "ids": "bitcoin",
                    "vs_currencies": "usd",
                    "include_24hr_vol": "true",
                    "include_24hr_change": "true",
                    "include_market_cap": "true"
                }
            )
            
            if btc_response.status_code == 200:
                btc_data = btc_response.json().get("bitcoin", {})
                
                # Get Solana data as well
                sol_response = requests.get(
                    "https://api.coingecko.com/api/v3/simple/price",
                    params={
                        "ids": "solana",
                        "vs_currencies": "usd",
                        "include_24hr_vol": "true",
                        "include_24hr_change": "true",
                        "include_market_cap": "true"
                    }
                )
                
                if sol_response.status_code == 200:
                    sol_data = sol_response.json().get("solana", {})
                    
                    market_data = {
                        "timestamp": datetime.now().isoformat(),
                        "bitcoin": btc_data,
                        "solana": sol_data
                    }
                    
                    logger.info(f"Retrieved market data: BTC ${btc_data.get('usd', 0):,.2f}, SOL ${sol_data.get('usd', 0):,.2f}")
                    return market_data
            
            # If API calls fail, generate synthetic data for development
            logger.warning("Using fallback market data (API unavailable)")
            return self._generate_fallback_market_data()
            
        except Exception as e:
            logger.error(f"Error getting market data: {e}")
            return self._generate_fallback_market_data()
    
    def _generate_fallback_market_data(self):
        """Generate fallback market data for development"""
        return {
            "timestamp": datetime.now().isoformat(),
            "bitcoin": {
                "usd": random.uniform(20000, 60000),
                "usd_24h_change": random.uniform(-5, 5),
                "usd_24h_vol": random.uniform(20000000000, 50000000000),
                "usd_market_cap": random.uniform(800000000000, 1200000000000)
            },
            "solana": {
                "usd": random.uniform(40, 150),
                "usd_24h_change": random.uniform(-8, 8),
                "usd_24h_vol": random.uniform(1000000000, 3000000000),
                "usd_market_cap": random.uniform(15000000000, 50000000000)
            }
        }
    
    def analyze_with_ai(self, market_data):
        """
        Use OpenAI to analyze market conditions and determine optimal timing
        
        Args:
            market_data: Dictionary of current market metrics
            
        Returns:
            Dictionary with analysis results
        """
        try:
            # Format market data as a string for the prompt
            market_data_str = json.dumps(market_data, indent=2)
            
            prompt = f"""
            You are an AI crypto market analyst for an autonomous token creation system.
            Analyze the following market data and determine if now is a good time to create a new token on Solana.
            
            MARKET DATA:
            {market_data_str}
            
            Based on this data, please provide:
            1. Current market sentiment (scale 0-1, where 1 is extremely positive)
            2. Market volatility (scale 0-1, where 1 is extremely volatile)
            3. Overall confidence that this is a good time to launch a token (scale 0-1)
            4. Brief explanation of your reasoning (max 3 sentences)
            
            Response format (JSON only):
            {{
                "market_sentiment": (0-1 value),
                "market_volatility": (0-1 value),
                "overall_confidence": (0-1 value),
                "explanation": "Your brief explanation here"
            }}
            """
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4o", # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
                messages=[{"role": "system", "content": prompt}],
                response_format={"type": "json_object"}
            )
            
            analysis = json.loads(response.choices[0].message.content)
            
            # Update market state with new analysis
            self.market_state["last_analysis_time"] = datetime.now().isoformat()
            self.market_state["market_sentiment"] = analysis["market_sentiment"]
            self.market_state["market_volatility"] = analysis["market_volatility"]
            self.market_state["overall_confidence"] = analysis["overall_confidence"]
            
            # Add to history, keeping last 10 analyses
            self.market_state["analysis_history"].append({
                "timestamp": datetime.now().isoformat(),
                "analysis": analysis
            })
            if len(self.market_state["analysis_history"]) > 10:
                self.market_state["analysis_history"] = self.market_state["analysis_history"][-10:]
            
            # Save updated state
            self.save_market_state()
            
            logger.info(f"Analysis complete: confidence {analysis['overall_confidence']:.2f}")
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing market: {e}")
            return {
                "market_sentiment": 0.5,
                "market_volatility": 0.5,
                "overall_confidence": 0.4,
                "explanation": "Error during analysis. Using default values."
            }
    
    def should_create_token(self):
        """
        Determine if a new token should be created based on market conditions
        
        Returns:
            Tuple of (should_create, reason)
        """
        now = datetime.now()
        
        # Check if we're in the cooldown period
        if self.market_state["last_token_creation_time"]:
            last_creation = datetime.fromisoformat(self.market_state["last_token_creation_time"])
            days_since_last = (now - last_creation).total_seconds() / (24 * 3600)
            
            if days_since_last < self.cooldown_period:
                return (False, f"In cooldown period. {self.cooldown_period - days_since_last:.1f} days remaining.")
        
        # Check if we need a fresh analysis
        needs_analysis = True
        if self.market_state["last_analysis_time"]:
            last_analysis = datetime.fromisoformat(self.market_state["last_analysis_time"])
            hours_since_analysis = (now - last_analysis).total_seconds() / 3600
            
            if hours_since_analysis < 8:  # Analysis is valid for 8 hours
                needs_analysis = False
        
        # Get fresh analysis if needed
        if needs_analysis:
            market_data = self.get_market_data()
            self.analyze_with_ai(market_data)
        
        # Decide based on confidence level
        confidence = self.market_state["overall_confidence"]
        if confidence >= self.confidence_threshold:
            return (True, f"Market conditions favorable. Confidence: {confidence:.2f}")
        else:
            return (False, f"Market conditions unfavorable. Confidence: {confidence:.2f}")
    
    def record_token_creation(self):
        """Record that a token was created"""
        self.market_state["last_token_creation_time"] = datetime.now().isoformat()
        self.save_market_state()
        logger.info("Recorded token creation")

# If script is run directly, test the analysis
if __name__ == "__main__":
    analyzer = MarketAnalyzer()
    market_data = analyzer.get_market_data()
    analysis = analyzer.analyze_with_ai(market_data)
    
    print("\nMarket Analysis Results:")
    print(f"Sentiment: {analysis['market_sentiment']:.2f}")
    print(f"Volatility: {analysis['market_volatility']:.2f}")
    print(f"Overall Confidence: {analysis['overall_confidence']:.2f}")
    print(f"Explanation: {analysis['explanation']}")
    
    should_create, reason = analyzer.should_create_token()
    print(f"\nShould create token? {should_create}")
    print(f"Reason: {reason}")