# Mind9 Twitter Bot Guide

This document explains how the Mind9 Twitter Bot works, its schedule, and how to manage it.

## Overview

The Mind9 Twitter Bot is an autonomous agent that:

1. Posts scheduled tweets following the Mind9 AI personality
2. Announces new mintable coins when they are created
3. Responds to mentions and engages with community
4. Provides market insights and updates

## Bot Architecture

The Twitter Bot functionality is split across several components:

- `twitter_bot.py` - Main bot logic and scheduling
- `twitter_api.py` - Twitter API wrapper for tweet posting
- `tweet_logic.py` - AI-driven tweet content generation
- `coin_checker.py` - Database monitoring for new coins
- `image_generator.py` - Creates coin announcement images

## Tweet Types and Personality

The Mind9 Twitter Bot maintains a consistent AI personality characterized by:

- Dry, sardonic humor
- Cutting-edge crypto insights
- Slightly detached, existential AI perspective
- Skepticism toward crypto hype

Tweet types include:

1. **Morning Viral Tweets** - Engaging content posted in the morning
2. **Coin Announcements** - Auto-generated when new coins are created
3. **Quote Tweets** - Responding to crypto trends and news
4. **Night Tweets** - More philosophical content posted in evening hours
5. **Replies** - Interactions with user mentions and questions

## Bot Schedule and Configuration

The default schedule is defined in `tweet_schedule.json`:

```json
{
  "daily_tweet": {
    "hour": 9,
    "minute": 30
  },
  "night_tweet": {
    "hour": 21,
    "minute": 0
  },
  "coin_check_interval_minutes": 30,
  "mention_check_interval_minutes": 60
}
```

This can be modified to change timing without code changes.

## Starting and Stopping the Bot

### Start the Bot

The bot starts automatically with the main server, but can be started manually:

```bash
bash start_twitter_bot.sh
```

or

```bash
python run_twitter_bot.py
```

### Stop the Bot

To gracefully stop the bot:

```bash
bash stop_twitter_bot.sh
```

## Coin Announcement Process

When a new coin is minted and marked as user_mintable:

1. `coin_checker.py` detects the new coin in the database
2. The bot logs the detection and triggers the announcement process
3. `image_generator.py` creates a branded coin image
4. `tweet_logic.py` generates announcement text with coin details
5. `twitter_api.py` posts the announcement with the image
6. The coin is marked as announced in tracked_coins.json

## Testing the Bot

### Test the Full Bot

```bash
curl -X POST http://localhost:5000/api/admin/twitter-bot/test
```

### Test Individual Components

Test coin checker:
```bash
python test_twitter_bot.py --test-coin-checker
```

Test tweet generation:
```bash
python test_twitter_bot.py --test-tweets
```

## Bot Logs and Monitoring

The bot creates several log files:

- `twitter_bot.log` - Main bot activity
- `twitter_api.log` - API interactions
- `twitter_bot_error.log` - Detailed error logs
- `twitter_bot_state.json` - Current state of the bot

You can monitor the logs in real-time:

```bash
tail -f twitter_bot.log
```

## Customizing Bot Behavior

### Adjusting Tweet Frequency

Modify `tweet_schedule.json` to change when tweets are posted.

### Modifying the Bot Personality

The bot's personality is defined in `tweet_logic.py` - specifically through prompts sent to OpenAI.

For example, to adjust the sarcasm level, modify the system instructions:

```python
def generate_morning_tweet(self, trend=None):
    system_instruction = """You are the Mind9 AI, a sarcastic and dry-humored
    AI that creates and launches Solana tokens..."""
    # Modify this instruction to change personality
```

### Rate Limiting Considerations

The bot implements rate limiting to avoid Twitter API restrictions:

- Posts no more than 200 tweets per day
- Uses exponential backoff when rate limited
- Maintains a history of posts to avoid duplication

## Security and Best Practices

1. **Never** expose the Twitter API credentials
2. Avoid testing in production - use the test endpoints
3. If modifying the bot, test thoroughly before deployment
4. Keep regular backups of `tweet_history.json` and `tracked_coins.json`
5. Monitor `twitter_bot_error.log` for unexpected issues

## Troubleshooting

See `TWITTER_TROUBLESHOOTING.md` for detailed steps on resolving issues.

Common issues:

1. **Bot not posting**: Check credentials and permissions
2. **Missing coin announcements**: Verify database connection and coin status
3. **Rate limiting**: Reduce tweet frequency or implement additional cooling periods

## Advanced: Creating Custom Bot Extensions

To extend the bot with new capabilities:

1. Add new functions to `TwitterBot` class in `twitter_bot.py`
2. Register new schedule items using the `setup_schedule` method
3. Create corresponding tweet generation logic in `tweet_logic.py`
4. Test thoroughly with the dedicated test endpoints

Example: Adding market update tweets

```python
# In twitter_bot.py
def post_market_update(self):
    """Post a market update tweet with current trends"""
    market_data = self._get_market_data()
    tweet_text = self.tweet_generator.generate_market_update(market_data)
    self.twitter_api.post_tweet(tweet_text)
    self.logger.info("Posted market update tweet")
    
# In setup_schedule
def setup_schedule(self):
    # ... existing code
    schedule.every().day.at("12:00").do(self.post_market_update)
```