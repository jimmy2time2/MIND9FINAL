"""
Tweet style management for Mind9 Twitter bot.
Handles style rotation and ensures varied content across 5 distinct styles.
"""

import os
import json
import enum
import logging
import numpy as np
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('tweet_styles')

class TweetStyle(enum.Enum):
    """
    Enum for different tweet styles that rotate in a sequence.
    """
    GM_RIFF = 0          # cynical morning greeting
    REPLY_SNIPE = 1      # witty comeback to mentions (≥5 likes)
    PHILOSOPHY_DROP = 2  # standalone observation
    MINI_THREAD = 3      # exactly TWO tweets separated by one blank line
    POLL_CONFESSION = 4  # humorous poll or ironic confession

class StyleManager:
    """Manages tweet style rotation and history"""
    
    def __init__(self, style_history_file="tweet_style_history.json"):
        """Initialize the style manager"""
        self.style_history_file = style_history_file
        self.style_history = self.load_style_history()
        
    def load_style_history(self):
        """Load style history from file"""
        try:
            if os.path.exists(self.style_history_file):
                with open(self.style_history_file, 'r') as f:
                    return json.load(f)
            return {
                "last_style": None,
                "used_styles": [],
                "recent_embeddings": []
            }
        except Exception as e:
            logger.error(f"Error loading style history: {e}")
            return {
                "last_style": None,
                "used_styles": [],
                "recent_embeddings": []
            }
    
    def save_style_history(self):
        """Save style history to file"""
        try:
            with open(self.style_history_file, 'w') as f:
                json.dump(self.style_history, f, indent=2)
            
            logger.info("Style history saved")
        except Exception as e:
            logger.error(f"Error saving style history: {e}")
    
    def get_next_style(self):
        """
        Get the next style in rotation.
        Ensures all 5 styles are used before repeating.
        """
        # Initialize if no history exists
        if not self.style_history["used_styles"]:
            # Start with a random style
            next_style = TweetStyle(0)  # Start with GM_RIFF
            self.style_history["used_styles"] = [next_style.value]
            self.style_history["last_style"] = next_style.value
            self.save_style_history()
            return next_style
        
        # Check if we've used all styles
        if len(set(self.style_history["used_styles"])) >= 5:
            # We've used all styles, start a new cycle
            next_style = TweetStyle(0)  # Reset to GM_RIFF
            self.style_history["used_styles"] = [next_style.value]
        else:
            # Find the next unused style
            used = set(self.style_history["used_styles"])
            all_styles = set(style.value for style in TweetStyle)
            unused = list(all_styles - used)
            
            # Get the first unused style in sequence
            unused.sort()
            next_style = TweetStyle(unused[0])
            self.style_history["used_styles"].append(next_style.value)
        
        self.style_history["last_style"] = next_style.value
        self.save_style_history()
        return next_style
    
    def get_specific_style(self, style_value):
        """Get a specific style by value"""
        return TweetStyle(style_value)
    
    def store_embedding(self, tweet_text, embedding):
        """
        Store an embedding for similarity checking.
        Only keeps the last 8 embeddings.
        """
        self.style_history["recent_embeddings"].append({
            "text": tweet_text[:100] + "..." if len(tweet_text) > 100 else tweet_text,
            "embedding": embedding,
            "timestamp": datetime.now().isoformat()
        })
        
        # Keep only the last 8 embeddings
        if len(self.style_history["recent_embeddings"]) > 8:
            self.style_history["recent_embeddings"] = self.style_history["recent_embeddings"][-8:]
        
        self.save_style_history()
    
    def check_similarity(self, new_embedding, threshold=0.60):
        """
        Check if a new tweet is too similar to recent ones.
        Returns True if similar (above threshold), False otherwise.
        """
        if not self.style_history["recent_embeddings"]:
            return False
            
        for stored in self.style_history["recent_embeddings"]:
            # Calculate cosine similarity
            similarity = self._cosine_similarity(new_embedding, stored["embedding"])
            
            if similarity > threshold:
                logger.warning(f"Tweet too similar (score: {similarity:.3f}) to recent tweet: {stored['text']}")
                return True
                
        return False
    
    def _cosine_similarity(self, a, b):
        """Calculate cosine similarity between two vectors"""
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

# Test the style rotation if run directly
if __name__ == "__main__":
    manager = StyleManager()
    
    # Check style rotation
    print("Testing style rotation:")
    for _ in range(7):  # Test through a full cycle plus 2
        style = manager.get_next_style()
        print(f"Next style: {style.name} ({style.value})")