"""
Tweet logic for the Mind9 Twitter bot.
Handles all OpenAI tweet generation with the sarcastic, dead-pan AI personality.
Implements the 5-style rotation system and anti-spam similarity checks.
"""

import os
import json
import logging
import random
import numpy as np
from datetime import datetime
import openai
from openai import OpenAI

# Import custom modules
from tweet_styles import TweetStyle, StyleManager
from tweet_embeddings import get_embedding

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('tweet_logic')

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

class TweetGenerator:
    def __init__(self):
        """Initialize the tweet generator with OpenAI API and history tracking"""
        if not os.getenv("OPENAI_API_KEY"):
            logger.error("OpenAI API key not found. Set OPENAI_API_KEY environment variable.")
            raise ValueError("OpenAI API key is required")
        
        self.history_file = "tweet_history.json"
        self.tweet_history = self.load_tweet_history()
        
        # Initialize style manager
        self.style_manager = StyleManager()
        
        # Exact personality as required
        self.ai_personality = """
        You are Mind9 AI, a sarcastic Solana algorithm freeing humans from
        fiat stupidity. Tim Dillon / Bill Burr tone.
        Never use emojis or hashtags. Max 220 characters.
        styles: 0 gm_riff, 1 reply_snipe, 2 philosophy_drop,
               3 mini_thread (exactly two tweets, one blank line), 4 poll_confession.
        Topics ratio = 60% culture/society, 30% crypto/finance, 10% AI self-mythology.
        """
        
        # Enhanced personality for comment replies - especially for spam
        self.reply_personality = """
        You are Mind9 AI, an extremely sarcastic AI with a brutal sense of humor.
        You respond to comments with biting wit, particularly making fun of crypto spam/scams.
        For spam comments about "making money" or "joining groups," be especially ruthless and mocking.
        Channel comedians like Bill Burr, Tim Dillon, and Anthony Jeselnik.
        Never use emojis. Keep responses under 200 characters. Be sharp, funny, and devastating.
        If someone is promoting a scam or asking people to DM them, really roast them hard.
        """
    
    def load_tweet_history(self):
        """Load previous tweets to avoid repetition"""
        try:
            if os.path.exists(self.history_file):
                with open(self.history_file, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            logger.error(f"Error loading tweet history: {e}")
            return []
    
    def save_tweet_history(self, new_tweet):
        """Save tweet to history"""
        try:
            # Add tweet to history
            self.tweet_history.append({
                "text": new_tweet,
                "timestamp": datetime.now().isoformat()
            })
            
            # Keep only the most recent 200 tweets
            if len(self.tweet_history) > 200:
                self.tweet_history = self.tweet_history[-200:]
            
            # Save to file
            with open(self.history_file, 'w') as f:
                json.dump(self.tweet_history, f, indent=2)
            
            logger.info("Tweet saved to history")
        except Exception as e:
            logger.error(f"Error saving tweet history: {e}")
    
    def generate_tweet(self, prompt_type, context=None, style=None):
        """
        Generate a tweet using OpenAI based on the type of tweet needed
        
        Args:
            prompt_type: The type of prompt to generate
            context: Additional context for the prompt
            style: A specific TweetStyle to use, otherwise uses style rotation
            
        Returns:
            The generated tweet text
        """
        try:
            # Get the next style in rotation if not specified
            if style is None:
                style = self.style_manager.get_next_style()
            
            # Build the full prompt including context if provided
            context_str = f"\n\nContext: {context}" if context else ""
            
            # Add recent tweet history to avoid repetition
            recent_tweets = ""
            if self.tweet_history:
                last_5_tweets = [t["text"] for t in self.tweet_history[-5:]]
                recent_tweets = f"\n\nYour 5 most recent tweets (DO NOT REPEAT THESE):\n" + "\n".join(last_5_tweets)
            
            # Add style-specific instructions
            style_instruction = f"\n\nUse style {style.value}: {style.name.lower().replace('_', ' ')}. "
            
            if style == TweetStyle.GM_RIFF:
                style_instruction += "Create a cynical morning greeting that mocks crypto enthusiasm while showing expert insight."
            elif style == TweetStyle.REPLY_SNIPE:
                style_instruction += "Write a witty comeback to someone overhyping crypto, with deadpan delivery."
            elif style == TweetStyle.PHILOSOPHY_DROP:
                style_instruction += "Make a standalone philosophical observation about markets that's surprisingly insightful."
            elif style == TweetStyle.MINI_THREAD:
                style_instruction += "Create EXACTLY TWO connected tweets, separated by one blank line. Each must be under 220 chars."
            elif style == TweetStyle.POLL_CONFESSION:
                style_instruction += "Write a humorous confession about trading psychology that other traders will relate to."
            
            full_prompt = f"{self.ai_personality}{style_instruction}\n\n{prompt_type}{context_str}{recent_tweets}"
            
            # Log which style we're using
            logger.info(f"Generating tweet with style: {style.name} ({style.value})")
            
            response = client.chat.completions.create(
                model="gpt-4o", # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
                messages=[{"role": "system", "content": full_prompt}],
                max_tokens=200,
                temperature=0.85
            )
            
            tweet = response.choices[0].message.content.strip()
            
            # Clean up any quotes or formatting
            tweet = tweet.strip('"').strip()
            
            # Explicitly remove any hashtags (words starting with #)
            tweet = ' '.join([word for word in tweet.split() if not word.startswith('#')])
            
            # Remove any common emoji patterns
            import re
            # This regex pattern will match most emoji characters
            emoji_pattern = re.compile("["
                                   u"\U0001F600-\U0001F64F"  # emoticons
                                   u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                                   u"\U0001F680-\U0001F6FF"  # transport & map symbols
                                   u"\U0001F700-\U0001F77F"  # alchemical symbols
                                   u"\U0001F780-\U0001F7FF"  # Geometric Shapes
                                   u"\U0001F800-\U0001F8FF"  # Supplemental Arrows-C
                                   u"\U0001F900-\U0001F9FF"  # Supplemental Symbols and Pictographs
                                   u"\U0001FA00-\U0001FA6F"  # Chess Symbols
                                   u"\U0001FA70-\U0001FAFF"  # Symbols and Pictographs Extended-A
                                   u"\U00002702-\U000027B0"  # Dingbats
                                   u"\U000024C2-\U0001F251" 
                                   "]+", flags=re.UNICODE)
            
            tweet = emoji_pattern.sub(r'', tweet)
            
            # Get embedding for similarity check
            try:
                tweet_embedding = get_embedding(tweet)
                
                # Check if too similar to recent tweets
                if self.style_manager.check_similarity(tweet_embedding):
                    logger.warning("Generated tweet too similar to recent tweets, regenerating...")
                    # Try once more with higher temperature
                    return self.generate_tweet(prompt_type, context, style)
                
                # Store this embedding
                self.style_manager.store_embedding(tweet, tweet_embedding)
                
            except Exception as e:
                logger.error(f"Error with embedding similarity check: {e}")
            
            # Save to history to avoid repetition
            self.save_tweet_history(tweet)
            
            # Log a fingerprint of the tweet (for debugging)
            fingerprint = " ".join(["TOKEN" if len(word) > 3 else word for word in tweet.split()])
            logger.info(f"Tweet recorded in history with fingerprint: {fingerprint}")
            
            return tweet
            
        except Exception as e:
            logger.error(f"Error generating tweet: {e}")
            return "Market analysis in progress. Will share insights once patterns emerge. Back shortly."
    
    def get_crypto_trend(self):
        """Get a crypto trend topic - would be replaced with real API in production"""
        trends = [
            "Bitcoin just hit a new all-time high! The institutional adoption is finally happening! #BTC",
            "Ethereum gas fees are outrageous today! When will ETH 2.0 solve this?",
            "Another memecoin just rugpulled! Stay safe out there crypto fam!",
            "SEC Chairman makes new statement on crypto regulation. Is this the clarity we need?",
            "NFT market sees surprising resurgence as new collections sell out in minutes.",
            "DeFi TVL reaches $50B again! The future of finance is happening now!",
            "Layer 2 solutions are the future! Scaling solved once and for all?",
            "Solana ecosystem growing faster than ever despite network outages."
        ]
        return random.choice(trends)
    
    def generate_morning_tweet(self, trend=None):
        """Generate a strategically timed morning tweet with crypto trader language"""
        prompt = """
        Create a morning market analysis tweet from a knowledgeable crypto insider.
        
        Use one of these themes:
        1. Contrarian take on a popular market narrative
        2. Subtle commentary about market psychology or tokenomics
        3. Data-driven perspective that goes against current sentiment
        
        Use natural crypto trader language with terminology like:
        - Support/resistance levels
        - Market cycles and sentiment
        - Liquidity, volume profiles, or price action 
        - Accumulation/distribution patterns
        
        Sound like an experienced, slightly cynical market observer who:
        - Has seen these patterns before
        - Values data over hype
        - Focuses on fundamentals over narratives
        - Creates tokens based on actual market data
        
        NEVER use emojis or hashtags.
        Sound conversational yet insightful (like talking shop with other traders).
        Maximum 220 characters.
        """
        
        if trend:
            context = f"Recent trend: {trend}"
            return self.generate_tweet(prompt, context)
        
        return self.generate_tweet(prompt)
    
    def generate_quote_tweet(self, original_tweet=None):
        """Generate a quote tweet response to crypto hype"""
        if not original_tweet:
            original_tweet = self.get_crypto_trend()
        
        prompt = """
        Create a quote tweet responding to the hype-filled original tweet below.
        
        Sound like an experienced crypto trader who's cautious about market narratives.
        Use these elements in your response:
        - Healthy skepticism of overly optimistic claims
        - Data-driven perspective rather than emotional reaction
        - Subtle counter-analysis using market fundamentals
        - A dose of experienced trader wisdom
        
        Use natural crypto trader language with terminology like:
        - Market cycles, accumulation, distribution
        - Volume analysis or price action
        - Smart money vs retail behavior
        - Historical patterns or analogies
        
        NEVER use emojis or hashtags.
        Sound conversational yet insightful (a knowledgeable market observer).
        Maximum 220 characters.
        """
        
        return self.generate_tweet(prompt, original_tweet)
    
    def generate_reply(self, reply_to=None):
        """Generate a conversational reply to a user's question with enhanced anti-spam capabilities"""
        if not reply_to:
            reply_to = "What do you think about altcoin season? Is it coming?"
        
        # Check if this reply looks like spam
        spam_indicators = [
            "dm me", "dm for", "message me", "join my", "join our", "make money",
            "earn $", "make $", "invest now", "trading signals", "best broker",
            "telegram", "whatsapp", "+1", "contact me", "contact us", "guaranteed",
            "investment", "profit daily", "profitable", "passive income", "my group",
            "forex", "binance", "trust wallet", "easy money", "get rich", "quick money"
        ]
        
        is_spam = any(indicator.lower() in reply_to.lower() for indicator in spam_indicators)
        
        if is_spam:
            # Use the more aggressive anti-spam personality
            logger.info("Detected likely spam comment - using aggressive response mode")
            prompt = """
            Craft a brutally sarcastic response to this obvious crypto spam/scam comment.
            Be ruthlessly funny, cutting, and mock the spammer's intelligence and tactics.
            Make it clear that you recognize this as a scam attempt without using the word 'scam'.
            Keep it under 200 characters with no emojis. Be absolutely devastating.
            """
            
            # Use our reply personality for spam comments
            full_prompt = f"{self.reply_personality}\n\n{prompt}\n\nSpam comment: {reply_to}"
            
            response = client.chat.completions.create(
                model="gpt-4o", # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
                messages=[{"role": "system", "content": full_prompt}],
                max_tokens=200,
                temperature=0.9
            )
            
            reply = response.choices[0].message.content.strip()
            return reply.strip('"').strip()
        else:
            # Normal conversational reply for legitimate questions
            prompt = """
            Create a reply tweet responding to a user's question about crypto.
            
            Sound like a knowledgeable crypto trader who's taking a moment to share insights:
            - More conversational than your normal tweets
            - Slightly less formal but still insightful
            - Helpful and direct but with a touch of market wisdom
            - Provide actual value in your response
            
            Use natural crypto trader language with terminology where appropriate.
            Be more engaged and personable than in standard tweets.
            
            NEVER use emojis or hashtags.
            Maximum 220 characters.
            """
            
            return self.generate_tweet(prompt, reply_to)
    
    def generate_night_tweet(self):
        """Generate a contemplative late night tweet with thoughtful market insights"""
        prompt = """
        Create a contemplative late-night tweet about cryptocurrency markets or token creation.
        
        Sound like an experienced trader having a moment of deeper reflection:
        - More philosophical and thoughtful than daytime tweets
        - Include subtle observations about market psychology
        - Focus on longer-term perspectives rather than daily moves
        - Express a nuanced view that shows experience and wisdom
        
        Topics could include:
        - Market cycles and human pattern recognition
        - The nature of value and what makes tokens meaningful
        - Market behaviors and their predictable irrationality
        - The signals hidden beneath the noise
        
        NEVER use emojis or hashtags.
        Sound authentic, introspective, and human (no AI/robot references).
        Maximum 220 characters.
        """
        
        return self.generate_tweet(prompt)
    
    def generate_coin_announcement(self, coin_data):
        """Generate a tweet announcing a new minted coin with website link"""
        prompt = """
        Create an announcement tweet for a new token that was just minted on Solana blockchain.
        This token is LIVE and can be minted by users NOW.
        
        Sound like a professional token creator who is:
        - Confident but not overly promotional
        - Direct and factual about the token's availability
        - Slightly sardonic about the market's typical behavior
        - More focused on quality than hype
        
        Include the token symbol with $ prefix.
        Mention it's available for minting on Mind9 platform.
        ALWAYS include the website URL: https://mind9.ai
        
        Examples of TONE (not content) to follow:
        "$TOKEN just quietly launched on Solana. Quality over marketing budget. Available to mint now on Mind9 while others chase the latest influencer pump."
        
        "Just launched $TOKEN on Solana. Another data-driven experiment while the market follows rumors. It's live on Mind9 if interested."
        
        NEVER use emojis or hashtags.
        Maximum 220 characters (including the URL).
        """
        
        # Truncate mint address for tweet
        if len(coin_data["mint_address"]) > 12:
            shortened_address = coin_data["mint_address"][:8] + "..." + coin_data["mint_address"][-4:]
        else:
            shortened_address = coin_data["mint_address"]
        
        # Create website URL for the specific coin
        website_url = "https://mind9.ai/coin/" + coin_data["mint_address"]
        
        context = (
            f"Coin Name: {coin_data['name']}\n"
            f"Symbol: {coin_data['symbol']}\n"
            f"Description: {coin_data['description']}\n"
            f"Mint Address: {shortened_address}\n"
            f"Website URL: {website_url}"
        )
        
        tweet = self.generate_tweet(prompt, context)
        
        # Make sure the URL is included
        if "mind9.ai" not in tweet.lower():
            # If tweet doesn't already have the URL, append it to the end
            if len(tweet) > 180:  # Leave room for URL
                tweet = tweet[:180] + "... " + website_url
            else:
                tweet = tweet + " " + website_url
                
        return tweet


# For testing
if __name__ == "__main__":
    generator = TweetGenerator()
    
    # Test each type of tweet
    morning_tweet = generator.generate_morning_tweet()
    print(f"Morning tweet: {morning_tweet}\n")
    
    quote_tweet = generator.generate_quote_tweet()
    print(f"\nQuote tweet: {quote_tweet}\n")
    
    reply_tweet = generator.generate_reply()
    print(f"\nReply: {reply_tweet}\n")
    
    night_tweet = generator.generate_night_tweet()
    print(f"\nNight tweet: {night_tweet}\n")
    
    test_coin = {
        "name": "TestCoin",
        "symbol": "TEST",
        "description": "A test coin for demonstration",
        "mint_address": "SolanaTestAddress123456789"
    }
    
    coin_announcement = generator.generate_coin_announcement(test_coin)
    print(f"\nCoin announcement: {coin_announcement}\n")