#!/bin/bash

# Always-On Script for Mind9 on Replit Reserved VM
# This is a simplified script to keep Mind9 running 24/7

echo "=================================================="
echo "  Mind9 Always-On Setup for Reserved VM"
echo "=================================================="
echo ""

# Create logs directory
mkdir -p logs

# Kill any existing processes
echo "Stopping any existing Mind9 services..."
pkill -f "npm run dev" 2>/dev/null || true
pkill -f "python.*twitter_bot.py" 2>/dev/null || true
pkill -f "python.*run_mind9.py" 2>/dev/null || true
pkill -f "python.*run_coin_promoter.py" 2>/dev/null || true
pkill -f "keep_services_running.sh" 2>/dev/null || true
sleep 2

# Find Python path
PYTHON_PATH=$(which python3.11 || which python3 || which python || echo "python3")
echo "Using Python path: $PYTHON_PATH"

# Start the web application
echo "Starting Mind9 web application..."
export HOST=0.0.0.0
export PORT=5000
nohup npm run dev > logs/web_app.log 2>&1 &
echo "Web app started with PID: $!"

# Start Twitter bot
echo "Starting Twitter bot..."
nohup $PYTHON_PATH -u run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
echo "Twitter bot started with PID: $!"

# Start Mind9 core
echo "Starting Mind9 core system..."
nohup $PYTHON_PATH -u run_mind9.py > logs/mind9.log 2>&1 &
echo "Mind9 core started with PID: $!"

# Start coin promoter
echo "Starting Coin Promoter..."
nohup $PYTHON_PATH -u run_coin_promoter.py > logs/coin_promoter.log 2>&1 &
echo "Coin Promoter started with PID: $!"

echo ""
echo "Mind9 services started successfully!"
echo "The system will continue running even when you close the browser."
echo ""
echo "For optimal operation on a Reserved VM:"
echo "1. Do not stop this script"
echo "2. Leave this terminal running"
echo "3. You can close the browser"
echo ""
echo "=================================================="

# Keep the terminal active and monitor services
while true; do
  # Check web server
  if ! netstat -tuln | grep -q ":5000 "; then
    echo "[$(date)] Web server not running, restarting..."
    export HOST=0.0.0.0
    export PORT=5000
    nohup npm run dev > logs/web_app.log 2>&1 &
    echo "Web app restarted with PID: $!"
  fi
  
  # Check Twitter bot
  if ! pgrep -f "run_twitter_bot.py" > /dev/null; then
    echo "[$(date)] Twitter bot not running, restarting..."
    nohup $PYTHON_PATH -u run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
    echo "Twitter bot restarted with PID: $!"
  fi
  
  # Check Mind9 core
  if ! pgrep -f "run_mind9.py" > /dev/null; then
    echo "[$(date)] Mind9 core not running, restarting..."
    nohup $PYTHON_PATH -u run_mind9.py > logs/mind9.log 2>&1 &
    echo "Mind9 core restarted with PID: $!"
  fi
  
  # Check coin promoter
  if ! pgrep -f "run_coin_promoter.py" > /dev/null; then
    echo "[$(date)] Coin Promoter not running, restarting..."
    nohup $PYTHON_PATH -u run_coin_promoter.py > logs/coin_promoter.log 2>&1 &
    echo "Coin Promoter restarted with PID: $!"
  fi
  
  # Log heartbeat
  echo "[$(date)] Mind9 is running autonomously on Replit Reserved VM" 
  sleep 60  # Check every minute
done