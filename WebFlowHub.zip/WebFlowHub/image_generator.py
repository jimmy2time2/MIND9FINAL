#!/usr/bin/env python3
"""
Image Generator for Mind9
Creates elegant, branded coin images with consistent styling
"""

import os
import io
import logging
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("image_generator.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("image_generator")

class CoinImageGenerator:
    def __init__(self, output_dir="generated_images"):
        """Initialize image generator with output directory"""
        self.output_dir = output_dir
        
        # Ensure output directory exists
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        # Load fonts - use default fonts if custom ones aren't available
        try:
            # Try to load a clean sans-serif font
            self.title_font = ImageFont.truetype("Arial.ttf", 72)
            self.subtitle_font = ImageFont.truetype("Arial.ttf", 24)
        except IOError:
            # Fallback to default font
            self.title_font = ImageFont.load_default()
            self.subtitle_font = ImageFont.load_default()
            
        logger.info("CoinImageGenerator initialized")
            
    def _create_gradient_background(self, width, height, top_color, bottom_color):
        """Create a smooth gradient background"""
        base = Image.new('RGBA', (width, height), (255, 255, 255, 0))
        draw = ImageDraw.Draw(base)
        
        # Convert colors from hex to RGB if needed
        if isinstance(top_color, str):
            top_color = self._hex_to_rgb(top_color)
        if isinstance(bottom_color, str):
            bottom_color = self._hex_to_rgb(bottom_color)
            
        # Create gradient
        for y in range(height):
            # Calculate the ratio of completion
            ratio = y / height
            # Interpolate between colors
            r = int(top_color[0] * (1 - ratio) + bottom_color[0] * ratio)
            g = int(top_color[1] * (1 - ratio) + bottom_color[1] * ratio)
            b = int(top_color[2] * (1 - ratio) + bottom_color[2] * ratio)
            # Draw the line
            draw.line([(0, y), (width, y)], fill=(r, g, b))
            
        return base
        
    def _hex_to_rgb(self, hex_color):
        """Convert hex color to RGB tuple"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
    def _create_circle_mask(self, size):
        """Create a circular mask for the gradient"""
        mask = Image.new('L', size, 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0) + size, fill=255)
        return mask
        
    def generate_coin_image(self, coin_name, primary_color="#FF7D45", secondary_color="#FFD1B8"):
        """
        Generate a coin image with:
        - Gradient circle in warm tones
        - Coin name text in clean, centered font
        - "Created by Mind9" subtext
        
        Args:
            coin_name: Name of the coin (e.g. "$FLUX")
            primary_color: Main gradient color (hex)
            secondary_color: Secondary gradient color (hex)
            
        Returns:
            Tuple of (file_path, image_bytes)
        """
        # Generate a clean version of the coin name for the filename
        clean_name = coin_name.replace('$', '').lower()
        
        # Set up image parameters
        width, height = 1200, 1200
        padding = 100
        circle_size = (width - 2*padding, height - 2*padding)
        
        # Create base image with transparent background
        image = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        
        # Create gradient background
        gradient = self._create_gradient_background(
            circle_size[0], circle_size[1], 
            primary_color, secondary_color
        )
        
        # Create circular mask and apply to gradient
        circle_mask = self._create_circle_mask(circle_size)
        gradient.putalpha(circle_mask)
        
        # Apply slight blur for soft edges
        gradient = gradient.filter(ImageFilter.GaussianBlur(radius=15))
        
        # Paste gradient onto base image
        image.paste(gradient, (padding, padding), gradient)
        
        # Add drawing context
        draw = ImageDraw.Draw(image)
        
        # Ensure proper contrast for text
        text_color = (0, 0, 0, 255)  # Black text for visibility
        
        # Add coin name text - centered
        text_width, text_height = draw.textbbox((0, 0), coin_name, font=self.title_font)[2:4]
        position = ((width - text_width) // 2, (height - text_height) // 2 - 20)
        draw.text(position, coin_name, font=self.title_font, fill=text_color)
        
        # Add "Created by Mind9" subtext
        subtext = "Created by Mind9"
        subtext_width, subtext_height = draw.textbbox((0, 0), subtext, font=self.subtitle_font)[2:4]
        subtext_position = ((width - subtext_width) // 2, position[1] + text_height + 30)
        draw.text(subtext_position, subtext, font=self.subtitle_font, fill=text_color)
        
        # Generate filename with timestamp to avoid conflicts
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        filename = f"{clean_name}_{timestamp}.png"
        file_path = os.path.join(self.output_dir, filename)
        
        # Save the image
        image.save(file_path, 'PNG')
        
        # Also create a bytes buffer for direct upload
        img_byte_arr = io.BytesIO()
        image.save(img_byte_arr, format='PNG')
        img_bytes = img_byte_arr.getvalue()
        
        logger.info(f"Generated coin image for {coin_name}, saved to {file_path}")
        
        return file_path, img_bytes

if __name__ == "__main__":
    # Test the image generator
    generator = CoinImageGenerator()
    file_path, _ = generator.generate_coin_image("$FLUX")
    print(f"Test image generated and saved to: {file_path}")