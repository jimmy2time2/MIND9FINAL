// 24/7 Deployment Helper for Mind9
// Run with: node 24-7-deploy.js

const fs = require('fs');
const { execSync } = require('child_process');
const path = require('path');

console.log('======================================================');
console.log('  Mind9 24/7 Deployment Helper');
console.log('======================================================\n');

// Step 1: Create .replit file
try {
  console.log('Step 1: Creating .replit file...');
  const replitContent = `run = "node dist/index.js"

[deployment]
deploymentTarget = "reservedvm"
build = ["sh", "-c", "npm ci && npm run build"]
run   = ["sh", "-c", "./start_persistent.sh"]

[[ports]]
localPort     = 5000
externalPort  = 80
name          = "Mind9-App"
protocol      = "http"`;

  fs.writeFileSync('.replit', replitContent);
  console.log('✓ .replit file created');
} catch (err) {
  console.error('Error creating .replit file:', err.message);
  console.error('You will need to create this file manually using the content from DEPLOYMENT_INSTRUCTIONS.md');
}

// Step 2: Create replit.nix file
try {
  console.log('\nStep 2: Creating replit.nix file...');
  const nixContent = `{ pkgs }: {
  deps = [
    pkgs.nodejs-20
    pkgs.libpng pkgs.cairo pkgs.pango pkgs.librsvg
    pkgs.pkg-config
  ];
}`;

  fs.writeFileSync('replit.nix', nixContent);
  console.log('✓ replit.nix file created');
} catch (err) {
  console.error('Error creating replit.nix file:', err.message);
  console.error('You will need to create this file manually using the content from DEPLOYMENT_INSTRUCTIONS.md');
}

// Step 3: Create and make executable start_persistent.sh
try {
  console.log('\nStep 3: Creating start_persistent.sh...');
  const persistentScript = `#!/usr/bin/env bash
# Keep background workers + web server alive
npx pm2-runtime dist/index.js`;

  fs.writeFileSync('start_persistent.sh', persistentScript);
  try {
    execSync('chmod +x start_persistent.sh');
    console.log('✓ start_persistent.sh created and made executable');
  } catch (err) {
    console.error('Error making start_persistent.sh executable:', err.message);
    console.log('Please run: chmod +x start_persistent.sh');
  }
} catch (err) {
  console.error('Error creating start_persistent.sh:', err.message);
}

// Step 4: Prompt for changing canvas dependency
console.log('\nStep 4: Canvas dependency...');
console.log('You need to update your Canvas dependency by running:');
console.log('  npm uninstall canvas');
console.log('  npm install --save npm:@napi-rs/canvas@^0.1.37 --force');

// Step 5: Check package.json build script
try {
  console.log('\nStep 5: Checking package.json build script...');
  const packageJson = require('./package.json');
  
  let hasCorrectScripts = true;
  if (!packageJson.scripts || !packageJson.scripts.build) {
    console.log('⚠️ Missing build script in package.json');
    hasCorrectScripts = false;
  }
  
  if (!packageJson.scripts || !packageJson.scripts.start) {
    console.log('⚠️ Missing start script in package.json');
    hasCorrectScripts = false;
  }
  
  if (hasCorrectScripts) {
    console.log('✓ package.json scripts look good');
  } else {
    console.log('Make sure package.json has these scripts:');
    console.log('  "build": "vite build",');
    console.log('  "start": "node dist/index.js"');
  }
} catch (err) {
  console.error('Error checking package.json:', err.message);
}

// Step 6: Check for environment secrets
console.log('\nStep 6: Environment variables check...');
console.log('Make sure you have these secrets set in Replit Secrets:');
console.log('  OPENAI_API_KEY');
console.log('  SOLANA_PRIVATEKEY');
console.log('  TWITTER_BEARER');

// Final instructions
console.log('\n======================================================');
console.log('  Next Steps:');
console.log('======================================================');
console.log('1. Run the Canvas dependency update commands');
console.log('2. Add the required secrets in Replit Secrets');
console.log('3. Commit your changes:');
console.log('   git add -A');
console.log('   git commit -m "♻️ One-file manifest, Reserved VM, nix libs, prebuilt canvas"');
console.log('4. Deploy to a Reserved VM using the Replit deployment interface');
console.log('   (Select 0.5 GB tier or higher)');
console.log('5. Verify your deployment with:');
console.log('   curl -I https://<your-project>.replit.app');
console.log('======================================================\n');