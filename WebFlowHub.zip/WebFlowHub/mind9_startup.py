#!/usr/bin/env python3
"""
Mind9 Autonomous System Startup Script

This script is designed to launch and manage all Mind9 services in the Replit environment.
It ensures services keep running and handles automatic restarts.
"""

import os
import time
import signal
import subprocess
import logging
import threading
import sys
from datetime import datetime

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("logs/mind9_startup.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("Mind9Startup")

# Create logs directory if it doesn't exist
os.makedirs("logs", exist_ok=True)

# Global variables to track processes
processes = {}

def signal_handler(sig, frame):
    """Handle termination signals and shutdown gracefully"""
    logger.info("Shutdown signal received, terminating all processes...")
    stop_all_processes()
    sys.exit(0)

def stop_all_processes():
    """Stop all running processes"""
    for name, process in processes.items():
        if process and process.poll() is None:  # Process exists and is running
            logger.info(f"Stopping {name}...")
            try:
                process.terminate()
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
            logger.info(f"{name} stopped")

def start_process(name, command, log_file):
    """Start a process and return the subprocess object"""
    logger.info(f"Starting {name}...")
    
    # Create log file path
    log_path = os.path.join("logs", log_file)
    
    # Open log file
    with open(log_path, "a") as f:
        f.write(f"\n\n=== {name} Starting at {datetime.now().isoformat()} ===\n\n")
    
    # Start the process
    log_fd = open(log_path, "a")
    
    # Start the process with the log file
    process = subprocess.Popen(
        command,
        stdout=log_fd,
        stderr=subprocess.STDOUT,
        shell=True,
        preexec_fn=os.setsid
    )
    
    logger.info(f"{name} started with PID {process.pid}")
    return process

def check_and_restart_process(name, command, log_file):
    """Check if a process is running, restart if needed"""
    global processes
    
    if name in processes and processes[name] and processes[name].poll() is None:
        # Process is still running
        return
    
    # Process is not running, start it
    processes[name] = start_process(name, command, log_file)

def process_monitor():
    """Monitor all processes and restart them if needed"""
    logger.info("Process monitor started")
    
    while True:
        try:
            # Check Twitter bot
            check_and_restart_process(
                "TwitterBot", 
                "python run_twitter_bot.py", 
                "twitter_bot.log"
            )
            
            # Check Coin Promoter
            check_and_restart_process(
                "CoinPromoter", 
                "python coin_promoter.py", 
                "coin_promoter.log"
            )
            
            # Check Mind9 Core
            check_and_restart_process(
                "Mind9Core", 
                "python main.py", 
                "mind9.log"
            )
            
            # Update timestamp file
            with open(".services_running", "w") as f:
                f.write(datetime.now().isoformat())
                
            # Wait for next check
            time.sleep(60)
            
        except Exception as e:
            logger.error(f"Error in process monitor: {e}")
            time.sleep(60)  # Continue monitoring despite errors

def main():
    """Main entry point for the startup script"""
    logger.info("====== Mind9 Autonomous System Startup ======")
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Create .flags directory and enable all services
    os.makedirs(".flags", exist_ok=True)
    
    # Set all flags to enabled
    with open(".flags/autostart_enabled", "w") as f:
        f.write("true")
    with open(".flags/autonomous_enabled", "w") as f:
        f.write("true")
    with open(".flags/twitter_enabled", "w") as f:
        f.write("true")
    with open(".flags/coin_promoter_enabled", "w") as f:
        f.write("true")
    
    # Create .pids directory
    os.makedirs(".pids", exist_ok=True)
    
    # Set timestamp to indicate services are running
    with open(".mind9_running", "w") as f:
        f.write(datetime.now().isoformat())
    
    # Start monitor in a thread
    monitor_thread = threading.Thread(target=process_monitor)
    monitor_thread.daemon = True
    monitor_thread.start()
    
    logger.info("Mind9 services started and being monitored!")
    
    # Keep the main thread running
    while True:
        time.sleep(60)
        # Update timestamp to indicate script is still running
        with open(".last_watchdog_run", "w") as f:
            f.write(datetime.now().isoformat())

if __name__ == "__main__":
    main()