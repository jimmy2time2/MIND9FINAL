#!/usr/bin/env python3
"""
Twitter Bot for Mind9
Autonomous AI Twitter agent that posts market insights and announces new token launches.
"""

import os
import time
import json
import logging
import random
from datetime import datetime, timedelta

# Import TweetStyle at the top level to fix the error
try:
    from tweet_styles import TweetStyle, StyleManager
    from tweet_logic import TweetGenerator
except ImportError:
    # Create a fallback enum if not available
    import enum
    class TweetStyle(enum.Enum):
        GM_RIFF = 0
        REPLY_SNIPE = 1
        PHILOSOPHY_DROP = 2
        MINI_THREAD = 3
        POLL_CONFESSION = 4

# Handle optional imports with fallbacks
try:
    import schedule
except ImportError:
    # Create a schedule fallback if not available
    class ScheduleFallback:
        def __init__(self):
            self.scheduled_tasks = []
            
        def every(self, interval=1):
            self.current_interval = interval
            return self
            
        def minutes(self):
            return self
            
        def day(self):
            return self
            
        def at(self, time_str):
            return self
            
        def do(self, func, *args, **kwargs):
            self.scheduled_tasks.append({"func": func, "args": args, "kwargs": kwargs})
            return self
            
        def run_pending(self):
            # In fallback mode, we just log that we would run tasks
            if self.scheduled_tasks:
                logging.info(f"Would run {len(self.scheduled_tasks)} scheduled tasks (fallback mode)")
            return None
    
    # Create a global schedule object        
    schedule = ScheduleFallback()
    print("Warning: schedule module not available, using fallback implementation")

try:
    from dotenv import load_dotenv
except ImportError:
    # Create a fallback if dotenv module is not available
    def load_dotenv():
        print("Warning: python-dotenv not available, using basic env loading")
        return True

# Import Mind9 components
# TweetGenerator is already imported at the top
from twitter_api import TwitterAPI
from coin_checker import CoinChecker

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("twitter_bot.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("mind9_twitter")

class TwitterBot:
    def __init__(self):
        """Initialize the Twitter bot with required components"""
        # Check API credentials 
        self._check_credentials()
        
        # Initialize components
        logger.info("Initializing Twitter bot components...")
        self.tweet_generator = TweetGenerator()
        self.twitter = TwitterAPI()
        self.coin_checker = CoinChecker()
        
        # Load or initialize bot state
        self.state_file = "twitter_bot_state.json"
        self.load_state()
        
        # Load tweet schedule configuration
        self.load_tweet_schedule()
        
        logger.info("Mind9 Twitter bot started")
        logger.info(f"Daily tweet limit: {self.daily_tweet_limit}")
        logger.info(f"Cooldown period: {self.cooldown_minutes} minutes")
    
    def _check_credentials(self):
        """Check if all required credentials are available"""
        # Twitter API keys
        twitter_vars = [
            "TWITTER_API_KEY",
            "TWITTER_API_KEY_SECRET",
            "TWITTER_ACCESS_TOKEN",
            "TWITTER_ACCESS_TOKEN_SECRET",
            "TWITTER_BEARER_TOKEN"
        ]
        
        # OpenAI API key for tweet generation
        openai_var = "OPENAI_API_KEY"
        
        missing_twitter = [var for var in twitter_vars if not os.getenv(var)]
        if missing_twitter:
            logger.warning(f"Missing Twitter credentials: {', '.join(missing_twitter)}")
            logger.warning("Twitter functionality will be limited")
        
        if not os.getenv(openai_var):
            logger.warning("OPENAI_API_KEY is missing. Tweet generation will be limited.")
    
    def load_state(self):
        """Load bot state from file or initialize new state"""
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r') as file:
                    self.state = json.load(file)
                    logger.info("Loaded Twitter bot state")
            except Exception as e:
                logger.error(f"Error loading Twitter bot state: {e}")
                self.initialize_state()
        else:
            self.initialize_state()
        
        # Check if it's a new day and reset the counter if needed
        current_date = datetime.now().strftime("%Y-%m-%d")
        if self.state["current_date"] != current_date:
            logger.info("New day detected, resetting tweet counter")
            self.state["current_date"] = current_date
            self.state["daily_tweet_count"] = 0
            self.save_state()
    
    def initialize_state(self):
        """Initialize a new bot state"""
        self.state = {
            "current_date": datetime.now().strftime("%Y-%m-%d"),
            "last_tweet_time": None,
            "daily_tweet_count": 0,
            "total_tweets": 0,
            "announced_coins": []
        }
        self.save_state()
    
    def save_state(self):
        """Save bot state to file"""
        try:
            with open(self.state_file, 'w') as file:
                json.dump(self.state, file, indent=2)
        except Exception as e:
            logger.error(f"Error saving Twitter bot state: {e}")
    
    def load_tweet_schedule(self):
        """Load tweet schedule configuration"""
        # Enhanced configuration for community building and better engagement
        self.daily_tweet_limit = 8  # Increased limit to 8 tweets per day for growing community
        self.cooldown_minutes = 60  # Reduced to 1 hour between regular tweets
        
        # Strategic time slots targeting highest crypto engagement times (24-hour format)
        # Based on research of peak crypto discussion and trading activity
        self.scheduled_times = [
            "08:30",  # Early morning tweet (catch Asian/European markets)
            "10:15",  # Mid-morning tweet (US market opening)
            "12:30",  # Lunch break tweet
            "14:45",  # Early afternoon update
            "16:30",  # Market summary
            "18:45",  # Evening analysis
            "20:30",  # Prime time engagement
            "22:15"   # Late night discussion
        ]
        
        # Add randomization to posting times for more natural behavior
        self.randomize_scheduled_times()
        
        # Try to load custom configuration if available
        try:
            if os.path.exists("tweet_schedule.json"):
                with open("tweet_schedule.json", 'r') as file:
                    config = json.load(file)
                    # Enforce minimum cooldown of 120 minutes regardless of config
                    self.daily_tweet_limit = config.get("daily_limit", 2)
                    self.cooldown_minutes = max(120, config.get("cooldown_minutes", 180))
                    self.scheduled_times = config.get("scheduled_times", self.scheduled_times)
                    # Re-randomize after loading
                    self.randomize_scheduled_times()
            logger.info(f"Strategic tweet schedule loaded: {', '.join(self.scheduled_times)}")
        except Exception as e:
            logger.error(f"Error loading tweet schedule, using strategic defaults: {e}")
            
    def randomize_scheduled_times(self):
        """Add natural randomization to tweet schedule"""
        randomized_times = []
        
        for time_slot in self.scheduled_times:
            # Parse original time
            hour, minute = map(int, time_slot.split(':'))
            
            # Add random offset between -30 and +30 minutes
            random_offset = random.randint(-30, 30)
            
            # Apply offset
            total_minutes = hour * 60 + minute + random_offset
            
            # Convert back to hours and minutes
            new_hour = (total_minutes // 60) % 24
            new_minute = total_minutes % 60
            
            # Format as time string
            new_time = f"{new_hour:02d}:{new_minute:02d}"
            randomized_times.append(new_time)
        
        # Replace scheduled times with randomized ones
        self.scheduled_times = randomized_times
        logger.info(f"Randomized strategic tweet schedule: {', '.join(self.scheduled_times)}")
    
    def check_rate_limits(self):
        """Check if we're within rate limits for posting tweets"""
        # First, check if Twitter API is currently rate limited
        rate_limit_file = 'twitter_rate_limit.json'
        if os.path.exists(rate_limit_file):
            try:
                with open(rate_limit_file, 'r') as f:
                    rate_limit_info = json.load(f)
                    
                if rate_limit_info.get('rate_limited', False):
                    reset_time_str = rate_limit_info.get('reset_time')
                    if reset_time_str:
                        try:
                            reset_time = datetime.fromisoformat(reset_time_str)
                            now = datetime.now()
                            
                            if now < reset_time:
                                wait_time = (reset_time - now).total_seconds()
                                logger.warning(f"Twitter API rate limited. Reset at {reset_time_str} ({int(wait_time/60)} minutes from now)")
                                return False
                            else:
                                # Time has passed, we can try again
                                logger.info("Rate limit reset time has passed, clearing rate limit status")
                                try:
                                    with open(rate_limit_file, 'w') as f:
                                        json.dump({'rate_limited': False}, f)
                                except Exception as e:
                                    logger.error(f"Error clearing rate limit status: {e}")
                        except Exception as e:
                            logger.error(f"Could not parse reset time: {reset_time_str}, error: {e}")
            except Exception as e:
                logger.error(f"Error reading rate limit file: {e}")
        
        # Check daily limit (Twitter allows max 17 tweets per day, we'll use less)
        if self.state["daily_tweet_count"] >= self.daily_tweet_limit:
            logger.info(f"Daily tweet limit reached ({self.daily_tweet_limit} tweets)")
            return False
        
        # Increase minimum gap between tweets to 3 hours to spread them throughout the day
        if self.state["last_tweet_time"]:
            last_tweet = datetime.fromisoformat(self.state["last_tweet_time"])
            elapsed = datetime.now() - last_tweet
            # 10800 seconds = 3 hours minimum
            min_seconds_between_tweets = 10800
            
            if elapsed.total_seconds() < min_seconds_between_tweets:
                remaining = min_seconds_between_tweets - elapsed.total_seconds()
                hours, remainder = divmod(int(remaining), 3600)
                minutes, seconds = divmod(remainder, 60)
                time_remaining = f"{hours}h {minutes}m {seconds}s"
                
                logger.info(f"COOLDOWN ACTIVE: Must wait {time_remaining} before next tweet (min 3h between tweets)")
                return False
            
            # Additional strategic cooldown check from config
            if elapsed.total_seconds() < self.cooldown_minutes * 60:
                remaining = (self.cooldown_minutes * 60) - elapsed.total_seconds()
                logger.info(f"Strategic cooldown active. {int(remaining/60)} minutes remaining.")
                return False
        
        # If we reached this point, we're good to go
        logger.info("Rate limit check passed, it's OK to tweet")
        return True
    
    def post_coin_announcement(self, coin_data):
        """Post an announcement about a new minted coin - high priority tweets that can override daily limits"""
        # Check if we've already announced this coin
        if coin_data["id"] in self.state["announced_coins"]:
            logger.info(f"Coin {coin_data['symbol']} already announced, skipping")
            return None
        
        # Check minimum cooldown period - even critical announcements need spacing
        if self.state["last_tweet_time"]:
            last_tweet = datetime.fromisoformat(self.state["last_tweet_time"])
            elapsed = datetime.now() - last_tweet
            
            # Apply 45-minute minimum for coin announcements - these are important but need some spacing
            # 2700 seconds = 45 minutes minimum
            min_seconds_between_tweets = 2700 
            
            if elapsed.total_seconds() < min_seconds_between_tweets:
                remaining = min_seconds_between_tweets - elapsed.total_seconds()
                hours, remainder = divmod(int(remaining), 3600)
                minutes, seconds = divmod(remainder, 60)
                time_remaining = f"{hours}h {minutes}m {seconds}s"
                
                logger.info(f"COOLDOWN FOR COIN ANNOUNCEMENT: Must wait {time_remaining} before announcement (min 45min between tweets)")
                return None
        
        # Track attempt count for retries
        max_attempts = 3
        current_attempt = 0
        retry_delay = 60  # seconds
        
        while current_attempt < max_attempts:
            current_attempt += 1
            
            try:
                logger.info(f"Generating coin announcement for {coin_data['symbol']} (attempt {current_attempt}/{max_attempts})")
                
                # Generate the tweet
                tweet_text = self.tweet_generator.generate_coin_announcement(coin_data)
                
                # Check if tweet generation was successful
                if not tweet_text or tweet_text.startswith("Error") or "TechnicalDifficulties" in tweet_text:
                    logger.warning(f"Coin announcement generation failed (attempt {current_attempt}/{max_attempts})")
                    if current_attempt < max_attempts:
                        logger.info(f"Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                        continue
                    else:
                        logger.error("Max attempts reached. Coin announcement generation failed.")
                        return None
                
                # Find image path if available
                image_path = coin_data.get("image_path")
                if image_path and os.path.exists(image_path):
                    logger.info(f"Using image for announcement: {image_path}")
                else:
                    logger.info("No image available for coin announcement")
                    image_path = None
                
                # Attempt to post tweet
                logger.info(f"Posting announcement for {coin_data['symbol']} to Twitter...")
                tweet_id = self.twitter.post_tweet(tweet_text, image_path)
                
                if tweet_id:
                    logger.info(f"Successfully posted coin announcement (ID: {tweet_id}) for {coin_data['symbol']}")
                    
                    # Update the state
                    self.state["last_tweet_time"] = datetime.now().isoformat()
                    self.state["daily_tweet_count"] += 1
                    self.state["total_tweets"] += 1
                    self.state["announced_coins"].append(coin_data["id"])
                    
                    # Add to announcement history for tracking
                    if "announcement_history" not in self.state:
                        self.state["announcement_history"] = []
                    
                    # Store coin announcements in state for monitoring
                    self.state["announcement_history"].insert(0, {
                        "id": tweet_id,
                        "coin_id": coin_data["id"],
                        "symbol": coin_data["symbol"],
                        "timestamp": datetime.now().isoformat(),
                        "text": tweet_text[:50] + "..." if len(tweet_text) > 50 else tweet_text
                    })
                    
                    # Keep only recent announcements
                    if len(self.state["announcement_history"]) > 10:
                        self.state["announcement_history"] = self.state["announcement_history"][:10]
                    
                    self.save_state()
                    return tweet_id
                else:
                    logger.warning(f"Twitter posting failed (attempt {current_attempt}/{max_attempts})")
                    if current_attempt < max_attempts:
                        logger.info(f"Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                        continue
                    else:
                        logger.error(f"Max attempts reached. Failed to post announcement for {coin_data['symbol']}")
                        return None
                
            except Exception as e:
                logger.error(f"Error posting coin announcement (attempt {current_attempt}/{max_attempts}): {str(e)}")
                if current_attempt < max_attempts:
                    logger.info(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                    continue
                else:
                    logger.error(f"Max attempts reached. Coin announcement failed with error: {str(e)}")
                    return None
        
        return None
    
    def check_and_respond_to_mentions(self):
        """Check for mentions and respond to them"""
        try:
            # Initialize variables for tracking mentions
            if "processed_mentions" not in self.state:
                self.state["processed_mentions"] = []
            
            # Load tweet generator if needed
            if not hasattr(self, 'tweet_gen') or not self.tweet_gen:
                try:
                    from tweet_logic import TweetGenerator
                    from tweet_styles import TweetStyle
                    self.tweet_gen = TweetGenerator()
                    logger.info("Loaded tweet generator for mention responses")
                except Exception as e:
                    logger.error(f"Error initializing tweet generator for mentions: {e}")
                    return False
            
            # Get mentions using the Twitter API
            mentions = self.twitter.get_account_mentions(count=20)
            if not mentions:
                logger.info("No new mentions found")
                return False
            
            # Track mentions we've responded to
            processed_count = 0
            
            # Process mentions with limit on daily responses
            daily_mention_responses = self.state.get("daily_mention_responses", 0)
            max_daily_responses = 8  # Maximum of 8 responses per day
            
            # Check the timestamp for the daily response count reset
            today = datetime.now().strftime("%Y-%m-%d")
            response_count_date = self.state.get("response_count_date", "")
            
            # Reset the counter if it's a new day
            if today != response_count_date:
                daily_mention_responses = 0
                self.state["response_count_date"] = today
            
            # Process each mention
            for mention in mentions:
                mention_id = mention.id
                
                # Skip if we've already processed this mention
                if mention_id in self.state["processed_mentions"]:
                    continue
                
                # Limit the number of daily responses
                if daily_mention_responses >= max_daily_responses:
                    logger.info(f"Daily mention response limit reached ({max_daily_responses})")
                    break
                
                # Get the mention text and user info
                mention_text = mention.text
                mention_author = mention.author_id  # This is the user ID
                
                # Skip our own tweets, mentions without text, or mentions older than 24 hours
                if (mention_author == self.twitter.verify_credentials().id_str or 
                    not mention_text or 
                    (datetime.now() - datetime.fromisoformat(mention.created_at)).total_seconds() > 24*60*60):
                    self.state["processed_mentions"].append(mention_id)
                    continue
                
                logger.info(f"Processing mention: {mention_text[:50]}...")
                
                try:
                    # Generate a reply using our spam detection capabilities
                    from tweet_styles import TweetStyle
                    # This will automatically detect spam and handle it accordingly
                    reply_text = self.tweet_gen.generate_reply(mention_text)
                    
                    # Post the reply
                    reply_id = self.twitter.post_reply(reply_text, mention_id)
                    
                    if reply_id:
                        logger.info(f"Posted reply to mention {mention_id}: {reply_text[:50]}...")
                        
                        # Update tracking
                        self.state["processed_mentions"].append(mention_id)
                        daily_mention_responses += 1
                        processed_count += 1
                        
                        # Update state variables
                        self.state["last_tweet_time"] = datetime.now().isoformat()
                        self.state["total_tweets"] = self.state.get("total_tweets", 0) + 1
                        self.state["daily_mention_responses"] = daily_mention_responses
                        self.save_state()
                    
                except Exception as e:
                    logger.error(f"Error responding to mention {mention_id}: {e}")
            
            # Trim processed mentions list to keep only the most recent 100
            if len(self.state["processed_mentions"]) > 100:
                self.state["processed_mentions"] = self.state["processed_mentions"][-100:]
            
            # Save updated state
            self.save_state()
            
            if processed_count > 0:
                logger.info(f"Processed {processed_count} new mentions")
            
            return True
            
        except Exception as e:
            logger.error(f"Error handling mentions: {e}")
            return False
    
    def post_scheduled_tweet(self, tweet_type="daily", style_override=None):
        """Post a scheduled tweet based on the specified style or time of day"""
        # Check rate limits
        if not self.check_rate_limits():
            logger.info("Rate limits prevent posting scheduled tweet at this time")
            return None
        
        # Determine tweet type based on style_override or time of day
        if style_override:
            # TweetStyle is already imported at the top level
            tweet_category = style_override.name.lower()
            logger.info(f"Using specified tweet style: {tweet_category}")
            
            # For REPLY_SNIPE, try to reply to a mention first
            if style_override == TweetStyle.REPLY_SNIPE:
                mention_reply = self.handle_mentions()
                if mention_reply:
                    logger.info("Found and replied to mention at scheduled REPLY_SNIPE time")
                    return mention_reply
                else:
                    logger.info("No mentions to reply to at scheduled REPLY_SNIPE time, using standard tweet")
                    tweet_category = "market_commentary"  # Fallback
        else:
            # Fallback to time-based categorization if no style override
            hour = datetime.now().hour
            
            # Determine tweet type based on time of day for better organization
            if 5 <= hour < 12:
                tweet_category = "morning"
            elif 12 <= hour < 18:
                tweet_category = "market_commentary"
            else:
                tweet_category = "night"
        
        # Track attempt count for retries
        max_attempts = 3
        current_attempt = 0
        retry_delay = 30  # seconds
        
        while current_attempt < max_attempts:
            current_attempt += 1
            
            try:
                logger.info(f"Generating {tweet_category} tweet (attempt {current_attempt}/{max_attempts})")
                
                # Handle special case for MINI_THREAD style
                if style_override == TweetStyle.MINI_THREAD:
                    # Handle mini thread (two tweets with blank line between)
                    logger.info("Generating MINI_THREAD style with two connected tweets")
                    try:
                        thread_text = self.tweet_generator.generate_tweet(
                            "Create a mini-thread of exactly TWO connected tweets about market psychology or economics, separated by one blank line",
                            style=style_override
                        )
                        
                        # Split the thread by blank line
                        if "\n\n" in thread_text:
                            tweets = thread_text.split("\n\n", 1)
                            
                            if len(tweets) == 2:
                                # Post first tweet
                                first_tweet = tweets[0].strip()
                                logger.info(f"Posting first tweet of mini-thread: {first_tweet[:50]}...")
                                first_tweet_id = self.twitter.post_tweet(first_tweet)
                                
                                if first_tweet_id:
                                    # Wait a moment before posting reply
                                    time.sleep(5)
                                    
                                    # Post second tweet as a reply
                                    second_tweet = tweets[1].strip()
                                    logger.info(f"Posting second tweet as reply: {second_tweet[:50]}...")
                                    second_tweet_id = self.twitter.post_reply(second_tweet, first_tweet_id)
                                    
                                    if second_tweet_id:
                                        logger.info(f"Successfully posted mini-thread")
                                        
                                        # Update the state
                                        self.state["last_tweet_time"] = datetime.now().isoformat()
                                        self.state["daily_tweet_count"] = self.state.get("daily_tweet_count", 0) + 1
                                        self.state["total_tweets"] = self.state.get("total_tweets", 0) + 1
                                        
                                        # Add to tweet history for tracking
                                        if "tweet_history" not in self.state:
                                            self.state["tweet_history"] = []
                                        
                                        # Store both tweets in the history
                                        self.state["tweet_history"].insert(0, {
                                            "id": second_tweet_id,
                                            "type": "mini_thread_reply",
                                            "timestamp": datetime.now().isoformat(),
                                            "text": second_tweet[:50] + "..." if len(second_tweet) > 50 else second_tweet
                                        })
                                        
                                        self.state["tweet_history"].insert(0, {
                                            "id": first_tweet_id,
                                            "type": "mini_thread_main",
                                            "timestamp": datetime.now().isoformat(),
                                            "text": first_tweet[:50] + "..." if len(first_tweet) > 50 else first_tweet
                                        })
                                        
                                        # Keep only last 10 entries
                                        if len(self.state["tweet_history"]) > 10:
                                            self.state["tweet_history"] = self.state["tweet_history"][:10]
                                        
                                        self.save_state()
                                        return second_tweet_id
                                    
                                    # If second tweet fails, we still have the first one as tweet_text
                                    tweet_text = first_tweet
                                    tweet_id = first_tweet_id
                                    return tweet_id
                        
                        # If splitting failed, just use the whole text as a single tweet
                        tweet_text = thread_text
                        
                    except Exception as e:
                        logger.error(f"Error generating mini-thread: {e}")
                        # Fall back to philosophy style if mini-thread fails
                        tweet_text = self.tweet_generator.generate_night_tweet()
                
                # Handle special case for POLL_CONFESSION style
                elif style_override == TweetStyle.POLL_CONFESSION:
                    logger.info("Generating POLL_CONFESSION style")
                    tweet_text = self.tweet_generator.generate_tweet(
                        "Create a humorous confession about trading psychology that other traders will relate to",
                        style=style_override
                    )
                    
                # Handle special case for PHILOSOPHY_DROP style
                elif style_override == TweetStyle.PHILOSOPHY_DROP:
                    logger.info("Generating PHILOSOPHY_DROP style")
                    tweet_text = self.tweet_generator.generate_tweet(
                        "Create a philosophical observation about markets, economics, or human psychology",
                        style=style_override
                    )
                    
                # Generate tweet based on standard categories
                elif tweet_category == "morning" or style_override == TweetStyle.GM_RIFF:
                    tweet_text = self.tweet_generator.generate_morning_tweet()
                elif tweet_category == "market_commentary" or style_override == TweetStyle.REPLY_SNIPE:
                    tweet_text = self.tweet_generator.generate_quote_tweet()
                else:
                    tweet_text = self.tweet_generator.generate_night_tweet()
                
                # Check if tweet generation was successful
                if not tweet_text or tweet_text.startswith("Error") or "TechnicalDifficulties" in tweet_text:
                    logger.warning(f"Tweet generation failed (attempt {current_attempt}/{max_attempts})")
                    if current_attempt < max_attempts:
                        logger.info(f"Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                        continue
                    else:
                        logger.error("Max attempts reached. Tweet generation failed.")
                        return None
                
                # Attempt to post tweet
                logger.info(f"Posting {tweet_category} tweet to Twitter...")
                tweet_id = self.twitter.post_tweet(tweet_text)
                
                if tweet_id:
                    logger.info(f"Successfully posted {tweet_category} tweet (ID: {tweet_id})")
                    
                    # Update the state
                    self.state["last_tweet_time"] = datetime.now().isoformat()
                    self.state["daily_tweet_count"] += 1
                    self.state["total_tweets"] += 1
                    
                    # Add to tweet history for tracking
                    if "tweet_history" not in self.state:
                        self.state["tweet_history"] = []
                    
                    # Store last 10 tweets in state for monitoring
                    self.state["tweet_history"].insert(0, {
                        "id": tweet_id,
                        "type": tweet_category,
                        "timestamp": datetime.now().isoformat(),
                        "text": tweet_text[:50] + "..." if len(tweet_text) > 50 else tweet_text
                    })
                    
                    # Keep only last 10 entries
                    if len(self.state["tweet_history"]) > 10:
                        self.state["tweet_history"] = self.state["tweet_history"][:10]
                    
                    self.save_state()
                    return tweet_id
                else:
                    logger.warning(f"Twitter posting failed (attempt {current_attempt}/{max_attempts})")
                    if current_attempt < max_attempts:
                        logger.info(f"Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                        continue
                    else:
                        logger.error(f"Max attempts reached. Failed to post {tweet_category} tweet")
                        return None
                    
            except Exception as e:
                logger.error(f"Error in tweet workflow (attempt {current_attempt}/{max_attempts}): {str(e)}")
                if current_attempt < max_attempts:
                    logger.info(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                    continue
                else:
                    logger.error(f"Max attempts reached. Tweet process failed with error: {str(e)}")
                    return None
        
        return None
    
    def check_new_coins(self):
        """Check for new mintable coins and announce them"""
        logger.info("Checking for new minted coins that users can access")
        
        try:
            # Get latest user-mintable coins
            new_coins = self.coin_checker.check_for_new_coins()
            
            if not new_coins:
                logger.info("No new minted coins found that are ready for users")
                return False
                
            # Announce each new coin that hasn't been announced yet
            announcements_made = 0
            for coin in new_coins:
                # Skip if this coin is already in our announced list
                if coin["id"] in self.state["announced_coins"]:
                    continue
                
                # Announce the coin - override rate limits for important announcements
                tweet_id = self.post_coin_announcement(coin)
                
                if tweet_id:
                    announcements_made += 1
                    # Add a delay between announcements to avoid rate limits
                    if len(new_coins) > 1:
                        time.sleep(30 * 60)  # 30 minute delay
            
            return announcements_made > 0
            
        except Exception as e:
            logger.error(f"Error checking for new coins: {e}")
            return False
    
    def handle_mentions(self):
        """Check and respond to mentions with strategic approach using style rotation"""
        try:
            # Initialize variables for tracking mentions
            if "processed_mentions" not in self.state:
                self.state["processed_mentions"] = []
            
            # Load tweet generator if needed
            if not hasattr(self, 'tweet_gen') or not self.tweet_gen:
                try:
                    from tweet_logic import TweetGenerator
                    from tweet_styles import TweetStyle
                    self.tweet_gen = TweetGenerator()
                    logger.info("Loaded tweet generator for mention responses")
                except Exception as e:
                    logger.error(f"Error initializing tweet generator for mentions: {e}")
                    return False
            
            # Check if we've reached the daily response limit (8-10 per day as requested)
            if self.state.get("daily_response_count", 0) >= 8:
                logger.info("Daily mention response limit reached (8 max)")
                return False
                
            # Check if enough time has passed since our last response (30-60 min)
            if self.state.get("last_response_time"):
                last_response = datetime.fromisoformat(self.state["last_response_time"])
                elapsed = datetime.now() - last_response
                # Minimum 30 minutes between responses
                if elapsed.total_seconds() < 30 * 60:
                    logger.info(f"Response cooldown active. {int((30*60 - elapsed.total_seconds())/60)} minutes remaining.")
                    return False
            
            # Get mentions using the Twitter API
            logger.info("Checking for new mentions to respond to")
            try:
                mentions = self.twitter.get_account_mentions(count=20)
                if not mentions:
                    logger.info("No new mentions found")
                    return False
            except Exception as e:
                logger.error(f"Error getting mentions: {e}")
                return False
            
            # Track mentions we've responded to
            processed_count = 0
            
            # Try to get our user ID for comparing
            try:
                my_user_id = self.twitter.api_v1.verify_credentials().id_str
            except:
                logger.warning("Couldn't get our user ID, will skip self-mentions check")
                my_user_id = None
            
            # Process each mention
            for mention in mentions:
                try:
                    mention_id = mention.id
                    
                    # Skip if we've already processed this mention
                    if mention_id in self.state["processed_mentions"]:
                        continue
                    
                    # Get the mention text and user info
                    mention_text = mention.text
                    mention_author = mention.author_id  # This is the user ID
                    
                    # Skip our own tweets, mentions without text, or mentions older than 24 hours
                    if ((my_user_id and mention_author == my_user_id) or 
                        not mention_text or 
                        (hasattr(mention, 'created_at') and 
                         (datetime.now() - datetime.fromisoformat(mention.created_at)).total_seconds() > 24*60*60)):
                        self.state["processed_mentions"].append(mention_id)
                        continue
                    
                    logger.info(f"Processing mention: {mention_text[:50]}...")
                    
                    # Generate a reply using the REPLY_SNIPE style
                    from tweet_styles import TweetStyle
                    reply_text = self.tweet_gen.generate_tweet(
                        "Create a witty reply to this mention that shows your AI personality:", 
                        context=mention_text,
                        style=TweetStyle.REPLY_SNIPE
                    )
                    
                    # Post the reply
                    reply_id = self.twitter.post_reply(reply_text, mention_id)
                    
                    if reply_id:
                        logger.info(f"Posted reply to mention {mention_id}: {reply_text[:50]}...")
                        
                        # Update tracking
                        self.state["processed_mentions"].append(mention_id)
                        self.state["daily_response_count"] = self.state.get("daily_response_count", 0) + 1
                        processed_count += 1
                        
                        # Update state variables
                        self.state["last_response_time"] = datetime.now().isoformat()
                        self.state["last_tweet_time"] = datetime.now().isoformat()
                        self.state["total_tweets"] = self.state.get("total_tweets", 0) + 1
                        self.save_state()
                        
                        # Only process one mention at a time to avoid rate limits
                        return reply_id
                except Exception as e:
                    logger.error(f"Error processing mention: {e}")
                    continue
            
            # Trim processed mentions list to keep only the most recent 100
            if len(self.state["processed_mentions"]) > 100:
                self.state["processed_mentions"] = self.state["processed_mentions"][-100:]
            
            # Save updated state
            self.save_state()
            
            if processed_count > 0:
                logger.info(f"Processed {processed_count} new mentions")
                return True
            
            # If we get here, no successful response was made
            logger.info("No mentions processed this run")
            return None
            
        except Exception as e:
            logger.error(f"Error handling mentions: {e}")
            return False
    
    def setup_schedule(self):
        """Set up the scheduled tasks with jitter for more human-like behavior"""
        # Check for new minted coins every 15 minutes
        schedule.every(15).minutes.do(self.check_new_coins)
        
        # Schedule daily tweets at specific times with ±15 min jitter
        # Following the required tweet types at specific times:
        # - 09:00 (±15m): gm_riff
        # - 12:30 (±15m): reply_snipe (if mention found, else skip)
        # - 16:00 (±15m): philosophy_drop
        # - 20:30 (±15m): mini_thread
        import random
        from tweet_styles import TweetStyle
        
        # Calculate jittered times with specific styles
        self.tweet_schedule = []
        
        # GM morning riff around 9:00 AM
        minutes_jitter_morning = random.randint(-15, 15)
        morning_hour = 9
        morning_min = max(0, minutes_jitter_morning)  # Ensure we don't go below 0 minutes
        morning_time = f"{morning_hour:02d}:{morning_min:02d}"
        self.tweet_schedule.append((morning_time, TweetStyle.GM_RIFF))
        
        # Check for mentions to reply at 12:30 PM
        minutes_jitter_noon = random.randint(-15, 15)
        noon_hour = 12
        noon_min = 30 + minutes_jitter_noon
        if noon_min >= 60:
            noon_hour += 1
            noon_min -= 60
        elif noon_min < 0:
            noon_hour -= 1
            noon_min += 60
        noon_time = f"{noon_hour:02d}:{noon_min:02d}"
        self.tweet_schedule.append((noon_time, TweetStyle.REPLY_SNIPE))
        
        # Philosophy drop at 16:00 (4 PM)
        minutes_jitter_afternoon = random.randint(-15, 15)
        afternoon_hour = 16
        afternoon_min = minutes_jitter_afternoon
        if afternoon_min >= 60:
            afternoon_hour += 1
            afternoon_min -= 60
        elif afternoon_min < 0:
            afternoon_hour -= 1
            afternoon_min += 60
        afternoon_time = f"{afternoon_hour:02d}:{afternoon_min:02d}"
        self.tweet_schedule.append((afternoon_time, TweetStyle.PHILOSOPHY_DROP))
        
        # Mini thread at 20:30 (8:30 PM)
        minutes_jitter_evening = random.randint(-15, 15)
        evening_hour = 20
        evening_min = 30 + minutes_jitter_evening
        if evening_min >= 60:
            evening_hour += 1
            evening_min -= 60
        elif evening_min < 0:
            evening_hour -= 1
            evening_min += 60
        evening_time = f"{evening_hour:02d}:{evening_min:02d}"
        self.tweet_schedule.append((evening_time, TweetStyle.MINI_THREAD))
        
        # Random 10% daily chance for poll_confession (approx 3 times per month)
        if random.random() < 0.1:  # 10% chance
            random_hour = random.randint(14, 22)  # Between 2 PM and 10 PM
            random_min = random.randint(0, 59)
            random_time = f"{random_hour:02d}:{random_min:02d}"
            self.tweet_schedule.append((random_time, TweetStyle.POLL_CONFESSION))
        
        # Schedule each jittered time with its specific style
        for time_slot, style in self.tweet_schedule:
            schedule.every().day.at(time_slot).do(self.post_scheduled_tweet, style_override=style)
            logger.info(f"Scheduled {style.name} tweet at {time_slot}")
        
        # Check for mentions every 30 minutes
        schedule.every(30).minutes.do(self.handle_mentions)
        
        logger.info(f"Tweet schedule initialized with jitter (human-like variability)")
        logger.info(f"Regular tweets: {len(self.tweet_schedule)} per day")
        logger.info(f"Mention checks scheduled every 30 minutes")
    
    def check_twitter_health(self):
        """Check the health of the Twitter bot and ensure it's operating correctly"""
        try:
            # Check when the last tweet was made
            if not self.state.get("last_tweet_time"):
                logger.warning("No tweets have been made yet")
                return False
            
            # Calculate time since last tweet
            last_tweet_time = datetime.fromisoformat(self.state["last_tweet_time"])
            time_since_last_tweet = datetime.now() - last_tweet_time
            
            # If no tweet in the last 24 hours, there might be an issue
            if time_since_last_tweet.total_seconds() > 24 * 60 * 60:
                logger.warning(f"No tweets in the last 24 hours (last tweet was {time_since_last_tweet.total_seconds()/3600:.1f} hours ago)")
                
                # Save the alert to state for tracking
                if "alerts" not in self.state:
                    self.state["alerts"] = []
                
                self.state["alerts"].insert(0, {
                    "type": "no_recent_tweets",
                    "timestamp": datetime.now().isoformat(),
                    "details": f"No tweets in {time_since_last_tweet.total_seconds()/3600:.1f} hours"
                })
                
                # Keep only the most recent alerts
                if len(self.state["alerts"]) > 10:
                    self.state["alerts"] = self.state["alerts"][:10]
                
                self.save_state()
                return False
            
            # All health checks passed
            return True
            
        except Exception as e:
            logger.error(f"Error checking Twitter health: {e}")
            return False
    
    def force_tweet_if_necessary(self):
        """If we haven't tweeted in too long, force a tweet to maintain activity"""
        try:
            # Check if we need to force a tweet
            if not self.state.get("last_tweet_time"):
                logger.warning("No tweets have been made yet, forcing a tweet")
                return self.post_scheduled_tweet("forced_recovery")
            
            # Calculate time since last tweet
            last_tweet_time = datetime.fromisoformat(self.state["last_tweet_time"])
            time_since_last_tweet = datetime.now() - last_tweet_time
            
            # If no tweet in the last 24 hours, force a tweet
            if time_since_last_tweet.total_seconds() > 24 * 60 * 60:
                logger.warning(f"No tweets in the last 24 hours, forcing a tweet to maintain activity")
                return self.post_scheduled_tweet("forced_recovery")
            
            return None
        except Exception as e:
            logger.error(f"Error in force tweet logic: {e}")
            return None
    
    def run(self, continuous=True):
        """Run the Twitter bot"""
        # Set up scheduled tasks
        self.setup_schedule()
        
        # Add heartbeat check every 6 hours
        schedule.every(6).hours.do(self.check_twitter_health)
        
        # Initial check for new coins
        self.check_new_coins()
        
        # Force a tweet if we haven't tweeted in a while
        self.force_tweet_if_necessary()
        
        if not continuous:
            # Run pending tasks once and exit
            schedule.run_pending()
            logger.info("Single-run mode complete")
            return
        
        # Track continuous operation stats
        startup_time = datetime.now()
        last_health_log = datetime.now()
        health_log_interval = 60 * 60  # Log health status every hour
        
        # Main loop for continuous operation
        while True:
            try:
                # Run pending scheduled tasks
                schedule.run_pending()
                
                # Periodically log health status for monitoring
                time_since_health_log = (datetime.now() - last_health_log).total_seconds()
                if time_since_health_log >= health_log_interval:
                    uptime = datetime.now() - startup_time
                    days, remainder = divmod(uptime.total_seconds(), 86400)
                    hours, remainder = divmod(remainder, 3600)
                    minutes, _ = divmod(remainder, 60)
                    
                    logger.info(f"Health Status - Uptime: {int(days)}d {int(hours)}h {int(minutes)}m, "
                               f"Total tweets: {self.state.get('total_tweets', 0)}, "
                               f"Today's tweets: {self.state.get('daily_tweet_count', 0)}")
                    
                    last_health_log = datetime.now()
                
                # Sleep to prevent high CPU usage
                time.sleep(60)  # Check every minute
            except KeyboardInterrupt:
                logger.info("Twitter bot manually stopped")
                break
            except Exception as e:
                logger.error(f"Error in main loop: {e}", exc_info=True)
                
                # Add error to state for tracking
                if "errors" not in self.state:
                    self.state["errors"] = []
                
                self.state["errors"].insert(0, {
                    "timestamp": datetime.now().isoformat(),
                    "error": str(e)
                })
                
                # Keep only recent errors
                if len(self.state["errors"]) > 20:
                    self.state["errors"] = self.state["errors"][:20]
                
                self.save_state()
                
                # Sleep longer on error to avoid rapid failure loops
                time.sleep(300)  # Sleep 5 minutes on error

# For direct testing
if __name__ == "__main__":
    try:
        bot = TwitterBot()
        
        # Command-line argument for single run vs continuous mode
        import sys
        continuous_mode = True
        if len(sys.argv) > 1 and sys.argv[1] == "once":
            continuous_mode = False
            print("Running in single-execution mode")
        
        bot.run(continuous=continuous_mode)
    except Exception as e:
        logger.critical(f"Fatal error: {e}", exc_info=True)