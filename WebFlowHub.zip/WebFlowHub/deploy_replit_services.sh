#!/bin/bash

# Mind9 Deploy Helper for Replit Reserved VM
# This script helps deploy Mind9 on a Replit Reserved VM with proper service setup

echo "=================================================="
echo "  Mind9 Deployment Helper for Replit Reserved VM"
echo "=================================================="
echo ""

# Check for root/sudo access
if [ "$(id -u)" -ne 0 ]; then
  echo "⚠️  Not running as root. Some system installations may fail."
  echo "    Consider running with sudo if you encounter permission errors."
  echo ""
fi

# Create logs directory
mkdir -p logs

# 1. Fix Canvas dependencies
echo "Step 1: Installing Canvas dependencies..."
if command -v apt-get &> /dev/null; then
  apt-get update -y
  apt-get install -y libcairo2-dev libjpeg-dev libpango1.0-dev libgif-dev librsvg2-dev libuuid1 build-essential
  echo "✓ Canvas dependencies installed via apt"
else
  echo "⚠️  apt-get not available. Using replit.nix for Canvas dependencies"
  # Create replit.nix file with Canvas dependencies
  cat > replit.nix << 'EOL'
{ pkgs }: {
  deps = [
    pkgs.nodejs-20_x
    pkgs.python311
    pkgs.postgresql_16
    pkgs.nodePackages.typescript
    pkgs.nodePackages.npm
    
    # Canvas dependencies
    pkgs.cairo
    pkgs.pango
    pkgs.libuuid
    pkgs.libpng
    pkgs.libjpeg
    pkgs.giflib
    pkgs.librsvg
    pkgs.pkg-config
  ];
  
  env = {
    LD_LIBRARY_PATH = pkgs.lib.makeLibraryPath [
      pkgs.libuuid
      pkgs.cairo
      pkgs.pango
      pkgs.libpng
      pkgs.libjpeg
      pkgs.giflib
      pkgs.librsvg
    ];
  };
}
EOL
  echo "✓ Canvas dependencies configured in replit.nix"
fi

# 2. Fix npm and Canvas installation
echo "Step 2: Setting up npm and rebuilding Canvas..."
export npm_config_canvas_binary_host_mirror=https://github.com/Automattic/node-canvas/releases/download/
export CXXFLAGS="--std=c++14"

# Rebuild canvas specifically
echo "  Rebuilding Canvas package..."
npm rebuild canvas --build-from-source || echo "⚠️  Canvas rebuild failed, but deployment can continue."

# 3. Install system monitoring tools
echo "Step 3: Installing system monitoring tools..."
if command -v apt-get &> /dev/null; then
  apt-get install -y net-tools procps lsof || echo "⚠️  Some monitoring tools couldn't be installed"
  echo "✓ System monitoring tools installed"
else
  echo "⚠️  apt-get not available. Using fallback monitoring methods."
fi

# 4. Create the .replit file for proper configuration
echo "Step 4: Creating .replit configuration..."
cat > .replit << 'EOL'
run = "bash start_replit_services.sh"
entrypoint = "main.py"
hidden = [".config", ".vscode", ".npm", "node_modules", ".gitignore", "canvas_fix.sh", "deploy_replit_services.sh"]

[nix]
channel = "stable-22_11"

[auth]
pageEnabled = false
buttonEnabled = false

[env]
HOST = "0.0.0.0"
PORT = "5000"

[deployment]
run = ["sh", "-c", "node server/index.js"]
build = ["sh", "-c", "./build.sh"]

[languages]
[languages.javascript]
pattern = "**/{*.js,*.jsx,*.ts,*.tsx}"
[languages.javascript.languageServer]
start = "typescript-language-server --stdio"
[languages.python]
pattern = "**/{*.py}"
[languages.python.languageServer]
start = "pylsp"
EOL
echo "✓ .replit configuration created"

# 5. Create service startup script
echo "Step 5: Creating service startup script..."
cat > start_replit_services.sh << 'EOL'
#!/bin/bash

# Mind9 Service Startup for Replit Reserved VM
echo "Starting Mind9 services..."

# Find Python path
PYTHON_PATH=$(which python3.11 || which python3 || which python || echo "python3")
echo "Using Python path: $PYTHON_PATH"

# Start health monitor in background
echo "Starting health monitor..."
nohup ./health_monitor_replit.sh > logs/health_monitor.log 2>&1 &

# Start services (health monitor will ensure they keep running)
export HOST=0.0.0.0
export PORT=5000
npm run dev &

echo "Mind9 services started. Opening UI..."
sleep 5

# Open UI by visiting our port
if command -v curl &> /dev/null; then
  # Automatically trigger a page load, but don't output anything
  curl -s http://localhost:5000 > /dev/null 2>&1 || true
fi

echo ""
echo "Mind9 is now running"
echo "Web UI available at: http://localhost:5000"
echo ""
echo "Close this terminal to continue running in the background"
echo "Monitor logs are in the 'logs' directory"
EOL
chmod +x start_replit_services.sh
echo "✓ Service startup script created"

# 6. Create deployment build script
echo "Step 6: Creating build script for deployment..."
cat > build.sh << 'EOL'
#!/bin/bash
# Set NPM config for Canvas
export npm_config_canvas_binary_host_mirror=https://github.com/Automattic/node-canvas/releases/download/
export CXXFLAGS="--std=c++14"

# Install system dependencies required by Canvas
echo "Installing system dependencies for Canvas..."
if command -v apt-get &> /dev/null; then
  apt-get update
  apt-get install -y libcairo2-dev libjpeg-dev libpango1.0-dev libgif-dev librsvg2-dev build-essential
fi

# Ensure packages are installed
echo "Installing npm packages..."
npm install --build-from-source || npm install

# Rebuild canvas specifically
echo "Rebuilding canvas..."
npm rebuild canvas --update-binary || true

# Build the application
echo "Building application..."
npm run build

# Make scripts executable
chmod +x *.sh

# Notify build complete
echo "Build completed successfully!"
EOL
chmod +x build.sh
echo "✓ Build script created"

echo ""
echo "=================================================="
echo "  Mind9 Deployment Setup Complete!"
echo "=================================================="
echo ""
echo "To start Mind9 services:"
echo "  ./start_replit_services.sh"
echo ""
echo "To ensure 24/7 operation on Reserved VM:"
echo "  nohup ./reserved_vm_fixed.sh > logs/reserved_vm.log 2>&1 &"
echo ""
echo "To deploy to Replit:"
echo "  Go to the Deployments tab in Replit"
echo "  Click Deploy"
echo ""
echo "=================================================="