/**
 * Test script for token creation and verification
 * This script creates a test token and then verifies it on the blockchain
 */

import fetch from 'node-fetch';
import { verifyToken } from './verify_token.js';

// Configuration
const API_BASE_URL = 'http://localhost:5000';

// Check environment
if (!process.env.RPC_ENDPOINT || !process.env.CREATOR_WALLET_ADDRESS || !process.env.SOLANA_PRIVATE_KEY) {
  console.error(`
ERROR: Missing required environment variables. 
The following are required:
- RPC_ENDPOINT: Solana RPC endpoint
- CREATOR_WALLET_ADDRESS: The wallet address that will own the token
- SOLANA_PRIVATE_KEY: Private key of the creator wallet (for signing transactions)
`);
  process.exit(1);
}

// Generate a random token name and symbol for testing
function generateTestToken() {
  const prefixes = ['Test', 'Demo', 'Mock', 'Beta', 'Sample'];
  const suffixes = ['Coin', 'Token', 'Cash', 'Money', 'Crypto', 'Finance', 'Capital'];
  const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const randomSuffix = suffixes[Math.floor(Math.random() * suffixes.length)];
  const name = `${randomPrefix} ${randomSuffix}`;
  
  // Create a symbol from the first letters of each word
  const symbol = name.split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase();
  
  return { name, symbol };
}

// Create a token using the API
async function createToken(name, symbol) {
  console.log(`Creating token: ${name} (${symbol})...`);
  
  try {
    const response = await fetch(`${API_BASE_URL}/api/test-token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ name, symbol })
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API error (${response.status}): ${errorText}`);
    }
    
    const result = await response.json();
    
    if (!result.success) {
      throw new Error(`Token creation failed: ${result.message}`);
    }
    
    console.log(`✅ Token created successfully!`);
    console.log(`Mint address: ${result.mintAddress}`);
    
    return result;
  } catch (error) {
    console.error(`Error creating token:`, error);
    return { success: false, error: error.message };
  }
}

// Main function
async function main() {
  try {
    console.log('Starting token creation and verification test...');
    
    // Step 1: Generate random token data
    const testToken = generateTestToken();
    console.log(`Generated test token: ${testToken.name} (${testToken.symbol})`);
    
    // Step 2: Create the token
    const creationResult = await createToken(testToken.name, testToken.symbol);
    
    if (!creationResult.success) {
      console.error('❌ Token creation failed, aborting test.');
      process.exit(1);
    }
    
    // Step 3: Verify the token on-chain
    console.log('\nVerifying token on Solana blockchain...');
    const verificationResult = await verifyToken(creationResult.mintAddress);
    
    if (verificationResult.verified) {
      console.log('\n✅ Token verified successfully on Solana blockchain!');
      console.log(`Token details:`);
      console.log(`- Name: ${testToken.name}`);
      console.log(`- Symbol: ${testToken.symbol}`);
      console.log(`- Mint address: ${creationResult.mintAddress}`);
      console.log(`- Creator balance: ${verificationResult.creatorBalance}`);
      console.log(`- Decimals: ${verificationResult.decimals}`);
      
      console.log('\n🎉 Test completed successfully! 🎉');
      process.exit(0);
    } else {
      console.error('\n❌ Token verification failed:');
      console.error(verificationResult.error);
      process.exit(1);
    }
  } catch (error) {
    console.error('Error running test:', error);
    process.exit(1);
  }
}

// Run the script
main().catch(err => {
  console.error('Unhandled error:', err);
  process.exit(1);
});