"""
Coin Manager for Mind9
Handles Solana token minting, verification, and database management.
This module provides admin-only functions for coin creation.
"""

import os
import json
import logging
import time
import psycopg2
from psycopg2.extras import RealDictCursor
from datetime import datetime
import base58
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("coin_manager.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("mind9_coin_manager")

# Load environment variables
load_dotenv()

class CoinManager:
    def __init__(self):
        """Initialize the coin manager"""
        self.db_url = os.getenv('DATABASE_URL')
        self.connection_pool = None
        self.connect_to_db()
        
    def connect_to_db(self):
        """Connect to the PostgreSQL database"""
        try:
            if self.db_url:
                self.connection_pool = psycopg2.pool.SimpleConnectionPool(
                    1, 20, self.db_url
                )
                logger.info("Connected to PostgreSQL database")
            else:
                logger.error("DATABASE_URL environment variable not set")
        except Exception as e:
            logger.error(f"Error connecting to database: {e}")
    
    def get_connection(self):
        """Get a database connection"""
        if self.connection_pool:
            return self.connection_pool.getconn()
        return None
    
    def release_connection(self, conn):
        """Release a connection back to the pool"""
        if self.connection_pool and conn:
            self.connection_pool.putconn(conn)
    
    def check_mint_exists(self, mint_address):
        """
        Check if a Solana token mint address exists and is valid
        This connects to the Solana RPC endpoint to verify the mint
        """
        # This is just a basic check - in a real implementation this would
        # make a call to the Solana RPC to verify the token exists
        if not mint_address or len(mint_address) < 32:
            return False
            
        # In production, you would validate the mint address exists on Solana
        # using the Solana web3.js library or making an RPC request
        return True
    
    def admin_create_coin(self, name, symbol, description, mint_address, total_supply="1,000,000"):
        """
        ADMIN ONLY: Create a new coin entry
        This function should only be called manually by an admin
        
        Returns:
            dict: The newly created coin data if successful
            None: If the operation fails
        """
        logger.info(f"ADMIN requested coin creation: {name} ({symbol})")
        
        # Validate inputs
        if not name or not symbol or not description or not mint_address:
            logger.error("Missing required parameters for coin creation")
            return None
            
        # Check if mint address appears valid
        if not self.check_mint_exists(mint_address):
            logger.error(f"Invalid mint address: {mint_address}")
            return None
            
        conn = None
        try:
            conn = self.get_connection()
            if not conn:
                logger.error("No database connection available")
                return None
                
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            
            # Check if this mint address already exists in the database
            cursor.execute(
                "SELECT id FROM coins WHERE mint_address = %s",
                (mint_address,)
            )
            if cursor.fetchone():
                logger.error(f"A coin with mint address {mint_address} already exists")
                return None
            
            # Set up tokenomics with the required distribution
            tokenomics = {
                "liquidityPool": 70,
                "tradingFund": 20, 
                "creator": 5,
                "luckyTrader": 3,
                "systemOperations": 2
            }
            
            # Default values for liquidity
            liquidity_amount = str(int(total_supply.replace(',', '')) * 0.7)  # 70% in liquidity
            liquidity_sol = "2.0"  # Default 2 SOL in liquidity
            
            # Insert new coin with minted=True since this is an admin action
            cursor.execute("""
                INSERT INTO coins 
                (name, symbol, mint_address, description, total_supply, tokenomics, 
                liquidity_amount, liquidity_sol, timestamp, lucky_trader_wallet, minted, user_mintable)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
            """, (
                name, symbol, mint_address, description, total_supply, 
                json.dumps(tokenomics), liquidity_amount, liquidity_sol,
                datetime.now(), "ADMIN_CREATED", True, True
            ))
            
            new_coin = cursor.fetchone()
            conn.commit()
            
            logger.info(f"Successfully created coin: {name} ({symbol}) with mint address {mint_address}")
            return dict(new_coin)
            
        except Exception as e:
            if conn:
                conn.rollback()
            logger.error(f"Error creating coin: {e}")
            return None
        finally:
            if conn:
                self.release_connection(conn)
    
    def verify_coin_minted(self, coin_id):
        """
        Verify and update a coin's minted status
        This would connect to Solana to verify the token exists and update the database
        
        Returns:
            bool: True if coin is verified as minted, False otherwise
        """
        conn = None
        try:
            conn = self.get_connection()
            if not conn:
                logger.error("No database connection available")
                return False
                
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            
            # Get the coin record
            cursor.execute(
                "SELECT * FROM coins WHERE id = %s",
                (coin_id,)
            )
            coin = cursor.fetchone()
            
            if not coin:
                logger.error(f"Coin with ID {coin_id} not found")
                return False
                
            # In production, you would connect to Solana RPC and verify the mint_address exists
            # and has the proper supply and metadata
            mint_exists = self.check_mint_exists(coin['mint_address'])
            
            if mint_exists:
                # Update the coin status to minted
                cursor.execute(
                    "UPDATE coins SET minted = TRUE WHERE id = %s",
                    (coin_id,)
                )
                conn.commit()
                logger.info(f"Verified coin {coin['symbol']} (ID: {coin_id}) is minted")
                return True
            else:
                logger.warning(f"Coin {coin['symbol']} (ID: {coin_id}) verification failed")
                return False
                
        except Exception as e:
            if conn:
                conn.rollback()
            logger.error(f"Error verifying coin: {e}")
            return False
        finally:
            if conn:
                self.release_connection(conn)
    
    def make_coin_mintable(self, coin_id):
        """
        Set a coin's user_mintable status to True
        This is an admin-only operation
        
        Returns:
            bool: True if update was successful, False otherwise
        """
        conn = None
        try:
            conn = self.get_connection()
            if not conn:
                logger.error("No database connection available")
                return False
                
            cursor = conn.cursor()
            
            # Update the coin to be user mintable
            cursor.execute(
                "UPDATE coins SET user_mintable = TRUE WHERE id = %s",
                (coin_id,)
            )
            
            if cursor.rowcount == 0:
                logger.error(f"Coin with ID {coin_id} not found")
                return False
                
            conn.commit()
            logger.info(f"Coin ID {coin_id} is now user mintable")
            return True
            
        except Exception as e:
            if conn:
                conn.rollback()
            logger.error(f"Error making coin mintable: {e}")
            return False
        finally:
            if conn:
                self.release_connection(conn)
    
    def get_coin_info(self, coin_id=None, mint_address=None):
        """
        Get information about a specific coin
        
        Returns:
            dict: Coin information if found
            None: If coin not found
        """
        if not coin_id and not mint_address:
            logger.error("Must provide either coin_id or mint_address")
            return None
            
        conn = None
        try:
            conn = self.get_connection()
            if not conn:
                logger.error("No database connection available")
                return None
                
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            
            if coin_id:
                cursor.execute(
                    "SELECT * FROM coins WHERE id = %s",
                    (coin_id,)
                )
            else:
                cursor.execute(
                    "SELECT * FROM coins WHERE mint_address = %s",
                    (mint_address,)
                )
                
            coin = cursor.fetchone()
            
            if not coin:
                logger.warning(f"Coin not found")
                return None
                
            return dict(coin)
            
        except Exception as e:
            logger.error(f"Error getting coin info: {e}")
            return None
        finally:
            if conn:
                self.release_connection(conn)
    
    def get_all_minted_coins(self):
        """
        Get all coins that are minted and mintable by users
        
        Returns:
            list: List of coin dictionaries
        """
        conn = None
        try:
            conn = self.get_connection()
            if not conn:
                logger.error("No database connection available")
                return []
                
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            
            cursor.execute("""
                SELECT * FROM coins 
                WHERE minted = TRUE AND user_mintable = TRUE
                ORDER BY timestamp DESC
            """)
                
            coins = cursor.fetchall()
            return [dict(coin) for coin in coins]
            
        except Exception as e:
            logger.error(f"Error getting minted coins: {e}")
            return []
        finally:
            if conn:
                self.release_connection(conn)

# For command line testing
if __name__ == "__main__":
    manager = CoinManager()
    
    # Example of admin creating a coin
    # This would normally be called from a web admin interface
    # coin = manager.admin_create_coin(
    #     name="Test Admin Coin",
    #     symbol="TAC",
    #     description="A test coin created by admin",
    #     mint_address="TESTMINTADDRESS1234567890ABCDEF1234567890ABCDEF12345"
    # )
    
    # if coin:
    #     print(f"Created coin: {coin['name']} ({coin['symbol']})")
    # else:
    #     print("Failed to create coin")