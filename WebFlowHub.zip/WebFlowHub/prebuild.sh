#!/bin/bash

# Ensure Node.js is available for deployment builds
echo "Setting up Node.js environment for deployment..."

# Source Nix profile if it exists
if [ -f "/nix/var/nix/profiles/default/etc/profile.d/nix-daemon.sh" ]; then
  source /nix/var/nix/profiles/default/etc/profile.d/nix-daemon.sh
  echo "✅ Sourced Nix profile"
else
  echo "⚠️ Nix profile not found, trying alternative methods"
fi

# Find and add Node.js to PATH using multiple approaches
echo "Locating Node.js binaries..."

# Try standard Nix store locations
NODEJS_PATH=$(find /nix/store -maxdepth 1 -name "*nodejs*" -type d | sort -r | head -n1)
if [ -n "$NODEJS_PATH" ]; then
  export PATH="$NODEJS_PATH/bin:$PATH"
  echo "✅ Added Node.js from $NODEJS_PATH to PATH"
fi

# Final check
if command -v node &> /dev/null && command -v npm &> /dev/null; then
  echo "✅ Node.js $(node -v) and npm $(npm -v) are available"
else
  echo "⚠️ Node.js or npm still not found, using explicit fallback"
  # Hard-coded fallback for Replit GCE environment
  PATH="/nix/store/hb1lzaisgx2m9n29hqhh6yp6hasplq1v-nodejs-16.17.0/bin:$PATH"
  echo "PATH is now: $PATH"
fi

# Install global dependencies if needed
npm install -g npm@latest

# Prepare the build directory
echo "Creating dist directory if it doesn't exist..."
mkdir -p dist

echo "Prebuild script completed successfully!"

# Ensure script exits on error
set -e

echo "======== Mind9 Prebuild Setup ========"
echo "Setting up Node.js environment..."

# Multiple approaches to find Node.js
echo "Searching for Node.js installations..."

# Try standard path first
NODEJS_PATH=$(ls -td /nix/store/*nodejs-18* | grep -v ".drv" | head -n1)
if [ -z "$NODEJS_PATH" ]; then
  # Try broader search
  NODEJS_PATH=$(ls -td /nix/store/*nodejs* | grep -v ".drv" | head -n1)
fi

if [ -n "$NODEJS_PATH" ]; then
  export PATH="$NODEJS_PATH/bin:$PATH"
  echo "Found Node.js at: $NODEJS_PATH"
else
  echo "Warning: Could not find Node.js in Nix store using standard method"

  # Last resort - find any nodejs directory
  NODEJS_PATH=$(find /nix/store -maxdepth 1 -name "*nodejs*" -type d | sort -r | head -n1)
  if [ -n "$NODEJS_PATH" ]; then
    export PATH="$NODEJS_PATH/bin:$PATH"
    echo "Found Node.js using alternative method at: $NODEJS_PATH"
  fi
fi

# Verify Node.js and npm are available
NODE_VERSION=$(node -v 2>/dev/null || echo 'Not found')
NPM_VERSION=$(npm -v 2>/dev/null || echo 'Not found')

echo "Node.js version: $NODE_VERSION"
echo "npm version: $NPM_VERSION"

if [[ "$NODE_VERSION" == "Not found" || "$NPM_VERSION" == "Not found" ]]; then
  echo "WARNING: Node.js or npm still not found. This will likely cause deployment errors."
  echo "Available paths that might contain Node.js:"
  find /nix/store -maxdepth 1 -name "*nodejs*" -type d
  echo "Current PATH: $PATH"
fi

# Ensure npm and node are in PATH for the build process
echo "export PATH=\"$PATH\"" > ~/.npmrc

# Try to create a symlink as a fallback
if [[ "$NODE_VERSION" == "Not found" ]]; then
  echo "Attempting to create symlinks as last resort..."
  NODEJS_CANDIDATES=$(find /nix/store -name "nodejs-*" -type d | sort -r)
  for candidate in $NODEJS_CANDIDATES; do
    if [ -d "$candidate/bin" ]; then
      echo "Creating symlinks from $candidate/bin"
      ln -sf "$candidate/bin/node" /tmp/node 2>/dev/null || true
      ln -sf "$candidate/bin/npm" /tmp/npm 2>/dev/null || true
      export PATH="/tmp:$PATH"
      break
    fi
  done
fi

# Fix permissions if needed
if [ -d "node_modules" ]; then
  echo "Fixing node_modules permissions..."
  chmod -R +x node_modules/.bin 2>/dev/null || true
fi

echo "Prebuild setup completed"