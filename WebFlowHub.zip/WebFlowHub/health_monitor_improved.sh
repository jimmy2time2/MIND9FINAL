#!/bin/bash

# Enhanced Health Monitor for Mind9
# This script continuously checks all services and restarts them if they stop
# It's designed to work specifically with Replit's environment

# Set up logging
mkdir -p logs
LOG_FILE="logs/monitor.log"

echo "Mind9 Enhanced Health Monitor Started at $(date)" | tee -a $LOG_FILE

# Create status file to indicate monitoring is active
touch .health_monitor_running
echo "$(date)" > .health_monitor_running

# Make sure all required scripts are executable
chmod +x *.sh

# Ensure log directory exists
mkdir -p logs
mkdir -p .pids

# Function to check and restart a service
check_and_restart() {
    SERVICE_NAME=$1
    PROCESS_PATTERN=$2
    START_COMMAND=$3
    LOG_FILE=$4
    
    if ! pgrep -f "$PROCESS_PATTERN" > /dev/null; then
        echo "$(date) - $SERVICE_NAME not running, restarting..." | tee -a $LOG_FILE
        eval "$START_COMMAND > logs/$LOG_FILE 2>&1 &"
        PID=$!
        echo $PID > .pids/$SERVICE_NAME.pid
        echo "$(date) - $SERVICE_NAME restarted with PID: $PID" | tee -a $LOG_FILE
    fi
}

# Main monitoring loop
while true; do
    echo "$(date) - Checking Mind9 services..." >> $LOG_FILE
    
    # Check Twitter bot
    check_and_restart "twitter_bot" "python.*twitter_bot.py" "./start_twitter_bot.sh" "twitter_bot.log"
    
    # Check Coin Promoter
    check_and_restart "coin_promoter" "python.*coin_promoter.py" "python coin_promoter.py" "coin_promoter.log"
    
    # Check Mind9 Main System
    check_and_restart "mind9" "python.*main.py" "python main.py" "mind9.log"
    
    # Update timestamp files
    echo "$(date)" > .services_running
    echo "$(date)" > .last_watchdog_run

    # Wait before next check (5 minutes)
    sleep 300
done