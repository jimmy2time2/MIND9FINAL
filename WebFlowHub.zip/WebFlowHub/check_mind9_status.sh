#!/bin/bash

# Script to check the status of all Mind9 systems
# This shows current process status and key log entries

echo "==========================================="
echo "     Mind9 Platform Status Check"
echo "==========================================="

# Check System Load
echo "System Load:"
uptime
echo ""

# Check Running Processes
echo "Mind9 Process Status:"
echo "--------------------"
ps aux | grep -E "twitter_bot.py|run_twitter_bot.py|main.py|npm run dev" | grep -v grep
echo ""

# Check Recent Twitter Bot Activity
echo "Recent Twitter Bot Activity:"
echo "--------------------------"
tail -n 10 twitter_bot_output.log 2>/dev/null || echo "No Twitter bot logs found"
echo ""

# Check Coin Database Status
echo "Coin Database Status:"
echo "-------------------"
echo "Total recovered coins: $(grep -c "token added to database" recover_coins.ts.log 2>/dev/null || echo "Log not found")"
echo "Total enhanced coins: $(grep -c "Token updated successfully" improve_tokens.ts.log 2>/dev/null || echo "Log not found")"
echo ""

# Check Available Disk Space
echo "System Resources:"
echo "---------------"
df -h | grep -E "Filesystem|/$"
echo ""

# Check if Web Server is Responding
echo "Web Server Status:"
echo "----------------"
curl -s -o /dev/null -w "Response Code: %{http_code}\n" http://localhost:5000 || echo "Web server not responding"
echo ""

echo "==========================================="
echo "For more detailed logs, use these commands:"
echo "  Twitter bot: tail -f twitter_bot_output.log"
echo "  Coin activity: tail -f mind9_continuous.log"
echo "  Error logs: tail -f mind9_error.log"
echo "==========================================="