#!/bin/bash

# Mind9 24/7 Deployment Fix
# This script applies all the necessary changes for 24/7 operation on a Reserved VM

# Define colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}###############################################################################"
echo "## 📦  MIND9 — 24 / 7 RESERVED‑VM DEPLOYMENT FIX"
echo "## This script implements the deployment fix for 24/7 operation"
echo "###############################################################################${NC}"

# Create start_persistent.sh script
echo -e "\n${YELLOW}>>> Creating start_persistent.sh${NC}"
cat > start_persistent.sh <<'EOF'
#!/usr/bin/env bash
# Keeps HTTP server + workers alive inside the Reserved VM
npx pm2-runtime dist/index.js
EOF
chmod +x start_persistent.sh
echo -e "${GREEN}✓ Created and made executable start_persistent.sh${NC}"

# Message about modifying package.json
echo -e "\n${YELLOW}>>> Package.json modifications required${NC}"
echo -e "Please manually update your package.json file:"
echo -e "1. Replace 'canvas' dependency with '@napi-rs/canvas'"
echo -e "   From: \"canvas\": \"^3.1.0\","
echo -e "   To:   \"canvas\": \"npm:@napi-rs/canvas@^0.1.37\","
echo -e "\n2. Ensure these scripts are in your package.json:"
echo -e "   \"dev\": \"vite dev\","
echo -e "   \"build\": \"vite build\","
echo -e "   \"start\": \"node dist/index.js\""

# Message about config files
echo -e "\n${YELLOW}>>> Replit configuration files${NC}"
echo -e "Please manually update your .replit file with exactly:"
echo -e "run = \"node dist/index.js\"\n"
echo -e "[deployment]"
echo -e "deploymentTarget = \"reservedvm\""
echo -e "build = [\"sh\", \"-c\", \"npm ci && npm run build\"]"
echo -e "run   = [\"sh\", \"-c\", \"./start_persistent.sh\"]\n"
echo -e "[[ports]]"
echo -e "localPort    = 5000"
echo -e "externalPort = 80"
echo -e "name         = \"Mind9-App\""
echo -e "protocol     = \"http\""

echo -e "\nAnd update your replit.nix file with exactly:"
echo -e "{ pkgs }: {"
echo -e "  deps = ["
echo -e "    pkgs.nodejs-20"
echo -e "    pkgs.libpng pkgs.cairo pkgs.pango pkgs.librsvg"
echo -e "    pkgs.pkg-config"
echo -e "  ];"
echo -e "}"

# Message about secrets
echo -e "\n${YELLOW}>>> Required secrets${NC}"
echo -e "‼️  IMPORTANT: Add these secrets in the Deploy ► Secrets panel before continuing:"
echo -e "- OPENAI_API_KEY"
echo -e "- SOLANA_PRIVATEKEY"
echo -e "- TWITTER_BEARER"

# Final instructions
echo -e "\n${YELLOW}>>> Final steps${NC}"
echo -e "After making these changes:"
echo -e "1. Commit your changes: git add -A && git commit -m \"♻️  Reserved-VM deploy: single manifest, nix libs, pre-built canvas\""
echo -e "2. Go to the Deployments tab and deploy to a Reserved VM"
echo -e "3. Verify your app is running by visiting your deployed URL"

echo -e "\n${GREEN}###############################################################################"
echo "## END OF SCRIPT"
echo "###############################################################################${NC}"