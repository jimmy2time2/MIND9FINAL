#!/bin/bash

# Mind9 Permanent Deployment Script
# This script deploys Mind9 in a way that ensures it runs persistently
# even when terminals are closed or sessions end.

echo "==========================================="
echo "     Mind9 Persistent Deployment"
echo "==========================================="

# Make all scripts executable
chmod +x *.sh

# Install PM2 if not already installed
if ! command -v pm2 &> /dev/null; then
    echo "Installing PM2 process manager..."
    npm install -g pm2
fi

# Install any missing Python packages
echo "Checking for required Python packages..."
pip install schedule psycopg2-binary python-dotenv tweepy

# Stop any existing processes
echo "Stopping any existing Mind9 processes..."
pm2 stop all 2>/dev/null || true
pm2 delete all 2>/dev/null || true
pkill -f "python.*run_twitter_bot.py" 2>/dev/null || true
pkill -f "python.*twitter_bot.py" 2>/dev/null || true
pkill -f "python.*main.py" 2>/dev/null || true
pkill -f "python.*coin_promoter.py" 2>/dev/null || true
sleep 2

# Create systemd service file if it doesn't exist
if [ ! -f /etc/systemd/system/mind9.service ]; then
    echo "Creating systemd service file..."
    sudo cp mind9.service /etc/systemd/system/
    sudo systemctl daemon-reload
    sudo systemctl enable mind9.service
    echo "Mind9 service enabled to start on system boot"
fi

# Start all Mind9 services using PM2
echo "Starting Mind9 services using PM2..."
pm2 start ecosystem.config.cjs

# Save PM2 process list to ensure restart on system reboot
echo "Saving PM2 process list for automatic restart..."
pm2 save

# Set up PM2 to start on system boot
echo "Setting up PM2 to start on system boot..."
pm2 startup

# Setup log rotation
pm2 install pm2-logrotate

# Start the systemd service as a backup
echo "Starting Mind9 systemd service..."
sudo systemctl start mind9.service

echo ""
echo "Mind9 has been deployed with multiple layers of persistence!"
echo "1. PM2 process manager is handling all services"
echo "2. Systemd service is running as a backup"
echo "All services will now continue running even when terminal is closed."
echo ""
echo "Important information about Twitter functionality:"
echo "- The Twitter bot is now configured to promote all coins"
echo "- Each coin will be promoted with a link to its minting page"
echo "- Promotion schedule is optimized to avoid rate limits"
echo "- Twitter's 24-hour rate limits are automatically respected"
echo ""
echo "To monitor services: pm2 status"
echo "To view logs: pm2 logs"
echo "To restart everything: pm2 restart all"
echo ""
echo "Application should be accessible at: http://localhost:5000"
echo ""
echo "Note: If you get an error about permissions when running pm2 startup,"
echo "      copy the suggested command and run it with sudo."
echo "==========================================="