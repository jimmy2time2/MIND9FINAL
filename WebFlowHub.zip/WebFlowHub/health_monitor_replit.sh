#!/bin/bash

# Replit-Compatible Health Monitor for Mind9
# This script monitors the health of Mind9 services on Replit and restarts them if needed

echo "Starting Mind9 Health Monitor for Replit..."
echo "Monitor started at $(date)"
echo "---------------------------------------------"

# Create logs directory if it doesn't exist
mkdir -p logs

# Function to check if a process is running by searching for its pattern
process_running() {
  local pattern="$1"
  if pgrep -f "$pattern" > /dev/null; then
    return 0  # Process is running
  else
    return 1  # Process is not running
  fi
}

# Function to check if a port is in use using multiple methods
port_in_use() {
  local port="$1"
  local hex_port=$(printf "%04x" $port)
  
  # Try different commands, in order of preference
  if command -v netstat &> /dev/null; then
    if netstat -tuln 2>/dev/null | grep -q ":$port "; then
      return 0
    fi
  elif command -v ss &> /dev/null; then
    if ss -tuln 2>/dev/null | grep -q ":$port "; then
      return 0
    fi
  elif command -v lsof &> /dev/null; then
    if lsof -i :$port 2>/dev/null; then
      return 0
    fi
  elif [ -f /proc/net/tcp ]; then
    # Convert port to hex and check in /proc/net/tcp
    if grep -q ":$hex_port " /proc/net/tcp 2>/dev/null; then
      return 0
    fi
  fi
  
  return 1  # Port is not in use
}

# Function to get Python path
get_python_path() {
  which python3.11 2>/dev/null || which python3 2>/dev/null || which python 2>/dev/null || echo "python3"
}

# Function to get NPM path
get_npm_path() {
  which npm 2>/dev/null || echo ""
}

# Find executable paths
PYTHON_PATH=$(get_python_path)
NPM_PATH=$(get_npm_path)

echo "Using Python path: $PYTHON_PATH"
echo "Using NPM path: $NPM_PATH"

# File to record monitor status
MONITOR_STATUS="logs/monitor_status.log"
touch $MONITOR_STATUS
echo "Health monitor started at $(date)" > $MONITOR_STATUS

# Create status file to indicate monitor is running
touch .monitor_running

# Main monitoring loop
while true; do
  current_time=$(date)
  echo "Monitor check at $current_time" >> $MONITOR_STATUS
  
  # Check web server (port 5000)
  if ! port_in_use 5000; then
    echo "[$current_time] Web server not running on port 5000, restarting..." | tee -a logs/monitor.log
    
    # Kill any existing server processes
    pkill -f "node server/index.js" 2>/dev/null || true
    
    # Start web server
    export HOST=0.0.0.0
    export PORT=5000
    
    if [ -n "$NPM_PATH" ]; then
      nohup $NPM_PATH run dev > logs/web_app.log 2>&1 &
      echo "[$current_time] Web server restarted with PID: $!" | tee -a logs/monitor.log
    else
      # Fallback to direct node if npm not found
      if command -v node &> /dev/null; then
        nohup node server/index.js > logs/web_app.log 2>&1 &
        echo "[$current_time] Web server restarted with direct Node.js, PID: $!" | tee -a logs/monitor.log
      else
        echo "[$current_time] CRITICAL: Neither npm nor node found, cannot start web server" | tee -a logs/monitor.log
      fi
    fi
  fi
  
  # Check Twitter bot
  if ! process_running "twitter_bot.py"; then
    echo "[$current_time] Twitter bot not running, restarting..." | tee -a logs/monitor.log
    nohup $PYTHON_PATH -u run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
    echo "[$current_time] Twitter bot restarted with PID: $!" | tee -a logs/monitor.log
  fi
  
  # Check Mind9 core
  if ! process_running "run_mind9.py" && ! process_running "main.py"; then
    echo "[$current_time] Mind9 core system not running, restarting..." | tee -a logs/monitor.log
    nohup $PYTHON_PATH -u run_mind9.py > logs/mind9.log 2>&1 &
    echo "[$current_time] Mind9 core restarted with PID: $!" | tee -a logs/monitor.log
  fi
  
  # Check Coin Promoter
  if ! process_running "coin_promoter.py"; then
    echo "[$current_time] Coin Promoter not running, restarting..." | tee -a logs/monitor.log
    nohup $PYTHON_PATH -u run_coin_promoter.py > logs/coin_promoter.log 2>&1 &
    echo "[$current_time] Coin Promoter restarted with PID: $!" | tee -a logs/monitor.log
  fi
  
  # Record last run time
  echo $current_time > .last_monitor_run
  
  # Sleep for 2 minutes before next check
  sleep 120
done