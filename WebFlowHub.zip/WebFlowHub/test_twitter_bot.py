#!/usr/bin/env python3
"""
Test script for the Mind9 Twitter bot integration.
This script tests the Twitter bot without requiring Solana blockchain access.
"""

import os
import json
import logging
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("twitter_bot_test")

def check_required_packages():
    """Check that all required packages are installed"""
    # Map package import names to their pip install names
    package_map = {
        "tweepy": "tweepy", 
        "dotenv": "python-dotenv", 
        "psycopg2": "psycopg2-binary", 
        "openai": "openai"
    }
    
    missing_packages = []
    
    for import_name, pip_name in package_map.items():
        try:
            __import__(import_name)
            logger.info(f"Found package: {import_name}")
        except ImportError:
            missing_packages.append(pip_name)
            logger.warning(f"Missing package: {pip_name}")
    
    if missing_packages:
        logger.error(f"Missing required packages: {', '.join(missing_packages)}")
        logger.error("Please install them using: pip install " + " ".join(missing_packages))
        return False
    
    return True

def check_environment_variables():
    """Check that all required environment variables are set"""
    required_vars = [
        "TWITTER_API_KEY",
        "TWITTER_API_KEY_SECRET",
        "TWITTER_ACCESS_TOKEN",
        "TWITTER_ACCESS_TOKEN_SECRET",
        "TWITTER_BEARER_TOKEN",
        "OPENAI_API_KEY",
        "DATABASE_URL"
    ]
    
    missing_vars = [var for var in required_vars if not os.getenv(var)]
    
    if missing_vars:
        logger.error(f"Missing required environment variables: {', '.join(missing_vars)}")
        return False
    
    return True

def test_tweet_generation():
    """Test tweet generation without posting"""
    try:
        from tweet_logic import TweetGenerator
        
        generator = TweetGenerator()
        
        # Test different tweet types
        morning_tweet = generator.generate_morning_tweet()
        logger.info(f"Morning tweet: {morning_tweet}")
        
        market_tweet = generator.generate_quote_tweet()
        logger.info(f"Market tweet: {market_tweet}")
        
        night_tweet = generator.generate_night_tweet()
        logger.info(f"Night tweet: {night_tweet}")
        
        # Test coin announcement
        test_coin = {
            "id": 999,
            "name": "Test Coin",
            "symbol": "TEST",
            "mint_address": "TEST123456789",
            "description": "A test coin for tweet generation"
        }
        
        coin_tweet = generator.generate_coin_announcement(test_coin)
        logger.info(f"Coin announcement tweet: {coin_tweet}")
        
        return True
    except Exception as e:
        logger.error(f"Error testing tweet generation: {e}")
        return False

def test_twitter_api():
    """Test Twitter API connectivity without posting"""
    try:
        from twitter_api import TwitterAPI
        
        # Just initialize the API to test authentication
        api = TwitterAPI()
        logger.info("Twitter API initialized successfully")
        
        return True
    except Exception as e:
        logger.error(f"Error testing Twitter API: {e}")
        return False

def test_coin_checker():
    """Test coin checker database connectivity"""
    try:
        from coin_checker import CoinChecker
        
        checker = CoinChecker()
        if checker.connection:
            # Try to get latest coins
            coins = checker.get_latest_coins(limit=3)
            logger.info(f"Found {len(coins)} coins in database")
            
            for coin in coins:
                logger.info(f"Coin: {coin['name']} ({coin['symbol']})")
            
            return True
        else:
            logger.error("Could not connect to database")
            return False
    except Exception as e:
        logger.error(f"Error testing coin checker: {e}")
        return False
        
def test_minimal_twitter_bot():
    """Test a minimal TwitterBot implementation"""
    try:
        # Create a minimal TwitterBot class inline
        class MinimalTwitterBot:
            def __init__(self):
                """Minimal Twitter bot implementation that doesn't depend on solana"""
                self.tweet_generator = None
                logger.info("Initialized minimal TwitterBot")
                
                # Try to initialize components but catch errors
                try:
                    from tweet_logic import TweetGenerator
                    self.tweet_generator = TweetGenerator()
                    logger.info("Tweet generator initialized")
                except Exception as e:
                    logger.error(f"Error initializing tweet generator: {e}")
                
                try:
                    from twitter_api import TwitterAPI
                    self.twitter = TwitterAPI()
                    logger.info("Twitter API initialized")
                except Exception as e:
                    logger.error(f"Error initializing Twitter API: {e}")
                
                try:
                    from coin_checker import CoinChecker
                    self.coin_checker = CoinChecker()
                    logger.info("Coin checker initialized")
                except Exception as e:
                    logger.error(f"Error initializing coin checker: {e}")
            
            def run(self, continuous=False):
                """Simple run method"""
                logger.info("Running minimal TwitterBot")
                
                # Check for new coins
                found_coins = False
                try:
                    if self.coin_checker:
                        new_coins = self.coin_checker.check_for_new_coins()
                        if new_coins:
                            logger.info(f"Found {len(new_coins)} new coins to announce")
                            found_coins = True
                        else:
                            logger.info("No new coins to announce")
                except Exception as e:
                    logger.error(f"Error checking for new coins: {e}")
                
                return found_coins
        
        # Create and run the minimal bot
        bot = MinimalTwitterBot()
        result = bot.run()
        
        logger.info(f"Minimal Twitter bot run completed with result: {result}")
        return True
    except Exception as e:
        logger.error(f"Error testing minimal Twitter bot: {e}")
        return False

def main():
    """Run tests for Twitter bot components"""
    logger.info("Starting Twitter bot test")
    
    # Print banner
    print("""
    ╔══════════════════════════════════════════╗
    ║       Mind9 Twitter Bot Tester           ║
    ║   Testing bot components individually     ║
    ╚══════════════════════════════════════════╝
    """)
    
    # Check requirements
    if not check_required_packages():
        logger.error("Missing required packages, fix before continuing")
        return False
    
    if not check_environment_variables():
        logger.warning("Missing environment variables (tests may fail)")
    
    # Run tests
    results = {
        "Tweet Generation": test_tweet_generation(),
        "Twitter API": test_twitter_api(),
        "Coin Checker": test_coin_checker(),
        "Minimal Bot": test_minimal_twitter_bot()
    }
    
    # Print results
    print("\nTest Results:")
    print("=============")
    
    for test, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test}: {status}")
    
    # Overall result
    overall = all(results.values())
    print(f"\nOverall Result: {'✅ PASS' if overall else '❌ FAIL'}")
    
    if overall:
        print("\nAll Twitter bot components are working correctly!")
        print("You can now run the full Twitter bot.")
    else:
        print("\nSome components failed testing.")
        print("Fix the issues above before running the full Twitter bot.")
    
    return overall

if __name__ == "__main__":
    main()