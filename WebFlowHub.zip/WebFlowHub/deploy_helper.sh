#!/bin/bash

# Mind9 Deployment Helper Script
# This script prepares your Mind9 platform for deployment on Replit

echo "=================================================="
echo "  Mind9 Deployment Helper"
echo "=================================================="
echo ""
echo "This script will prepare your Mind9 platform for deployment on Replit"
echo ""

# Make all scripts executable
echo "Making scripts executable..."
chmod +x *.sh

# Create deployment configuration
echo "Creating deployment configuration..."
cat > .replit << EOL
run = "bash start_replit_services.sh"

[nix]
channel = "stable-24_05"

[env]
HOST = "0.0.0.0"
PORT = "5000"

[deployment]
run = ["bash", "start_replit_services.sh"]
deploymentTarget = "gce"

[[ports]]
localPort = 5000
externalPort = 80
name = "Mind9 App"
protocol = "http"
EOL

# Create Replit Secrets file to ensure secrets are deployed
echo "Creating secrets configuration..."
cat > .secrets.toml << EOL
OPENAI_API_KEY = "$OPENAI_API_KEY"
TWITTER_API_KEY = "$TWITTER_API_KEY"
TWITTER_API_KEY_SECRET = "$TWITTER_API_KEY_SECRET"
TWITTER_ACCESS_TOKEN = "$TWITTER_ACCESS_TOKEN"
TWITTER_ACCESS_TOKEN_SECRET = "$TWITTER_ACCESS_TOKEN_SECRET"
TWITTER_BEARER_TOKEN = "$TWITTER_BEARER_TOKEN"
RPC_ENDPOINT = "$RPC_ENDPOINT"
CREATOR_WALLET_ADDRESS = "$CREATOR_WALLET_ADDRESS"
SOLANA_PRIVATE_KEY = "$SOLANA_PRIVATE_KEY"
DATABASE_URL = "$DATABASE_URL"
PGUSER = "$PGUSER"
PGPASSWORD = "$PGPASSWORD"
PGDATABASE = "$PGDATABASE"
PGHOST = "$PGHOST"
PGPORT = "$PGPORT"
EOL

# Create a build script
echo "Creating build script..."
cat > build.sh << EOL
#!/bin/bash
# Install dependencies
npm install
# Build frontend
npm run build
# Make scripts executable
chmod +x *.sh
echo "Build completed successfully!"
EOL
chmod +x build.sh

# Create a replit.nix file
echo "Configuring Nix environment..."
cat > replit.nix << EOL
{ pkgs }: {
    deps = [
        pkgs.nodejs-20_x
        pkgs.python311
        pkgs.postgresql_16
        pkgs.nodePackages.typescript
        pkgs.nodePackages.npm
    ];
}
EOL

echo ""
echo "Deployment configuration created successfully!"
echo ""
echo "To deploy your Mind9 platform to Replit:"
echo "1. Click on the 'Deployment' tab in the Replit sidebar"
echo "2. Click 'Deploy'"
echo ""
echo "Your Mind9 system will now be properly configured for deployment."
echo "=================================================="