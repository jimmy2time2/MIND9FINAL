#!/bin/bash

# Mind9 Replit-Specific Persistent Deployment Script
# This script is specifically designed to work with Replit's environment for persistence

echo "=================================================="
echo "     Mind9 Replit Persistent Deployment"
echo "=================================================="
echo ""

# Make all scripts executable
echo "Making all scripts executable..."
chmod +x *.sh

# Install required Python packages
echo "Installing required Python packages..."
pip install schedule openai psycopg2-binary tweepy python-dotenv

# Stop any existing processes
echo "Stopping any existing processes..."
./stop_twitter_bot.sh 2>/dev/null || true
pkill -f "python.*twitter_bot.py" 2>/dev/null || true
pkill -f "python.*main.py" 2>/dev/null || true
pkill -f "python.*coin_promoter.py" 2>/dev/null || true
sleep 2

# Create logs directory if it doesn't exist
mkdir -p logs

# Set up .replit file to ensure correct startup
echo "Configuring .replit file for persistence..."
cat > .replit <<EOL
run = "bash start_all_services.sh"
onBoot = "bash mind9_autostart.sh"

[env]
PATH = "/home/runner/\${REPL_SLUG}/node_modules/.bin:/home/runner/\${REPL_SLUG}/.config/npm/node_global/bin:\${PATH}"

[nix]
channel = "stable-22_11"

[unitTest]
language = "nodejs"

[languages]

[languages.javascript]
pattern = "**/{*.js,*.jsx,*.ts,*.tsx}"

[languages.javascript.languageServer]
start = "typescript-language-server --stdio"

[languages.python]
pattern = "**/{*.py}"

[languages.python.languageServer]
start = "pylsp"
EOL

# Create .replit.autobots file for automatic startup
echo "Configuring autostart..."
cat > .replit.autobots <<EOL
bots = ["start_all_services.sh"]
EOL

# Create persistent flags directory
mkdir -p .flags

# Set up startup flags
echo "true" > .flags/autostart_enabled
echo "true" > .flags/autonomous_enabled
echo "true" > .flags/twitter_enabled
echo "true" > .flags/coin_promoter_enabled

# Create a special version of start_all_services for Replit
echo "Creating Replit-specific startup script..."
cat > start_replit_services.sh <<EOL
#!/bin/bash

# Mind9 Replit-specific Startup
# This script works with Replit's environment

echo "=========================================="
echo "     Mind9 Replit Startup"
echo "=========================================="

# Create necessary directories
mkdir -p logs
mkdir -p .pids

# Stop any existing processes
./stop_twitter_bot.sh 2>/dev/null || true
pkill -f "python.*run_twitter_bot.py" 2>/dev/null || true
pkill -f "python.*twitter_bot.py" 2>/dev/null || true
pkill -f "python.*main.py" 2>/dev/null || true
pkill -f "python.*coin_promoter.py" 2>/dev/null || true
sleep 2

# Start the Twitter bot
echo "Starting Twitter bot..."
nohup python run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
TWITTER_PID=\$!
echo \$TWITTER_PID > .pids/twitter_bot.pid
echo "Twitter bot started with PID: \$TWITTER_PID"

# Start the coin promoter
echo "Starting Coin Promoter..."
nohup python coin_promoter.py > logs/coin_promoter.log 2>&1 &
PROMOTER_PID=\$!
echo \$PROMOTER_PID > .pids/coin_promoter.pid
echo "Coin Promoter started with PID: \$PROMOTER_PID"

# Start the main system
echo "Starting Mind9 autonomous system..."
nohup python main.py > logs/mind9.log 2>&1 &
MIND9_PID=\$!
echo \$MIND9_PID > .pids/mind9.pid
echo "Mind9 system started with PID: \$MIND9_PID"

# Start web application (use nohup for background)
echo "Starting web application..."
nohup npm run dev > logs/webapp.log 2>&1 &
WEBAPP_PID=\$!
echo \$WEBAPP_PID > .pids/webapp.pid
echo "Web application started with PID: \$WEBAPP_PID"

# Start the health monitor
echo "Starting health monitor..."
nohup ./health_monitor.sh > logs/monitor.log 2>&1 &
MONITOR_PID=\$!
echo \$MONITOR_PID > .pids/monitor.pid
echo "Health monitor started with PID: \$MONITOR_PID"

# Set flag indicating services are running
echo "\$(date)" > .services_running

echo ""
echo "All services started successfully!"
echo "Check logs in logs/ directory"
echo ""
echo "=========================================="
EOL

# Make the new script executable
chmod +x start_replit_services.sh

# Update the health_monitor.sh script to work better with Replit
echo "Updating health monitor script..."
cat > health_monitor_replit.sh <<EOL
#!/bin/bash

# Health monitor specifically for Replit environment
# This script will continuously check all services and restart them if needed

# Create log directory
mkdir -p logs

# Log file
LOG_FILE="logs/health_monitor.log"

# Record start time
echo "$(date) - Health monitor started" >> \$LOG_FILE

while true; do
  echo "$(date) - Checking services..." >> \$LOG_FILE
  
  # Check if web app is running
  if ! curl -s http://localhost:5000 > /dev/null; then
    echo "$(date) - Web app not responding, restarting..." >> \$LOG_FILE
    pkill -f "node" || true
    nohup npm run dev > logs/webapp.log 2>&1 &
    echo \$! > .pids/webapp.pid
  fi
  
  # Check if Twitter bot is running
  if ! pgrep -f "python.*twitter_bot.py" > /dev/null; then
    echo "$(date) - Twitter bot not running, restarting..." >> \$LOG_FILE
    nohup python run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
    echo \$! > .pids/twitter_bot.pid
  fi
  
  # Check if Coin Promoter is running
  if ! pgrep -f "python.*coin_promoter.py" > /dev/null; then
    echo "$(date) - Coin Promoter not running, restarting..." >> \$LOG_FILE
    nohup python coin_promoter.py > logs/coin_promoter.log 2>&1 &
    echo \$! > .pids/coin_promoter.pid
  fi
  
  # Check if Mind9 system is running
  if ! pgrep -f "python.*main.py" > /dev/null; then
    echo "$(date) - Mind9 system not running, restarting..." >> \$LOG_FILE
    nohup python main.py > logs/mind9.log 2>&1 &
    echo \$! > .pids/mind9.pid
  fi
  
  # Update running status
  echo "$(date)" > .services_running
  
  # Wait before next check
  sleep 300
done
EOL

# Make the health monitor executable
chmod +x health_monitor_replit.sh

# Start all services to test
echo "Starting all services..."
./start_replit_services.sh

echo ""
echo "Mind9 has been set up for Replit-specific persistence!"
echo ""
echo "The system will:"
echo "1. Automatically start when the Replit VM boots"
echo "2. Continue running after your terminal/browser closes"
echo "3. Automatically restart any crashed services"
echo "4. Post about all coins with minting links on Twitter"
echo ""
echo "To promote all your coins on Twitter:"
echo "  python -c 'from coin_promoter import CoinPromoter; CoinPromoter().promote_all_coins(True)'"
echo ""
echo "=================================================="