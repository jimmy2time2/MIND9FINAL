# Mind9 Deployment Instructions

Follow these steps in order to fix the deployment issues and ensure 24/7 operation on a Replit Reserved VM.

## Step 1: Replace .replit File

Create/edit your `.replit` file to contain exactly this content:

```toml
run = "node dist/index.js"

[deployment]
deploymentTarget = "reservedvm"
build = ["sh", "-c", "npm ci && npm run build"]
run   = ["sh", "-c", "./start_persistent.sh"]

[[ports]]
localPort     = 5000
externalPort  = 80
name          = "Mind9-App"
protocol      = "http"
```

## Step 2: Configure replit.nix

Create/edit your `replit.nix` file to contain exactly this content:

```nix
{ pkgs }: {
  deps = [
    pkgs.nodejs-20
    pkgs.libpng pkgs.cairo pkgs.pango pkgs.librsvg
    pkgs.pkg-config
  ];
}
```

## Step 3: Update Canvas Library

Replace the Canvas library with a pre-built binary that doesn't require native compilation:

```bash
npm uninstall canvas
npm install --save npm:@napi-rs/canvas@^0.1.37 --force
```

## Step 4: Ensure start_persistent.sh Exists

The `start_persistent.sh` script has already been created with this content:

```bash
#!/usr/bin/env bash
# Keep background workers + web server alive
npx pm2-runtime dist/index.js
```

Make sure it's executable:

```bash
chmod +x start_persistent.sh
```

## Step 5: Add Required Secrets

Go to Replit → Secrets and add these keys:

- `OPENAI_API_KEY` = your OpenAI API key
- `SOLANA_PRIVATEKEY` = your base58 encoded private key
- `TWITTER_BEARER` = your Twitter bearer token

## Step 6: Commit Changes

After applying all these changes, commit them:

```bash
git add -A
git commit -m "♻️  One-file manifest, Reserved VM, nix libs, prebuilt canvas"
```

## Step 7: Deploy to Reserved VM

1. Click Deploy → Reserved VM → 0.5 GB tier → Redeploy now
2. Wait for the log line: ✓ Deployment succeeded

## Step 8: Verify Deployment

After deployment is complete, check that everything is working:

```bash
curl -I https://<your-project>.replit.app | head -n1
```

You should see `HTTP/1.1 200` in the response.

Also check that the background worker logs are showing up in the PM2 logs.

## Troubleshooting

If you encounter any issues:
1. Check the deployment logs for specific error messages
2. Verify all environment secrets are properly set
3. Make sure the start_persistent.sh script is executable
4. Confirm npm ci and npm run build completed successfully

Remember that the Reserved VM keeps your application running 24/7, even when you close the browser.