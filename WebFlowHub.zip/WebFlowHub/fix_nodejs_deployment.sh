#!/bin/bash

# Fix Node.js Deployment Script for Mind9
# This script fixes Node.js path issues in the deployment environment

echo "=================================================="
echo "  Mind9 Node.js Deployment Fix"
echo "=================================================="
echo ""

# First, create the .replit.nix file to ensure Node.js is included
echo "Creating proper replit.nix file..."
cat > replit.nix << 'EOL'
{ pkgs }: {
  deps = [
    pkgs.nodejs-20_x
    pkgs.python311
    pkgs.postgresql_16
    
    # Canvas dependencies
    pkgs.cairo
    pkgs.pango
    pkgs.libuuid
    pkgs.libpng
    pkgs.libjpeg
    pkgs.giflib
    pkgs.librsvg
  ];
  
  env = {
    LD_LIBRARY_PATH = pkgs.lib.makeLibraryPath [
      pkgs.libuuid
      pkgs.cairo
      pkgs.pango
      pkgs.libpng
      pkgs.libjpeg
      pkgs.giflib
      pkgs.librsvg
    ];
  };
}
EOL
echo "✓ replit.nix created"

# Create a proper fixed reserved VM script that correctly sets node paths
echo "Creating fixed reserved VM script with explicit Node.js paths..."
cat > fixed_reserved_vm.sh << 'EOL'
#!/bin/bash

# Mind9 Fixed Reserved VM Script with explicit Node.js paths
echo "=================================================="
echo "  Mind9 Reserved VM with Node.js Fixes"
echo "=================================================="
echo ""

# Create logs directory
mkdir -p logs

# Check for nodejs and npm in standard locations
NODE_PATHS=(
  "/home/runner/.config/.npm/node/lib/bin/node"
  "/home/runner/.nix-profile/bin/node"
  "/nix/store/*/bin/node"
  "/opt/nvm/versions/node/*/bin/node"
  "/opt/homebrew/bin/node"
  "/usr/local/bin/node"
  "/usr/bin/node"
)

NPM_PATHS=(
  "/home/runner/.config/.npm/bin/npm"
  "/home/runner/.nix-profile/bin/npm"
  "/nix/store/*/bin/npm"
  "/opt/nvm/versions/node/*/bin/npm"
  "/opt/homebrew/bin/npm"
  "/usr/local/bin/npm"
  "/usr/bin/npm"
)

NODE_PATH=""
NPM_PATH=""

# Find node executable
for path in "${NODE_PATHS[@]}"; do
  found_paths=$(ls $path 2>/dev/null || true)
  if [ ! -z "$found_paths" ]; then
    for found in $found_paths; do
      if [ -x "$found" ]; then
        NODE_PATH="$found"
        echo "Found Node.js: $NODE_PATH"
        break 2
      fi
    done
  fi
done

# Find npm executable
for path in "${NPM_PATHS[@]}"; do
  found_paths=$(ls $path 2>/dev/null || true)
  if [ ! -z "$found_paths" ]; then
    for found in $found_paths; do
      if [ -x "$found" ]; then
        NPM_PATH="$found"
        echo "Found npm: $NPM_PATH"
        break 2
      fi
    done
  fi
done

# If Node.js is still not found, try to install it
if [ -z "$NODE_PATH" ]; then
  echo "Node.js not found in standard locations. Attempting to install..."
  if command -v apt-get &> /dev/null; then
    sudo apt-get update -y && sudo apt-get install -y nodejs npm
    NODE_PATH=$(which node)
    NPM_PATH=$(which npm)
  elif command -v nix-env &> /dev/null; then
    nix-env -iA nixpkgs.nodejs
    NODE_PATH=$(which node)
    NPM_PATH=$(which npm)
  fi
fi

if [ -z "$NODE_PATH" ]; then
  echo "⚠️ Node.js could not be installed. Falling back to Python-only mode."
  ./run_python_only.sh
  exit 1
fi

echo "Using Node.js at: $NODE_PATH"
echo "Using npm at: $NPM_PATH"

# Export paths so other scripts can use them
export PATH="$(dirname $NODE_PATH):$(dirname $NPM_PATH):$PATH"
export NODE_PATH
export NPM_PATH

# Kill any existing processes
echo "Stopping any existing Mind9 services..."
pkill -f "npm run dev" 2>/dev/null || true
pkill -f "node server/index.js" 2>/dev/null || true
pkill -f "python.*twitter_bot.py" 2>/dev/null || true
pkill -f "python.*run_mind9.py" 2>/dev/null || true
pkill -f "python.*run_coin_promoter.py" 2>/dev/null || true
sleep 2

# Find Python path
PYTHON_PATH=$(which python3.11 || which python3 || which python || echo "python3")
echo "Using Python path: $PYTHON_PATH"

# Start the web application
echo "Starting Mind9 web application..."
export HOST=0.0.0.0
export PORT=5000
if [ ! -z "$NPM_PATH" ]; then
  nohup $NPM_PATH run dev > logs/web_app.log 2>&1 &
  echo "Web app started with PID: $!"
else
  nohup $NODE_PATH server/index.js > logs/web_app.log 2>&1 &
  echo "Web app started with direct Node.js, PID: $!"
fi

# Start Twitter bot
echo "Starting Twitter bot..."
nohup $PYTHON_PATH -u run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
echo "Twitter bot started with PID: $!"

# Start Mind9 core
echo "Starting Mind9 core system..."
nohup $PYTHON_PATH -u run_mind9.py > logs/mind9.log 2>&1 &
echo "Mind9 core started with PID: $!"

# Start coin promoter
echo "Starting Coin Promoter..."
nohup $PYTHON_PATH -u run_coin_promoter.py > logs/coin_promoter.log 2>&1 &
echo "Coin Promoter started with PID: $!"

echo ""
echo "Mind9 services started successfully!"
echo "The system will continue running even when you close the browser."
echo "Access the web interface at: http://localhost:5000"
echo ""
echo "=================================================="

# Keep the terminal active and monitor services
while true; do
  # Check web server
  if ! pgrep -f "npm run dev" > /dev/null && ! pgrep -f "node server/index.js" > /dev/null; then
    echo "[$(date)] Web server not running, restarting..."
    export HOST=0.0.0.0
    export PORT=5000
    if [ ! -z "$NPM_PATH" ]; then
      nohup $NPM_PATH run dev > logs/web_app.log 2>&1 &
    else
      nohup $NODE_PATH server/index.js > logs/web_app.log 2>&1 &
    fi
    echo "Web app restarted with PID: $!"
  fi
  
  # Check Twitter bot
  if ! pgrep -f "run_twitter_bot.py" > /dev/null; then
    echo "[$(date)] Twitter bot not running, restarting..."
    nohup $PYTHON_PATH -u run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
    echo "Twitter bot restarted with PID: $!"
  fi
  
  # Check Mind9 core
  if ! pgrep -f "run_mind9.py" > /dev/null; then
    echo "[$(date)] Mind9 core not running, restarting..."
    nohup $PYTHON_PATH -u run_mind9.py > logs/mind9.log 2>&1 &
    echo "Mind9 core restarted with PID: $!"
  fi
  
  # Check coin promoter
  if ! pgrep -f "run_coin_promoter.py" > /dev/null; then
    echo "[$(date)] Coin Promoter not running, restarting..."
    nohup $PYTHON_PATH -u run_coin_promoter.py > logs/coin_promoter.log 2>&1 &
    echo "Coin Promoter restarted with PID: $!"
  fi
  
  # Log heartbeat
  echo "[$(date)] Mind9 is running autonomously on Replit Reserved VM" 
  sleep 60  # Check every minute
done
EOL
chmod +x fixed_reserved_vm.sh
echo "✓ fixed_reserved_vm.sh created"

# Create a proper deployment build script
echo "Creating fixed deployment build script..."
cat > fixed_deployment.sh << 'EOL'
#!/bin/bash

# Mind9 Fixed Deployment Configuration
echo "=================================================="
echo "  Mind9 Fixed Deployment Configuration"
echo "=================================================="
echo ""

# Create proper deployment files
echo "Creating replit.deploy file..."
cat > .replit.deploy << 'DEPLOY'
run = "bash fixed_reserved_vm.sh"
deploymentTarget = "cloudrun"
DEPLOY

# Create build.sh for deployment
echo "Creating build.sh file..."
cat > build.sh << 'BUILD'
#!/bin/bash

# Export PATH to include nix Node.js binaries
export PATH="/nix/store/*/bin:$PATH"

# Find nodejs executable
NODE_PATH=$(find /nix/store -name node -type f -executable -path "*/bin/node" 2>/dev/null | head -n 1)
NPM_PATH=$(find /nix/store -name npm -type f -executable -path "*/bin/npm" 2>/dev/null | head -n 1)

if [ -z "$NODE_PATH" ]; then
  echo "ERROR: Node.js not found in the deployment environment."
  exit 1
fi

echo "Found Node.js at: $NODE_PATH"
echo "Found npm at: $NPM_PATH"

# Add node directory to PATH
export PATH="$(dirname $NODE_PATH):$PATH"

# Set NPM config for Canvas
export npm_config_canvas_binary_host_mirror=https://github.com/Automattic/node-canvas/releases/download/
export CXXFLAGS="--std=c++14"

# Install Canvas dependencies
echo "Installing system dependencies for Canvas..."
if command -v apt-get &> /dev/null; then
  apt-get update
  apt-get install -y libcairo2-dev libjpeg-dev libpango1.0-dev libgif-dev librsvg2-dev build-essential
fi

# Install npm packages
echo "Installing npm packages..."
$NPM_PATH install --build-from-source

# Rebuild canvas specifically
echo "Rebuilding canvas..."
$NPM_PATH rebuild canvas --update-binary

# Build the application
echo "Building application..."
$NPM_PATH run build

# Make scripts executable
chmod +x *.sh

# Notify build complete
echo "Build completed successfully!"
BUILD
chmod +x build.sh

echo ""
echo "=================================================="
echo "  Mind9 Deployment Fixed!"
echo "=================================================="
echo ""
echo "To deploy Mind9:"
echo "1. Run: ./fixed_deployment.sh"
echo "2. Go to the Deployments tab in Replit"
echo "3. Click Deploy"
echo ""
echo "=================================================="
EOL
chmod +x fixed_deployment.sh
echo "✓ fixed_deployment.sh created"

# Run the deployment fix
echo "Running deployment fix..."
./fixed_deployment.sh

echo ""
echo "Node.js deployment fixes completed!"
echo "Now run ./fixed_reserved_vm.sh to start Mind9 with proper Node.js paths"
echo ""