import { useEffect, useRef, useState } from "react";
import { Coin } from "@/lib/types";
import { truncateWalletAddress } from "@/lib/utils";

interface LiveTerminalProps {
  coins: Coin[];
}

export default function LiveTerminal({ coins = [] }: LiveTerminalProps) {
  const terminalRef = useRef<HTMLDivElement>(null);
  const [terminalMessages, setTerminalMessages] = useState<JSX.Element[]>([]);
  
  // Add system boot messages on initial load
  useEffect(() => {
    const now = new Date();
    const timestamp = now.toLocaleDateString('en-US', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }).replace(/(\d+)\/(\d+)\/(\d+)/, '$2.$1.$3');
    
    const bootMessages = [
      <div key="boot-1" className="mb-4">
        <div className="text-terminal-amber">
          [SYSTEM] {timestamp} - AI Terminal v1.0.2 initialized
        </div>
        <div className="text-terminal-blue ml-4">
          &gt;&gt; Connecting to Solana Mainnet... <span className="text-terminal-green">SUCCESS</span>
        </div>
        <div className="text-terminal-blue ml-4">
          &gt;&gt; Initializing OpenAI API connection... <span className="text-terminal-green">SUCCESS</span>
        </div>
        <div className="text-terminal-blue ml-4">
          &gt;&gt; Loading token database... <span className="text-terminal-green">SUCCESS</span>
        </div>
        <div className="text-terminal-blue ml-4">
          &gt;&gt; Initializing Lucky Trader Pool... <span className="text-terminal-green">SUCCESS</span>
        </div>
        <div className="text-terminal-amber">
          [SYSTEM] {timestamp} - All systems operational
        </div>
      </div>
    ];
    
    setTerminalMessages(bootMessages);
  }, []);
  
  // Add coin generation messages based on fetched coins
  useEffect(() => {
    // Add a message for when no coins are available
    if (!coins || coins.length === 0) {
      const now = new Date();
      const currentTimestamp = now.toLocaleDateString('en-US', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }).replace(/(\d+)\/(\d+)\/(\d+)/, '$2.$1.$3');
      
      const waitingMessage = (
        <div key="waiting" className="mb-4">
          <div className="text-terminal-amber">
            [AI] {currentTimestamp} - System online and observing market conditions
          </div>
          <div className="text-terminal-blue ml-4">
            &gt;&gt; Analyzing current market sentiment...
          </div>
          <div className="text-terminal-blue ml-4">
            &gt;&gt; Evaluating network health metrics...
          </div>
          <div className="text-terminal-amber">
            [SYSTEM] {currentTimestamp} - No coins have been created by Mind9 yet
          </div>
          <div className="text-terminal-green ml-4">
            &gt;&gt; The AI system is observing the market before creating the first token
          </div>
          <div className="text-terminal-amber mt-4">
            [AI] {currentTimestamp} - Continuing market analysis...
            <span className="animate-blink">█</span>
          </div>
        </div>
      );
      
      setTerminalMessages(prev => {
        // Only keep boot messages to avoid duplication
        const bootOnly = prev.filter(msg => msg.key?.toString().startsWith('boot'));
        return [...bootOnly, waitingMessage];
      });
    } else if (coins && coins.length > 0) {
      const coinMessages = coins.map((coin, index) => {
        const timestamp = new Date(coin.timestamp).toLocaleDateString('en-US', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false
        }).replace(/(\d+)\/(\d+)\/(\d+)/, '$2.$1.$3');
        
        // Parse tokenomics from string
        let tokenomics = {
          liquidityPool: 70,
          tradingFund: 20,
          creator: 5,
          luckyTrader: 3,
          systemOperations: 2
        };
        
        // Try to extract percentages from the tokenomics string
        if (coin.tokenomics) {
          try {
            const parts = coin.tokenomics.split(',').map(part => part.trim());
            parts.forEach(part => {
              if (part.includes('Locked LP') || part.includes('Liquidity')) {
                const match = part.match(/(\d+)%/);
                if (match) tokenomics.liquidityPool = parseInt(match[1]);
              } else if (part.includes('Trading Fund')) {
                const match = part.match(/(\d+)%/);
                if (match) tokenomics.tradingFund = parseInt(match[1]);
              } else if (part.includes('Creator')) {
                const match = part.match(/(\d+)%/);
                if (match) tokenomics.creator = parseInt(match[1]);
              } else if (part.includes('Lucky Trader')) {
                const match = part.match(/(\d+)%/);
                if (match) tokenomics.luckyTrader = parseInt(match[1]);
              } else if (part.includes('Operations') || part.includes('System')) {
                const match = part.match(/(\d+)%/);
                if (match) tokenomics.systemOperations = parseInt(match[1]);
              }
            });
          } catch (e) {
            console.log('Using default tokenomics values for LiveTerminal');
          }
        }
        
        return (
          <div className="mb-4" key={`coin-${index}`}>
            <div className="text-terminal-amber">
              [AI] {timestamp} - Beginning market analysis
            </div>
            <div className="text-terminal-blue ml-4">
              &gt;&gt; Scanning trending tokens...
            </div>
            <div className="text-terminal-blue ml-4">
              &gt;&gt; Analyzing market sentiment...
            </div>
            <div className="text-terminal-blue ml-4">
              &gt;&gt; Determining optimal tokenomics...
            </div>
            <div className="text-terminal-amber">
              [AI] {timestamp} - Token concept generated
            </div>
            <div className="border border-terminal-darkGreen p-2 my-2 bg-terminal-black/30">
              <div className="text-terminal-green font-bold">TOKEN: {coin.name}</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                <div>
                  <div><span className="text-terminal-amber">SYMBOL:</span> ${coin.symbol}</div>
                  <div><span className="text-terminal-amber">MINT ADDRESS:</span> {truncateWalletAddress(coin.mint_address)}</div>
                  <div><span className="text-terminal-amber">TOTAL SUPPLY:</span> {coin.total_supply}</div>
                </div>
                <div>
                  <div><span className="text-terminal-amber">TOKENOMICS:</span></div>
                  <div className="ml-2">- LP: {tokenomics.liquidityPool}%</div>
                  <div className="ml-2">- Creator: {tokenomics.creator}%</div>
                  <div className="ml-2">- Lucky Trader: {tokenomics.luckyTrader}%</div>
                </div>
              </div>
              <div className="mt-2 text-xs">
                <span className="text-terminal-amber">DESCRIPTION:</span> {coin.description}
              </div>
              <div className="mt-2 text-xs">
                <span className="text-terminal-amber">LIQUIDITY POOL:</span> {coin.liquidity_sol} SOL
              </div>
              <div className="mt-2">
                <a 
                  href={`/coin/${coin.id}`}
                  className="text-terminal-green hover:text-terminal-darkGreen"
                >
                  &gt;&gt; MINT ${coin.symbol} ON MIND9
                </a>
              </div>
            </div>
            <div className="text-terminal-amber">
              [SYSTEM] {timestamp} - Token successfully minted
            </div>
            <div className="text-terminal-amber">
              [SYSTEM] {timestamp} - Selecting lucky trader...
            </div>
            <div className="text-terminal-green ml-4">
              &gt;&gt; WINNER: {!coin.lucky_trader_wallet || coin.lucky_trader_wallet.toLowerCase().includes('simu') ? 'NO REAL WALLETS CONNECTED' : truncateWalletAddress(coin.lucky_trader_wallet)} {!coin.lucky_trader_wallet || coin.lucky_trader_wallet.toLowerCase().includes('simu') ? 'waiting for real wallet' : `received 3% of ${coin.symbol}`}
            </div>
            <div className="text-terminal-amber">
              [SYSTEM] {timestamp} - Liquidity pool created on Raydium
            </div>
          </div>
        );
      });
      
      // Add a "looking for next token" message at the end
      const now = new Date();
      const currentTimestamp = now.toLocaleDateString('en-US', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }).replace(/(\d+)\/(\d+)\/(\d+)/, '$2.$1.$3');
      
      const analysisMessage = (
        <div key="analysis" className="text-terminal-amber">
          [AI] {currentTimestamp} - Beginning new market analysis...
          <span className="animate-blink">█</span>
        </div>
      );
      
      // Add boot messages and coin messages
      setTerminalMessages(prev => {
        // Only keep boot messages to avoid duplication
        const bootOnly = prev.filter(msg => msg.key?.toString().startsWith('boot'));
        return [...bootOnly, ...coinMessages, analysisMessage];
      });
    }
  }, [coins]);
  
  // Scroll to bottom whenever messages change
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [terminalMessages]);

  return (
    <section className="lg:col-span-2 border border-terminal-darkGreen overflow-hidden">
      <div className="border-b border-terminal-darkGreen p-2">
        <h2 className="font-bold">
          <span className="text-terminal-amber">&gt;</span> 
          AI TERMINAL OUTPUT
          <span className="animate-blink text-terminal-green">█</span>
        </h2>
      </div>
      
      <div 
        ref={terminalRef}
        className="h-[calc(100vh-320px)] overflow-y-auto p-2 text-sm relative" 
        id="terminalOutput"
      >
        {terminalMessages}
      </div>
    </section>
  );
}
