import React from 'react';
import { useLocation } from 'wouter';
import { Coin } from '@/lib/types';
import { CoinCard } from './CoinCard';
import { useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';

interface CoinsGridProps {
  coins: Coin[];
}

export function CoinsGrid({ coins }: CoinsGridProps) {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const handleMintClick = (coin: Coin) => {
    navigate(`/coin/${coin.id}`);
  };
  
  // Deletion functionality removed to ensure system autonomy
  // Coins created by Mind9 AI cannot be deleted in an autonomous system
  
  if (coins.length === 0) {
    return (
      <div className="py-20 text-center border-2 border-terminal-darkGreen">
        <p className="text-terminal-green font-mono text-lg">
          MIND9 IS ANALYZING MARKET CONDITIONS
        </p>
        <p className="text-terminal-darkGreen mt-2">
          No tokens have been created yet. Check back soon.
        </p>
      </div>
    );
  }
  
  return (
    <div className="mt-8">
      <h2 className="font-mono text-2xl text-terminal-green mb-4 border-b border-terminal-darkGreen pb-2">
        <span className="text-terminal-amber">&gt;</span> AI-CREATED TOKENS
      </h2>
      
      <div className="grid grid-cols-1 gap-6">
        {coins.map(coin => (
          <CoinCard 
            key={coin.id} 
            coin={coin} 
            onMintClick={handleMintClick}
            // onDelete prop removed to ensure system autonomy
          />
        ))}
      </div>
    </div>
  );
}