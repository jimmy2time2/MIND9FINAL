import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import * as ChartPrimitive from "@/components/ui/chart";
import { Line, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, LineChart } from 'recharts';
import { apiRequest } from '@/lib/queryClient';
import { formatDistanceToNow } from 'date-fns';

interface PriceChartProps {
  mintAddress: string;
  symbol: string;
}

interface PriceDataPoint {
  timestamp: string;
  price: number;
}

export default function PriceChart({ mintAddress, symbol }: PriceChartProps) {
  const [priceData, setPriceData] = useState<PriceDataPoint[]>([]);
  const [timeframe, setTimeframe] = useState<'1h' | '24h' | '7d' | '30d'>('24h');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  useEffect(() => {
    // Only attempt to fetch data if we have a valid mint address
    if (!mintAddress || mintAddress === '') {
      handleFetchError(new Error('No mint address available'));
      return;
    }
    
    const fetchPriceData = async () => {
      setLoading(true);
      try {
        const response = await apiRequest(`/api/trading/price-history/${mintAddress}?timeframe=${timeframe}`);
        if (!response.ok) {
          throw new Error('Failed to fetch price data');
        }
        const data = await response.json();
        setPriceData(data);
        setLastUpdated(new Date());
      } catch (err: any) {
        handleFetchError(err);
      } finally {
        setLoading(false);
      }
    };

    fetchPriceData();
    // Refresh price data every minute
    const interval = setInterval(fetchPriceData, 60000);
    return () => clearInterval(interval);
  }, [mintAddress, timeframe]);

  // Handle error state - we don't generate placeholder data in production
  const handleFetchError = (err: Error) => {
    console.error('Failed to fetch price data:', err);
    setError('No price data available yet');
    setPriceData([]);
    setLoading(false);
  };

  const chartConfig = {
    price: {
      label: `Price (SOL)`,
      color: "hsl(var(--primary))",
    }
  };

  const chartData = priceData.map((point) => ({
    name: new Date(point.timestamp).toLocaleTimeString(),
    price: point.price
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>{symbol} Price Chart</span>
        </CardTitle>
        <CardDescription>
          {lastUpdated && !loading
            ? `Last updated ${formatDistanceToNow(lastUpdated, { addSuffix: true })}`
            : 'Loading price data...'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="24h" onValueChange={(v) => setTimeframe(v as any)}>
          <TabsList className="mb-4">
            <TabsTrigger value="1h">1H</TabsTrigger>
            <TabsTrigger value="24h">24H</TabsTrigger>
            <TabsTrigger value="7d">7D</TabsTrigger>
            <TabsTrigger value="30d">30D</TabsTrigger>
          </TabsList>
          
          <div className="h-[200px] w-full">
            {loading ? (
              <div className="flex justify-center items-center h-full">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : error ? (
              <div className="flex flex-col justify-center items-center h-full text-muted-foreground text-center px-4">
                <p>No price data available</p>
                <p className="text-xs mt-2">Price history will be displayed once the token has been minted by the AI</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={chartData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" />
                  <YAxis />
                  <CartesianGrid strokeDasharray="3 3" />
                  <Tooltip />
                  <Area 
                    type="monotone" 
                    dataKey="price" 
                    stroke="hsl(var(--primary))" 
                    fillOpacity={1}
                    fill="url(#colorPrice)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </Tabs>
      </CardContent>
    </Card>
  );
}