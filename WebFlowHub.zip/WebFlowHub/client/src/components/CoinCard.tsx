import React from 'react';
import { Link, useLocation } from 'wouter';
import { Coin } from '@/lib/types';
import { FiExternalLink } from 'react-icons/fi';

interface CoinCardProps {
  coin: Coin;
  onMintClick: (coin: Coin) => void;
}

export function CoinCard({ coin, onMintClick }: CoinCardProps) {
  // Format timestamp to a readable date
  const formattedDate = new Date(coin.timestamp).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const [, setLocation] = useLocation();
  
  // Navigate to coin detail page when card is clicked
  const handleCardClick = (e: React.MouseEvent) => {
    // Only navigate if the click wasn't on a button or link
    if (!(e.target as HTMLElement).closest('button, a')) {
      setLocation(`/coin/${coin.id}`);
    }
  };

  return (
    <div 
      onClick={handleCardClick}
      className="border-2 border-terminal-green bg-black bg-opacity-80 p-4 mb-5 hover:border-terminal-amber transition-all cursor-pointer"
    >
      <div className="flex flex-row">
        {/* Coin image */}
        <div className="w-16 h-16 md:w-20 md:h-20 flex-shrink-0 mr-4">
          {coin.image_path ? (
            <img 
              src={coin.image_path} 
              alt={`${coin.name} coin`} 
              className="w-full h-full object-contain"
            />
          ) : (
            <div 
              className="w-full h-full rounded-full" 
              style={{ 
                background: `radial-gradient(circle, ${coin.primary_color || '#FF7D45'}, ${coin.secondary_color || '#FFD1B8'})` 
              }}
            />
          )}
        </div>
        
        {/* Coin info */}
        <div className="flex-grow">
          <div className="flex justify-between items-start">
            <div className="flex items-center">
              <h3 className="text-terminal-green text-lg md:text-xl font-mono">
                ${coin.symbol}
              </h3>
              {coin.minted && (
                <span 
                  className="ml-2 px-1.5 py-0.5 bg-green-900 text-green-300 text-xs rounded font-mono"
                  title="Verified on blockchain"
                >
                  VERIFIED
                </span>
              )}
              {coin.id === 1 && (
                <span 
                  className="ml-2 px-1.5 py-0.5 bg-amber-900 text-amber-300 text-xs rounded font-mono animate-pulse"
                  title="First token created by Mind9 AI"
                >
                  GENESIS
                </span>
              )}
            </div>
            <div className="flex items-center">
              <span className="text-terminal-darkGreen text-xs">
                {formattedDate}
              </span>
            </div>
          </div>
          
          <p className="text-white text-sm font-mono mt-1">
            {coin.name}
          </p>
          
          <p className="text-terminal-darkGreen text-xs mt-1 flex items-center">
            <span>Created by Mind9</span>
            {coin.mint_address && (
              <a 
                href={`https://explorer.solana.com/address/${coin.mint_address}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="ml-2 text-terminal-green hover:text-terminal-amber flex items-center"
                title="View on Solana Explorer"
              >
                <FiExternalLink size={12} />
                <span className="ml-1 text-xs">Explorer</span>
              </a>
            )}
          </p>
          
          <p className="text-terminal-amber text-sm mt-2">
            {coin.tagline || coin.description?.substring(0, 60) + '...'}
          </p>
          
          <div className="flex flex-wrap justify-center items-center mt-3">
            <Link 
              to={`/coin/${coin.id}`} 
              className="px-4 py-2 font-mono text-sm border-2 border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black w-full text-center"
              onClick={(e) => e.stopPropagation()}
            >
              MANAGE TOKEN
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}