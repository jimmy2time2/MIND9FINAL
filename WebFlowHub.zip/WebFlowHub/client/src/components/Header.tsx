import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { truncateWalletAddress } from "@/lib/utils";
import { Loader2 } from "lucide-react";

interface AIWalletData {
  address: string;
  balance: number;
  updated_at: string;
}

export default function Header() {
  const [currentDate, setCurrentDate] = useState<string>("");
  
  // Fetch AI wallet balance
  const { data: walletData, isLoading: walletLoading } = useQuery<AIWalletData>({
    queryKey: ['/api/ai-wallet/balance'],
    refetchInterval: 60000, // Refresh every minute
  });
  
  useEffect(() => {
    // Update time every second
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const seconds = String(now.getSeconds()).padStart(2, '0');
      const day = String(now.getDate()).padStart(2, '0');
      const month = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'][now.getMonth()];
      const year = now.getFullYear();
      
      setCurrentDate(`${hours}:${minutes}:${seconds} - ${day}.${month}.${year}`);
    };
    
    const interval = setInterval(updateTime, 1000);
    updateTime(); // Initial call
    
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="mb-8">
      <div className="border border-terminal-darkGreen bg-terminal-black/50 p-2 mb-4">
        <div className="flex justify-between items-center">
          <div className="text-terminal-amber flex items-center">
            <span className="h-3 w-3 inline-block bg-terminal-red rounded-full mr-2"></span>
            <span className="h-3 w-3 inline-block bg-terminal-yellow rounded-full mr-2"></span>
            <span className="h-3 w-3 inline-block bg-terminal-green rounded-full mr-2"></span>
            <span className="font-bold">SYSTEM TERMINAL</span>
          </div>
          <div className="text-terminal-green text-xs">
            {currentDate}
          </div>
        </div>
        
        {/* AI Wallet Transparency Display */}
        <div className="my-2 py-1 px-2 border border-amber-500/30 bg-amber-500/5 rounded-sm flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div className="flex items-center text-xs">
            <span className="text-amber-500 font-mono mr-2">AI WALLET:</span>
            <a 
              href={`https://explorer.solana.com/address/${walletData?.address || '8Xe5...DXzR'}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-mono hover:text-amber-500 transition-colors"
            >
              {walletData?.address 
                ? truncateWalletAddress(walletData.address, 4, 3) 
                : '8Xe5...DXzR'}
            </a>
          </div>
          <div className="flex items-center text-xs">
            <span className="text-muted-foreground mr-2">Balance:</span>
            {walletLoading ? (
              <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />
            ) : (
              <span className="text-xs font-mono font-bold text-amber-500">
                {walletData?.balance !== undefined 
                  ? walletData.balance.toFixed(4) 
                  : "0.0000"} SOL
              </span>
            )}
            <span className="ml-2 text-[9px] text-muted-foreground italic">
              (5% tokens + 50% trading fees)
            </span>
          </div>
        </div>
        
        <div className="mt-2 flex flex-col md:flex-row justify-between items-start md:items-center">
          <div className="terminal-glow mb-2 md:mb-0">
            <div className="flex items-center">
              <pre className="text-terminal-amber font-mono text-xs md:text-sm leading-tight mr-1">
{`
 __  __ _           _ 
|  \\/  (_)_ __   __| |
| |\\/| | | '_ \\ / _\` |
| |  | | | | | | (_| |
|_|  |_|_|_| |_|\\__,_|
`}
              </pre>
              <span className="text-terminal-green text-4xl font-bold self-center">9</span>
            </div>
          </div>
          <div className="text-xs md:text-sm">
            <span className="animate-blink">█</span>
            <span>AUTONOMOUS AI-POWERED TOKEN GENERATOR v1.0.2</span>
          </div>
        </div>
      </div>
    </header>
  );
}
