import { useState } from 'react';
import { Link } from 'wouter';
import { technicalScript, aggressiveScript, mysteriousScript, hopefulScript } from '@/lib/introScripts';

export default function Footer() {
  const [showDevMenu, setShowDevMenu] = useState(false);
  
  // Function to reset the intro animation for development/testing
  const resetIntro = (scriptType = 'default') => {
    // Remove the flag that intro was seen
    localStorage.removeItem('mind9_intro_seen');
    
    // Set the script type in localStorage
    switch(scriptType) {
      case 'aggressive':
        localStorage.setItem('mind9_intro_script', 'aggressive');
        break;
      case 'mysterious':
        localStorage.setItem('mind9_intro_script', 'mysterious');
        break;
      case 'hopeful':
        localStorage.setItem('mind9_intro_script', 'hopeful');
        break;
      default:
        localStorage.setItem('mind9_intro_script', 'technical');
    }
    
    // Reload the page to show the intro
    window.location.reload();
  };
  
  // Toggle the visibility of the dev menu
  const toggleDevMenu = () => {
    setShowDevMenu(!showDevMenu);
  };
  
  return (
    <footer className="mt-8 text-xs text-center">
      <p className="terminal-glow mb-2">MIND9 - FULLY AUTONOMOUS AI-POWERED TOKEN GENERATOR</p>
      <p>ALL OPERATIONS CONTROLLED BY ARTIFICIAL INTELLIGENCE</p>
      <p className="text-terminal-darkGreen mt-2">[SYSTEM SELF-OPERATIONAL SINCE 2024.05.17]</p>
      <p className="mt-4 text-terminal-amber">&gt; HUMAN INTERACTION IS LIMITED TO WALLET CONNECTION AND TOKEN PURCHASES ONLY <span className="animate-blink">█</span></p>
      <p className="mt-2 text-terminal-darkGreen">REMEMBER: ONCE DEPLOYED, THE AI CANNOT BE MODIFIED OR STOPPED</p>
      
      {/* Hidden dev section - only visible on hover for testing */}
      <div className="mt-8 opacity-20 hover:opacity-100 transition-opacity">
        <div className="flex justify-center space-x-4">
          <button 
            onClick={toggleDevMenu} 
            className="text-[10px] text-terminal-darkGreen hover:text-terminal-green transition-colors"
          >
            [DEV: INTRO OPTIONS]
          </button>
          
          <Link href="/admin/tools"
            className="text-[10px] text-terminal-darkGreen hover:text-terminal-green transition-colors"
          >
            [DEV: TOKEN ADMIN TOOLS]
          </Link>
        </div>
        
        {showDevMenu && (
          <div className="mt-2 flex flex-col items-center space-y-1">
            <button 
              onClick={() => resetIntro('default')}
              className="text-[10px] text-terminal-darkGreen hover:text-terminal-green transition-colors"
            >
              Default/Technical
            </button>
            <button 
              onClick={() => resetIntro('aggressive')}
              className="text-[10px] text-terminal-darkGreen hover:text-terminal-green transition-colors"
            >
              Aggressive/Intense
            </button>
            <button 
              onClick={() => resetIntro('mysterious')}
              className="text-[10px] text-terminal-darkGreen hover:text-terminal-green transition-colors"
            >
              Mysterious/Cryptic
            </button>
            <button 
              onClick={() => resetIntro('hopeful')}
              className="text-[10px] text-terminal-darkGreen hover:text-terminal-green transition-colors"
            >
              Hopeful/Optimistic
            </button>
          </div>
        )}
      </div>
    </footer>
  );
}
