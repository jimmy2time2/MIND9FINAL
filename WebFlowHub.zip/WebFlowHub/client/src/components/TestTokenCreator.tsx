import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Loader2 } from 'lucide-react';

export function TestTokenCreator() {
  const [name, setName] = useState('');
  const [symbol, setSymbol] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<null | {
    success: boolean;
    mintAddress?: string;
    message?: string;
    error?: string;
  }>(null);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !symbol) {
      toast({
        title: "Validation Error",
        description: "Both name and symbol are required",
        variant: "destructive"
      });
      return;
    }
    
    // Convert symbol to uppercase
    const formattedSymbol = symbol.toUpperCase();
    
    setIsLoading(true);
    setResult(null);
    
    try {
      const response = await apiRequest('/api/test-token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, symbol: formattedSymbol })
      });
      
      const data = await response.json();
      
      setResult(data);
      
      if (data.success) {
        toast({
          title: "Token Created Successfully",
          description: `Token ${name} (${formattedSymbol}) created with mint address: ${data.mintAddress}`,
        });
      } else {
        toast({
          title: "Error Creating Token",
          description: data.message || "Failed to create token",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Error creating token:', error);
      setResult({
        success: false,
        message: "An error occurred while creating the token"
      });
      
      toast({
        title: "Error",
        description: "An error occurred while creating the token",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Test Token Creator</CardTitle>
        <CardDescription>
          Create test tokens on Solana for development purposes
        </CardDescription>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Token Name</Label>
            <Input
              id="name"
              placeholder="Test Token"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={isLoading}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="symbol">Token Symbol</Label>
            <Input
              id="symbol"
              placeholder="TTK"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              disabled={isLoading}
              className="uppercase"
              maxLength={5}
            />
            <p className="text-xs text-muted-foreground">
              Max 5 characters, will be converted to uppercase
            </p>
          </div>
          
          {result && (
            <div className={`p-3 rounded text-sm ${result.success ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100'}`}>
              {result.success ? (
                <div>
                  <p className="font-semibold">Successfully created token!</p>
                  <p className="mt-1">Mint Address: <code className="text-xs break-all">{result.mintAddress}</code></p>
                </div>
              ) : (
                <div>
                  <p className="font-semibold">Failed to create token</p>
                  <p className="mt-1">{result.message || result.error}</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
        
        <CardFooter>
          <Button type="submit" disabled={isLoading} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Creating Token...
              </>
            ) : (
              "Create Token"
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}