import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff, Zap, Brain, BarChart3, Clock, AlertTriangle, RotateCw, Rocket } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface SystemStatus {
  autonomous_enabled: boolean;
  verification_status: {
    last_run: string;
    next_run: string;
    unverified_count: number;
  };
  market_analysis: {
    last_run: string;
    next_run: string;
    sentiment_score: number;
    network_health: number;
    should_create_token: boolean;
    reason: string;
  };
  twitter_status: {
    last_post: string;
    next_scheduled: string;
    follower_count: number;
  };
  raydium_status: {
    tokens_ready: number;
    last_migration: string | null;
  };
  system_logs: Array<{
    timestamp: string;
    message: string;
    type: string;
  }>;
}

export function AutonomousSystem() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showLogs, setShowLogs] = useState(false);
  const [reconnecting, setReconnecting] = useState(false);
  const [acceleratedMode, setAcceleratedMode] = useState(false);
  
  // Fetch autonomous system status with auto-reconnection
  const { data: systemStatus, isLoading, error, isError } = useQuery<SystemStatus>({
    queryKey: ['/api/autonomous-status'],
    refetchInterval: 15000, // Refresh every 15 seconds for more responsive updates
    retry: 5, // Retry 5 times if connection fails
    retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 30000), // Exponential backoff
  });
  
  // Handle connection recovery
  useEffect(() => {
    if (isError && !reconnecting) {
      setReconnecting(true);
      
      toast({
        title: 'Connection lost',
        description: 'Attempting to reconnect to autonomous system...',
        variant: 'destructive',
      });
      
      // Force a refetch after a delay
      const timer = setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ['/api/autonomous-status'] });
        setReconnecting(false);
      }, 5000);
      
      return () => clearTimeout(timer);
    }
  }, [isError, reconnecting, toast, queryClient]);
  
  // Handle reconnection success
  useEffect(() => {
    if (systemStatus && reconnecting) {
      setReconnecting(false);
      toast({
        title: 'Reconnected',
        description: 'Successfully reconnected to autonomous system',
      });
    }
  }, [systemStatus, reconnecting, toast]);
  
  // Function to trigger accelerated first token creation
  const triggerAcceleratedMode = async () => {
    try {
      setAcceleratedMode(true);
      
      await apiRequest("/api/accelerate-token-creation", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' }
      });
      
      toast({
        title: 'Accelerated mode activated',
        description: 'The system will create the first token with lower thresholds for faster testing.',
      });
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/autonomous-status'] });
    } catch (error) {
      toast({
        title: 'Failed to activate accelerated mode',
        description: 'An error occurred while trying to accelerate token creation.',
        variant: 'destructive',
      });
      setAcceleratedMode(false);
    }
  };
  
  // Format timestamp to relative time (e.g., "2 minutes ago")
  const formatRelativeTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.round(diffMs / 1000);
    const diffMin = Math.round(diffSec / 60);
    const diffHr = Math.round(diffMin / 60);
    
    if (diffSec < 60) return `${diffSec} seconds ago`;
    if (diffMin < 60) return `${diffMin} minutes ago`;
    if (diffHr < 24) return `${diffHr} hours ago`;
    return date.toLocaleDateString();
  };
  
  // Calculate time until next run
  const calculateTimeUntil = (timestamp: string) => {
    const target = new Date(timestamp);
    const now = new Date();
    const diffMs = target.getTime() - now.getTime();
    
    if (diffMs <= 0) return 'Any moment now';
    
    const diffSec = Math.round(diffMs / 1000);
    const diffMin = Math.round(diffSec / 60);
    const diffHr = Math.round(diffMin / 60);
    
    if (diffSec < 60) return `${diffSec} seconds`;
    if (diffMin < 60) return `${diffMin} minutes`;
    if (diffHr < 24) return `${diffHr} hours`;
    return target.toLocaleDateString();
  };
  
  // Determine badge color based on status type
  const getBadgeVariant = (type: string): "default" | "destructive" | "secondary" | "outline" => {
    switch (type) {
      case 'success': return 'default';
      case 'error': return 'destructive';
      case 'warning': return 'secondary'; // Changed from 'warning' to 'secondary' to match allowed variants
      case 'info': return 'secondary';
      default: return 'outline';
    }
  };
  
  if (isLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            <span>Mind9 Autonomous System</span>
          </CardTitle>
          <CardDescription>Loading system status...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="h-4 bg-muted rounded animate-pulse w-3/4"></div>
              <div className="h-4 bg-muted rounded animate-pulse w-1/2"></div>
            </div>
            <div className="space-y-2">
              <div className="h-4 bg-muted rounded animate-pulse w-3/4"></div>
              <div className="h-4 bg-muted rounded animate-pulse w-1/2"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!systemStatus) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            <span>Mind9 Autonomous System</span>
          </CardTitle>
          <CardDescription>Unable to fetch system status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-destructive">
            Failed to connect to the autonomous system. Please try again later.
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            <span>Mind9 Autonomous System</span>
          </CardTitle>
          <Badge variant={systemStatus.autonomous_enabled ? "default" : "secondary"}>
            {systemStatus.autonomous_enabled ? "Autonomous" : "Manual"}
          </Badge>
        </div>
        <CardDescription>
          Fully autonomous AI decision engine creating tokens without human intervention
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Market Analysis Status */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span>Market Analysis</span>
            </h3>
            <div className="text-sm text-muted-foreground">
              Last run: {formatRelativeTime(systemStatus.market_analysis.last_run)}
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Network Health</span>
                <span>{Math.round(systemStatus.market_analysis.network_health * 100)}%</span>
              </div>
              <Progress value={systemStatus.market_analysis.network_health * 100} />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Sentiment Score</span>
                <span>{Math.round(systemStatus.market_analysis.sentiment_score * 100)}%</span>
              </div>
              <Progress value={systemStatus.market_analysis.sentiment_score * 100} />
            </div>
          </div>
          
          <div className="mt-3 text-sm">
            {systemStatus.market_analysis.should_create_token ? (
              <Badge className="animate-pulse" variant="default">
                TOKEN CREATION IMMINENT
              </Badge>
            ) : (
              <Badge variant="secondary">
                MONITORING MARKET
              </Badge>
            )}
            <p className="mt-2 text-muted-foreground">{systemStatus.market_analysis.reason}</p>
            
            {/* Progress bars showing thresholds for autonomous token creation */}
            <div className="mt-3 space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Network Health Threshold</span>
                  <span>
                    {Math.round(systemStatus.market_analysis.network_health * 100)}% / 70%
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-primary rounded-full transition-all duration-500"
                    style={{ 
                      width: `${Math.min(100, (systemStatus.market_analysis.network_health * 100) / 70 * 100)}%`
                    }}
                  />
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Sentiment Score Threshold</span>
                  <span>
                    {Math.round(systemStatus.market_analysis.sentiment_score * 100)}% / 65%
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-primary rounded-full transition-all duration-500"
                    style={{ 
                      width: `${Math.min(100, (systemStatus.market_analysis.sentiment_score * 100) / 65 * 100)}%` 
                    }}
                  />
                </div>
              </div>
            </div>
            
            <p className="mt-3 text-xs">
              <span className="font-semibold">Next market analysis:</span> <span className="text-primary">{calculateTimeUntil(systemStatus.market_analysis.next_run)}</span>
            </p>
          </div>
        </div>
        
        <Separator />
        
        {/* Token Verification Status */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold flex items-center gap-2">
              <Zap className="h-4 w-4" />
              <span>Token Verification</span>
            </h3>
            <div className="text-sm text-muted-foreground">
              Last run: {formatRelativeTime(systemStatus.verification_status.last_run)}
            </div>
          </div>
          
          <div className="text-sm">
            <p>
              {systemStatus.verification_status.unverified_count === 0 ? (
                "All tokens verified ✓"
              ) : (
                `${systemStatus.verification_status.unverified_count} token(s) awaiting verification`
              )}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Next verification in {calculateTimeUntil(systemStatus.verification_status.next_run)}
            </p>
          </div>
        </div>
        
        <Separator />
        
        {/* Twitter Status */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
              </svg>
              <span>Twitter Bot</span>
            </h3>
            <div className="text-sm text-muted-foreground">
              {systemStatus.twitter_status.follower_count} followers
            </div>
          </div>
          
          <div className="text-sm">
            <p>Last post: {formatRelativeTime(systemStatus.twitter_status.last_post)}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Next scheduled post in {calculateTimeUntil(systemStatus.twitter_status.next_scheduled)}
            </p>
          </div>
        </div>
        
        <Separator />
        
        {/* Raydium Migration Status */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>Raydium Migration</span>
            </h3>
          </div>
          
          <div className="text-sm">
            {systemStatus.raydium_status.tokens_ready > 0 ? (
              <Badge>{systemStatus.raydium_status.tokens_ready} token(s) ready for migration</Badge>
            ) : (
              <p>No tokens ready for migration</p>
            )}
            
            <p className="mt-1">
              {systemStatus.raydium_status.last_migration ? (
                `Last migration: ${formatRelativeTime(systemStatus.raydium_status.last_migration)}`
              ) : (
                "No migrations yet"
              )}
            </p>
          </div>
        </div>
        
        {/* System Logs */}
        <div className="mt-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold flex items-center gap-2">
              <span>System Logs</span>
            </h3>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowLogs(!showLogs)}
            >
              {showLogs ? (
                <><EyeOff className="h-4 w-4 mr-1" /> Hide Logs</>
              ) : (
                <><Eye className="h-4 w-4 mr-1" /> Show Logs</>
              )}
            </Button>
          </div>
          
          {showLogs && (
            <div className="max-h-60 overflow-y-auto border rounded-md p-2 text-xs font-mono">
              {systemStatus.system_logs.map((log, index) => (
                <div key={index} className="py-1 border-b border-dashed last:border-0">
                  <span className="text-muted-foreground mr-2">
                    {new Date(log.timestamp).toLocaleTimeString()}
                  </span>
                  <Badge variant={getBadgeVariant(log.type)} className="mr-2 px-1 py-0">{log.type}</Badge>
                  <span>{log.message}</span>
                </div>
              ))}
              {systemStatus.system_logs.length === 0 && (
                <div className="text-center py-4 text-muted-foreground">No logs available</div>
              )}
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="default" 
                className="gap-2"
                onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/autonomous-status'] })}
                disabled={isLoading || reconnecting}
              >
                {reconnecting ? (
                  <>
                    <RotateCw className="h-4 w-4 animate-spin" />
                    <span>Reconnecting...</span>
                  </>
                ) : (
                  <>
                    <RotateCw className="h-4 w-4" />
                    <span>Refresh Status</span>
                  </>
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Refresh system status data</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        {/* Accelerated mode button - only show if no tokens have been created yet */}
        {!acceleratedMode && systemStatus.market_analysis.reason.includes("first token") && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  className="gap-2"
                  onClick={triggerAcceleratedMode}
                  disabled={acceleratedMode}
                >
                  <Rocket className="h-4 w-4" />
                  <span>Accelerate First Token</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Speed up first token creation for testing</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </CardFooter>
    </Card>
  );
}