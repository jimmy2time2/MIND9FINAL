import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { truncateWalletAddress } from "@/lib/utils";
import { Loader2 } from "lucide-react";

interface AIWalletData {
  address: string;
  balance: number;
  updated_at: string;
}

export default function AIWalletInfo() {
  // Fetch AI wallet balance
  const { data, isLoading, error } = useQuery<AIWalletData>({
    queryKey: ['/api/ai-wallet/balance'],
    refetchInterval: 60000, // Refresh every minute
  });

  return (
    <Card className="border border-amber-500/20 bg-amber-500/5">
      <CardHeader className="pb-2">
        <CardTitle className="text-amber-500 flex items-center text-sm font-mono">
          <span className="mr-2">AI WALLET</span>
          <Badge variant="outline" className="font-mono">TRANSPARENCY</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Address:</span>
            <a 
              href={`https://explorer.solana.com/address/${data?.address || '8Xe5...DXzR'}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-mono hover:text-amber-500 transition-colors"
            >
              {data?.address 
                ? truncateWalletAddress(data.address, 4, 3) 
                : '8Xe5...DXzR'}
            </a>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Balance:</span>
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            ) : error ? (
              <span className="text-xs font-mono text-red-500">Error loading</span>
            ) : (
              <span className="text-xs font-mono font-bold">
                {data?.balance !== undefined 
                  ? data.balance.toFixed(4) 
                  : "0.0000"} SOL
              </span>
            )}
          </div>
          <div className="text-[10px] text-muted-foreground mt-2">
            This wallet creates tokens and receives 5% of each token launch + 50% of trading fees (1% of trade value)
          </div>
        </div>
      </CardContent>
    </Card>
  );
}