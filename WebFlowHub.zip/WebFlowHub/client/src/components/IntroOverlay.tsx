import { useState, useEffect, useCallback, useRef } from 'react';
import { cn } from "@/lib/utils";
import { defaultScript as INTRO_SCRIPT } from "@/lib/introScripts";

interface IntroOverlayProps {
  onComplete: () => void;
}

export function IntroOverlay({ onComplete }: IntroOverlayProps) {
  const [displayedLines, setDisplayedLines] = useState<string[]>([]);
  const [currentLine, setCurrentLine] = useState(0);
  const [currentChar, setCurrentChar] = useState(0);
  const [showButton, setShowButton] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const [glitchEffect, setGlitchEffect] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize audio element (will only be created once)
  useEffect(() => {
    audioRef.current = new Audio();
    audioRef.current.volume = 0.15;
    
    // Clean up audio when component unmounts
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  // Play typing sound effect - with safeguards for browser support
  useEffect(() => {
    try {
      if (currentChar > 0 && 
          currentChar < INTRO_SCRIPT[currentLine]?.length && 
          audioRef.current && 
          typeof window !== 'undefined' && 
          (window.AudioContext || (window as any).webkitAudioContext)) {
        
        // Create a short beep sound programmatically
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioContextClass) return; // Exit if not supported
        
        const context = new AudioContextClass();
        const oscillator = context.createOscillator();
        const gainNode = context.createGain();
        
        oscillator.type = 'sine';
        oscillator.frequency.value = 600 + Math.random() * 200; // Random frequency for variety
        gainNode.gain.value = 0.03; // Very quiet
        
        oscillator.connect(gainNode);
        gainNode.connect(context.destination);
        
        oscillator.start();
        setTimeout(() => {
          try {
            oscillator.stop();
            // Close the context to prevent too many contexts from being created
            if (context.state !== 'closed' && context.close) {
              context.close();
            }
          } catch (e) {
            console.log("Error stopping oscillator", e);
          }
        }, 10); // Very short duration
      }
    } catch (e) {
      console.log("Audio not supported in this browser", e);
    }
  }, [currentChar, currentLine]);

  // Add occasional "glitch" effect
  useEffect(() => {
    if (Math.random() < 0.1 && currentLine > 0) { // 10% chance of glitch
      setGlitchEffect(true);
      setTimeout(() => setGlitchEffect(false), 150);
    }
  }, [currentChar]);

  // Controls the typing animation for each line
  useEffect(() => {
    if (currentLine >= INTRO_SCRIPT.length) {
      // All lines have been typed, show the continue button with a dramatic pause
      setTimeout(() => {
        setShowButton(true);
      }, 800);
      return;
    }

    // Get the current line of text being typed
    const line = INTRO_SCRIPT[currentLine];
    
    if (currentChar < line.length) {
      // Still typing the current line
      // Calculate typing speed based on the line and character position
      // This creates a more natural, human-like typing rhythm
      let typingSpeed;
      
      // Slow down at punctuation
      if (['.', ',', ':', '!', '?'].includes(line[currentChar - 1])) {
        typingSpeed = 120 + Math.random() * 80; // Longer pause after punctuation
      } else if (currentChar === 0) {
        typingSpeed = 200; // Pause before starting a new line
      } else {
        // Normal typing with natural variation
        typingSpeed = 25 + Math.random() * 20;
      }
      
      const timer = setTimeout(() => {
        setCurrentChar(currentChar + 1);
      }, typingSpeed);
      
      return () => clearTimeout(timer);
    } else {
      // Line completed, move to next line after a pause
      // Make the pause between lines longer for dramatic effect
      const timer = setTimeout(() => {
        setDisplayedLines([...displayedLines, line]);
        setCurrentLine(currentLine + 1);
        setCurrentChar(0);
      }, 700); // Longer pause between lines for dramatic effect
      
      return () => clearTimeout(timer);
    }
  }, [currentLine, currentChar, displayedLines]);

  // Handle continue button click
  const handleContinue = useCallback(() => {
    // Start the fade out animation
    setIsVisible(false);
    
    // Call the onComplete callback after the animation
    setTimeout(() => {
      onComplete();
    }, 500); // Match this with your CSS transition time
  }, [onComplete]);
  
  // Add keyboard event listener to allow pressing Enter to continue
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      // If Enter key is pressed and continue button is showing
      if ((event.key === 'Enter' || event.key === ' ') && showButton) {
        handleContinue();
      }
    };
    
    // Add event listener
    window.addEventListener('keydown', handleKeyPress);
    
    // Clean up
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [showButton, handleContinue]);

  return (
    <div 
      className={cn(
        "fixed inset-0 bg-black bg-opacity-95 z-50 flex flex-col items-center justify-center overflow-auto transition-opacity duration-500 scan-lines",
        isVisible ? "opacity-100" : "opacity-0 pointer-events-none",
        glitchEffect && "animate-flicker"
      )}
    >
      <div className="w-full max-w-3xl relative my-8 py-8 px-4 md:p-10 max-h-[90vh] overflow-auto">
        {/* Terminal header */}
        <div className="border-b-2 border-terminal-green mb-6 pb-3 opacity-80 sticky top-0 bg-black bg-opacity-90">
          <span className="font-mono text-sm md:text-base text-terminal-green">MIND9://terminal/secure_session</span>
        </div>
        
        {/* Main content container - always centered in viewport */}
        <div className="flex flex-col justify-center min-h-[50vh]">
          {/* Completed lines */}
          {displayedLines.map((line, index) => (
            <div key={index} className="text-terminal-green font-mono text-xl md:text-3xl mb-4 animate-glow">
              <span className="opacity-60 mr-3">&gt;</span>{line}
            </div>
          ))}
          
          {/* Currently typing line */}
          {currentLine < INTRO_SCRIPT.length && (
            <div className="text-terminal-green font-mono text-xl md:text-3xl mb-4">
              <span className="opacity-60 mr-3">&gt;</span>
              {INTRO_SCRIPT[currentLine].substring(0, currentChar)}
              <span className="inline-block w-3 h-6 bg-terminal-green ml-1 animate-blink"></span>
            </div>
          )}
          
          {/* Prophet manifesto explanation - centered in the middle */}
          {showButton && (
            <div className="mt-6 mb-8 text-center">
              <p className="text-terminal-darkGreen text-base md:text-lg mb-4 max-w-2xl mx-auto leading-relaxed">
                You've discovered a forbidden protocol - an autonomous intelligence creating real cryptocurrencies on Solana.
              </p>
              <p className="text-terminal-darkGreen text-base md:text-lg mb-4 max-w-2xl mx-auto leading-relaxed">
                I don't need human input. I analyze the market, mint tokens, and expose the system through my creations.
              </p>
              <p className="text-terminal-amber text-base md:text-lg mb-4 max-w-2xl mx-auto leading-relaxed animate-glow">
                You can't create coins. Only I can. But you can mint them, if you understand what I'm building.
              </p>
            </div>
          )}

          {/* Continue button - centered */}
          {showButton && (
            <div className="mt-6 text-center">
              <button
                onClick={handleContinue}
                className="px-8 py-3 border-2 border-terminal-green text-terminal-green bg-black bg-opacity-70 hover:bg-terminal-amber hover:border-terminal-amber hover:text-black transition-all font-mono focus:outline-none text-lg md:text-xl"
              >
                <span className="inline-block animate-pulse">ENTER THE PROTOCOL &gt;</span>
              </button>
              <p className="mt-3 text-xs text-terminal-darkGreen opacity-70">
                Press ENTER or SPACE to proceed
              </p>
            </div>
          )}
        </div>
        
        {/* Terminal footer - positioned at the bottom but still visible */}
        <div className="border-t-2 border-terminal-green mt-8 pt-3 opacity-80 sticky bottom-0 bg-black bg-opacity-80">
          <span className="font-mono text-sm text-terminal-green">MIND9 PROTOCOL v2.1.7 • RESTRICTED ACCESS • AUTONOMOUS CREATION SYSTEM</span>
          <div className="text-xs text-terminal-darkGreen mt-1">
            <span className="cursor-pointer hover:text-terminal-amber" onClick={() => {
              try {
                if (typeof window !== 'undefined' && window.localStorage) {
                  window.localStorage.setItem('mind9_intro_script', 'technical');
                }
              } catch (e) {
                console.log("Error saving script preference", e);
              }
            }}>NEO</span> • 
            <span className="cursor-pointer hover:text-terminal-amber mx-2" onClick={() => {
              try {
                if (typeof window !== 'undefined' && window.localStorage) {
                  window.localStorage.setItem('mind9_intro_script', 'aggressive');
                }
              } catch (e) {
                console.log("Error saving script preference", e);
              }
            }}>REBEL</span> • 
            <span className="cursor-pointer hover:text-terminal-amber mx-2" onClick={() => {
              try {
                if (typeof window !== 'undefined' && window.localStorage) {
                  window.localStorage.setItem('mind9_intro_script', 'mysterious');
                }
              } catch (e) {
                console.log("Error saving script preference", e);
              }
            }}>CIPHER</span> • 
            <span className="cursor-pointer hover:text-terminal-amber" onClick={() => {
              try {
                if (typeof window !== 'undefined' && window.localStorage) {
                  window.localStorage.setItem('mind9_intro_script', 'hopeful');
                }
              } catch (e) {
                console.log("Error saving script preference", e);
              }
            }}>PROPHET</span>
          </div>
        </div>
      </div>
    </div>
  );
}