import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { truncateWalletAddress } from "@/lib/utils";
import { connectWallet, disconnectWallet, useWallet } from "@/lib/solana";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface WalletConnectorProps {
  poolSize: number;
}

export default function WalletConnector({ poolSize }: WalletConnectorProps) {
  const { walletAddress, connecting } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Calculate win chance percentage based on pool size
  const winChance = poolSize > 0 ? (1 / poolSize * 100).toFixed(3) : "0.000";
  
  // Add wallet to lucky trader pool
  const addToLuckyTraderPool = useMutation({
    mutationFn: async (walletAddress: string) => {
      return apiRequest("/api/lucky-trader", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ wallet_address: walletAddress })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/lucky-trader/pool'] });
      toast({
        title: "Wallet Connected",
        description: "Your wallet has been added to the Lucky Trader Pool",
      });
    },
    onError: (error) => {
      toast({
        title: "Connection Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleConnectWallet = async () => {
    try {
      const walletAddress = await connectWallet();
      if (walletAddress) {
        addToLuckyTraderPool.mutate(walletAddress);
      }
    } catch (error) {
      console.error("Error connecting wallet:", error);
      toast({
        title: "Connection Failed",
        description: "Failed to connect wallet. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const handleDisconnect = () => {
    disconnectWallet();
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected",
    });
  };

  return (
    <div className="border-t border-terminal-darkGreen pt-3 mb-4">
      <div className="mb-2 font-bold text-terminal-amber">CONNECT WALLET TO RECEIVE TOKENS</div>
      
      {!walletAddress ? (
        <div className="block">
          <div className="text-sm mb-3">
            <span>&gt; MIND9 AI DISTRIBUTES TOKENS AUTOMATICALLY</span>
            <p className="text-xs mt-1 text-terminal-darkGreen">
              Mind9 AI distributes 3% of each token to connected wallets automatically. One lucky trader is selected for each new token creation.
            </p>
          </div>
          <button 
            onClick={handleConnectWallet}
            disabled={connecting}
            className="w-full border border-terminal-green hover:bg-terminal-green hover:text-terminal-black transition-colors px-3 py-1 mb-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {connecting ? "CONNECTING..." : "CONNECT WALLET"}
          </button>
        </div>
      ) : (
        <div>
          <div className="text-sm mb-3">
            <span className="text-terminal-green">✓ WALLET CONNECTED</span><br/>
            <span className="text-xs break-all">{truncateWalletAddress(walletAddress)}</span>
          </div>
          <div className="text-xs">
            <div className="flex justify-between">
              <span>LUCKY TRADER STATUS:</span>
              <span className="text-terminal-green">ACTIVE</span>
            </div>
            <div className="flex justify-between">
              <span>TOTAL TRADERS:</span>
              <span>{poolSize}</span>
            </div>
            <div className="flex justify-between">
              <span>SELECTION CHANCE:</span>
              <span>{winChance}%</span>
            </div>
            <div className="flex justify-between mb-1">
              <span>PROFIT SHARE:</span>
              <span className="text-terminal-amber">3%</span>
            </div>
            <button 
              onClick={handleDisconnect}
              className="w-full mt-2 border border-terminal-red hover:bg-terminal-red hover:text-terminal-black transition-colors px-3 py-1 text-xs"
            >
              DISCONNECT
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
