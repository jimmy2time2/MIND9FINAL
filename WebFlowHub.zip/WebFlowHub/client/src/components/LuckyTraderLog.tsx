import { truncateWalletAddress } from "@/lib/utils";
import { Coin, LuckyTrader } from "@/lib/types";
import { useWallet } from '@/lib/solana';

interface LuckyTraderLogProps {
  coins: any[];
}

export default function LuckyTraderLog({ coins }: LuckyTraderLogProps) {
  const { isConnected } = useWallet();
  
  // Filter out any wallet addresses that start with "simu" - these are simulated wallets
  const realTraders = coins?.filter(coin => {
    const walletAddress = coin.lucky_trader_wallet || coin.wallet_address;
    return walletAddress && !walletAddress.toLowerCase().includes('simu');
  });

  return (
    <div className="border-t border-terminal-darkGreen pt-3">
      <div className="mb-2 font-bold text-terminal-amber">LUCKY TRADER AWARDS</div>
      <div className="h-40 overflow-y-auto text-xs">
        {isConnected && realTraders && realTraders.length > 0 ? (
          realTraders.map((coin, index) => (
            <div className="mb-2" key={index}>
              <div className="flex flex-wrap">
                <span className="text-terminal-amber mr-1">
                  [{new Date(coin.timestamp || coin.joined_at).toLocaleDateString('en-US', {
                    day: '2-digit',
                    month: '2-digit'
                  }).replace('/', '.')}]
                </span>
                <span className="text-terminal-green">3%</span>
                <span className="ml-1">of</span>
                <span className="text-terminal-blue ml-1">${coin.symbol || "TOKEN"}</span>
                <span className="ml-1">to</span>
              </div>
              <div className="text-terminal-green break-all">
                {truncateWalletAddress(coin.lucky_trader_wallet || coin.wallet_address)}
              </div>
            </div>
          ))
        ) : (
          <div className="text-terminal-amber py-2">
            {isConnected ? (
              <>
                WAITING FOR NEW TOKEN CREATION<br />
                You're in the lucky trader pool - you'll receive 3% of the next token created
                <span className="animate-blink ml-1">█</span>
              </>
            ) : (
              <>
                NO WALLETS CONNECTED<br />
                Connect your wallet to join the lucky trader pool and receive 3% of future token mints automatically
                <span className="animate-blink ml-1">█</span>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
