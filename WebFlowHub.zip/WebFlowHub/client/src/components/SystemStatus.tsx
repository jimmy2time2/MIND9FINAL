import { useState, useEffect } from "react";
import WalletConnector from "./WalletConnector";
import LuckyTraderLog from "./LuckyTraderLog";
import { formatDistanceToNow } from "date-fns";
import { Coin, LuckyTraderPool } from "@/lib/types";

interface SystemStatusProps {
  luckyTraderPool?: LuckyTraderPool;
  lastCoin: Coin | null;
}

export default function SystemStatus({ luckyTraderPool, lastCoin }: SystemStatusProps) {
  const [nextAnalysisTime, setNextAnalysisTime] = useState<string>("00:00:00");
  
  useEffect(() => {
    // Set the next analysis time based on the 8-hour market analysis interval
    // This is fixed to 8 hours from now as defined in the server code
    const interval = setInterval(() => {
      const now = new Date();
      // Calculate next analysis at 8 hours from now, consistent with server config
      const secondsInHour = 60 * 60;
      const hours = 8;
      const future = new Date(now.getTime() + (hours * secondsInHour * 1000));
      
      // Format as remaining time
      const remainingTime = formatDistanceToNow(future, { addSuffix: false });
      setNextAnalysisTime(`IN ${remainingTime.toUpperCase()}`);
    }, 60000); // Update every minute
    
    // Initial update
    const now = new Date();
    const future = new Date(now.getTime() + (8 * 60 * 60 * 1000));
    const remainingTime = formatDistanceToNow(future, { addSuffix: false });
    setNextAnalysisTime(`IN ${remainingTime.toUpperCase()}`);
    
    return () => clearInterval(interval);
  }, []);

  // Format the last coin mint time if available
  const lastCoinTime = lastCoin ? 
    new Date(lastCoin.timestamp).toLocaleDateString('en-US', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }).replace(/(\d+)\/(\d+)\/(\d+)/, '$2.$1.$3') : 
    "AWAITING FIRST MINT";

  return (
    <section id="system-status-panel" className="lg:col-span-1 border border-terminal-darkGreen p-2 h-fit">
      <div className="border-b border-terminal-darkGreen mb-3 pb-1">
        <h2 className="font-bold">
          <span className="text-terminal-amber">&gt;</span> 
          MIND9 AI STATUS
        </h2>
      </div>
      
      <div className="mb-4 text-sm">
        <div className="flex justify-between mb-1">
          <span>AI DECISION ENGINE:</span>
          <span className="text-terminal-green">OPERATIONAL <span className="animate-blink">█</span></span>
        </div>
        <div className="flex justify-between mb-1">
          <span>MARKET ANALYSIS:</span>
          <span className="text-terminal-green">ACTIVE</span>
        </div>
        <div className="flex justify-between mb-1">
          <span>BLOCKCHAIN NET:</span>
          <span className="text-terminal-green">SOLANA MAINNET</span>
        </div>
        <div className="flex justify-between mb-1">
          <span>LP PROVIDER:</span>
          <span className="text-terminal-amber">RAYDIUM</span>
        </div>
        <div className="flex justify-between mb-1">
          <span>LAST TOKEN MINT:</span>
          <span className="text-terminal-blue">{lastCoinTime}</span>
        </div>
        <div className="flex justify-between mb-1">
          <span>NEXT ANALYSIS:</span>
          <span className="text-terminal-amber">{nextAnalysisTime}</span>
        </div>

        <div className="flex justify-between mb-1">
          <span>LUCKY TRADER SHARE:</span>
          <span className="text-terminal-green">3%</span>
        </div>
      </div>
      
      <div id="lucky-trader-panel">
        <WalletConnector poolSize={luckyTraderPool?.total || 0} />
      </div>
      
      <LuckyTraderLog coins={luckyTraderPool?.traders || []} />
    </section>
  );
}
