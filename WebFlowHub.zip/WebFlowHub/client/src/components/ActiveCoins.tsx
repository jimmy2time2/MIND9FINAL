import { truncateWalletAddress } from "@/lib/utils";
import { Coin } from "@/lib/types";
import { FiBarChart2, FiCheck } from "react-icons/fi";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";

interface ActiveCoinsProps {
  coins: Coin[];
  onCoinSelect?: (coinId: number) => void;
}

export default function ActiveCoins({ coins = [], onCoinSelect }: ActiveCoinsProps) {
  const [verifyingCoins, setVerifyingCoins] = useState<Record<number, boolean>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Handle verification of a coin on Solana blockchain
  const handleVerifyCoin = async (coinId: number, e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (verifyingCoins[coinId]) return;
    
    // Set this coin as currently being verified
    setVerifyingCoins(prev => ({ ...prev, [coinId]: true }));
    
    try {
      // Make a request to verify the token on the blockchain
      const response = await apiRequest(`/api/coins/verify/${coinId}`, {
        method: 'POST'
      });
      
      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "Verification Successful",
          description: "Token verified on Solana blockchain",
          variant: "default"
        });
        
        // Refresh the coins list to update verification status
        queryClient.invalidateQueries({ queryKey: ['/api/coins'] });
      } else {
        throw new Error(result.message || "Verification failed");
      }
    } catch (error) {
      console.error("Error verifying coin:", error);
      toast({
        title: "Verification Failed",
        description: error instanceof Error ? error.message : "Failed to verify token on blockchain",
        variant: "destructive"
      });
    } finally {
      // Remove this coin from the verifying state
      setVerifyingCoins(prev => {
        const newState = { ...prev };
        delete newState[coinId];
        return newState;
      });
    }
  };
  
  // Delete function removed to ensure system autonomy
  return (
    <section className="mt-6 border border-terminal-darkGreen p-2">
      <div className="border-b border-terminal-darkGreen mb-3 pb-1">
        <h2 className="font-bold">
          <span className="text-terminal-amber">&gt;</span> 
          ACTIVE AI-GENERATED COINS
        </h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {coins && coins.length > 0 ? (
          coins.map((coin, index) => (
            <div 
              key={index} 
              className="border border-terminal-darkGreen p-2 bg-terminal-black/30 hover:bg-terminal-black/50 transition-colors"
            >
              <div className="text-terminal-green font-bold flex justify-between">
                <span>${coin.symbol}</span>
                <div className="flex items-center">
                  <span className="text-terminal-amber text-xs">
                    {new Date(coin.timestamp).toLocaleDateString('en-US', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric'
                    }).replace(/(\d+)\/(\d+)\/(\d+)/, '$2.$1.$3')}
                  </span>
                </div>
              </div>
              <div className="text-xs mt-1">
                <div><span className="text-terminal-amber">MINT:</span> {truncateWalletAddress(coin.mint_address)}</div>
                <div><span className="text-terminal-amber">SUPPLY:</span> {coin.total_supply}</div>
                <div><span className="text-terminal-amber">LIQUIDITY:</span> {coin.liquidity_sol} SOL</div>
                <div className="flex items-center mt-1">
                  <span className="text-terminal-amber mr-1">STATUS:</span>
                  {coin.minted ? (
                    <span className="bg-green-900 text-green-300 px-1 rounded text-xs flex items-center">
                      <FiCheck size={10} className="mr-1" /> VERIFIED
                    </span>
                  ) : (
                    <button 
                      onClick={(e) => handleVerifyCoin(coin.id, e)}
                      disabled={verifyingCoins[coin.id]}
                      className="border border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black px-1 rounded text-xs transition-colors flex items-center"
                    >
                      {verifyingCoins[coin.id] ? (
                        <>
                          <div className="animate-spin h-2 w-2 border border-current rounded-full border-t-transparent mr-1"></div>
                          VERIFYING...
                        </>
                      ) : (
                        <>
                          <FiBarChart2 size={10} className="mr-1" /> VERIFY
                        </>
                      )}
                    </button>
                  )}
                </div>
                <div className="mt-2">
                  <Link 
                    to={`/coin/${coin.id}`}
                    className="text-terminal-green hover:text-terminal-darkGreen cursor-pointer"
                  >
                    MINT & MANAGE TOKEN
                  </Link>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-terminal-amber text-center py-4">
            NO ACTIVE COINS - AI WILL GENERATE SOON <span className="animate-blink">█</span>
          </div>
        )}
      </div>
    </section>
  );
}
