import React, { useState, useEffect } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { apiRequest } from '@/lib/queryClient';
import { useWallet } from '@/lib/solana';
import { truncateWalletAddress } from '@/lib/utils';
import { ArrowDownUp, Info, AlertCircle, Gift } from 'lucide-react';
import type { Coin } from '@/lib/types';

interface TradePanelProps {
  coin: Coin;
}

export default function TradePanel({ coin }: TradePanelProps) {
  const [currentPrice, setCurrentPrice] = useState<number>(0);
  const [solAmount, setSolAmount] = useState<string>('0.1');
  const [tokenAmount, setTokenAmount] = useState<string>('0');
  const [mintAmount, setMintAmount] = useState<string>('1000');
  const [slippage, setSlippage] = useState<number>(0);
  const [priceImpact, setPriceImpact] = useState<number>(0);
  const [fees, setFees] = useState<any>(null);
  const [isBuying, setIsBuying] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isMinting, setIsMinting] = useState<boolean>(false);
  const { toast } = useToast();
  const { walletAddress, isConnected } = useWallet();

  // Fetch current price for this token
  useEffect(() => {
    const fetchPrice = async () => {
      try {
        if (!coin?.mint_address) return;

        const response = await apiRequest(`/api/trading/price/${coin.mint_address}`);
        const data = await response.json();
        setCurrentPrice(data.price);
      } catch (error) {
        console.error('Failed to fetch token price:', error);
      }
    };

    fetchPrice();
    // Refresh price every 15 seconds
    const interval = setInterval(fetchPrice, 15000);
    return () => clearInterval(interval);
  }, [coin]);

  // Calculate token amount when SOL amount changes (Buy mode)
  useEffect(() => {
    if (isBuying && currentPrice > 0) {
      const sol = parseFloat(solAmount) || 0;
      const tokens = sol / currentPrice;
      setTokenAmount(tokens.toFixed(6));
    }
  }, [solAmount, currentPrice, isBuying]);

  // Calculate SOL amount when token amount changes (Sell mode)
  useEffect(() => {
    if (!isBuying && currentPrice > 0) {
      const tokens = parseFloat(tokenAmount) || 0;
      const sol = tokens * currentPrice;
      setSolAmount(sol.toFixed(6));
    }
  }, [tokenAmount, currentPrice, isBuying]);

  // Calculate fees when amount changes
  useEffect(() => {
    const calculateFees = async () => {
      try {
        const sol = parseFloat(solAmount) || 0;
        if (sol <= 0) return;

        const response = await apiRequest('/api/trading/calculate-fees', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sol_amount: sol }),
        });
        
        const feeData = await response.json();
        setFees(feeData);
      } catch (error) {
        console.error('Failed to calculate fees:', error);
      }
    };

    calculateFees();
  }, [solAmount]);

  const handleBuy = async () => {
    if (!isConnected) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to trade.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const sol = parseFloat(solAmount);
      if (isNaN(sol) || sol <= 0) throw new Error("Invalid SOL amount");

      const response = await apiRequest('/api/trading/buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          wallet_address: walletAddress,
          mint_address: coin.mint_address,
          sol_amount: sol
        }),
      });
      
      const result = await response.json();
      
      if (!result.success) {
        throw new Error(result.message || "Transaction failed");
      }
      
      setSlippage(result.slippage);
      setPriceImpact(result.priceImpact);
      
      toast({
        title: "Purchase Successful",
        description: `You bought ${result.tokenAmount?.toFixed(6) || tokenAmount} ${coin.symbol} for ${sol} SOL`
      });
    } catch (error: any) {
      toast({
        title: "Transaction Failed",
        description: error.message || "Failed to buy token. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSell = async () => {
    if (!isConnected) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to trade.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const tokens = parseFloat(tokenAmount);
      if (isNaN(tokens) || tokens <= 0) throw new Error("Invalid token amount");

      const response = await apiRequest('/api/trading/sell', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          wallet_address: walletAddress,
          mint_address: coin.mint_address,
          token_amount: tokens
        }),
      });
      
      const result = await response.json();
      
      if (!result.success) {
        throw new Error(result.message || "Transaction failed");
      }
      
      setSlippage(result.slippage);
      setPriceImpact(result.priceImpact);
      
      toast({
        title: "Sale Successful",
        description: `You sold ${tokens.toFixed(6)} ${coin.symbol} for ${result.solAmount?.toFixed(6) || solAmount} SOL`
      });
    } catch (error: any) {
      toast({
        title: "Transaction Failed",
        description: error.message || "Failed to sell token. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleMint = async () => {
    if (!isConnected) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to mint tokens.",
        variant: "destructive"
      });
      return;
    }
    
    if (!coin.minted || !coin.user_mintable) {
      toast({
        title: "Token not mintable",
        description: "This token is not currently available for minting.",
        variant: "destructive"
      });
      return;
    }
    
    setIsMinting(true);
    try {
      const amount = parseInt(mintAmount);
      if (isNaN(amount) || amount < 100 || amount > 10000) {
        throw new Error("Amount must be between 100 and 10,000 tokens");
      }
      
      const response = await apiRequest(`/api/coins/mint/${coin.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          wallet_address: walletAddress,
          amount: amount
        }),
      });
      
      const result = await response.json();
      
      if (!result.success) {
        throw new Error(result.message || "Failed to mint tokens");
      }
      
      toast({
        title: "Minting Successful",
        description: `Successfully minted ${amount} ${coin.symbol} tokens to your wallet`,
      });
    } catch (error: any) {
      toast({
        title: "Minting Failed",
        description: error.message || "Failed to mint tokens. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsMinting(false);
    }
  };

  // Check if token can be traded (has Raydium integration) or just minted
  const canTrade = coin.raydium_migrated === true;
  
  return (
    <Card className="w-full max-w-md mx-auto border-2 border-primary/10 dark:bg-black/40 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>{canTrade ? `Trade ${coin.symbol}` : `Get ${coin.symbol}`}</span>
          {canTrade && (
            <Badge variant="outline" className="ml-2">
              {currentPrice ? `1 ${coin.symbol} = ${currentPrice.toFixed(6)} SOL` : 'Loading price...'}
            </Badge>
          )}
        </CardTitle>
        <CardDescription>
          {canTrade 
            ? `Buy or sell ${coin.name} tokens through Mind9's trading system` 
            : `Mint ${coin.name} tokens directly from Mind9 protocol`}
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {canTrade ? (
          // Trading interface (for migrated tokens)
          <Tabs defaultValue="buy" className="w-full" onValueChange={(value) => setIsBuying(value === 'buy')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="buy">Buy</TabsTrigger>
              <TabsTrigger value="sell">Sell</TabsTrigger>
            </TabsList>
            
            <TabsContent value="buy" className="space-y-4">
              <div className="space-y-2 mt-4">
                <Label htmlFor="solAmount">SOL Amount</Label>
                <Input
                  id="solAmount"
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={solAmount}
                  onChange={(e) => setSolAmount(e.target.value)}
                  placeholder="0.0"
                />
              </div>
              
              <div className="flex justify-center my-2">
                <ArrowDownUp size={20} className="text-muted-foreground" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="tokenAmount">
                  {coin.symbol} Amount
                  <span className="text-muted-foreground text-xs ml-2">
                    (Estimated)
                  </span>
                </Label>
                <Input
                  id="tokenAmount"
                  type="text"
                  value={tokenAmount}
                  readOnly
                  className="bg-muted/50"
                />
              </div>
              
              <Button 
                className="w-full" 
                onClick={handleBuy} 
                disabled={!isConnected || isLoading || parseFloat(solAmount) <= 0}
              >
                {isLoading ? 'Processing...' : `Buy ${coin.symbol}`}
              </Button>
            </TabsContent>
            
            <TabsContent value="sell" className="space-y-4">
              <div className="space-y-2 mt-4">
                <Label htmlFor="tokenAmountSell">{coin.symbol} Amount</Label>
                <Input
                  id="tokenAmountSell"
                  type="number" 
                  step="0.01"
                  min="0.01"
                  value={tokenAmount}
                  onChange={(e) => setTokenAmount(e.target.value)}
                  placeholder="0.0"
                />
              </div>
              
              <div className="flex justify-center my-2">
                <ArrowDownUp size={20} className="text-muted-foreground" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="solAmountSell">
                  SOL Amount
                  <span className="text-muted-foreground text-xs ml-2">
                    (Estimated)
                  </span>
                </Label>
                <Input
                  id="solAmountSell"
                  type="text"
                  value={solAmount}
                  readOnly
                  className="bg-muted/50"
                />
              </div>
              
              <Button 
                className="w-full" 
                onClick={handleSell} 
                disabled={!isConnected || isLoading || parseFloat(tokenAmount) <= 0}
              >
                {isLoading ? 'Processing...' : `Sell ${coin.symbol}`}
              </Button>
            </TabsContent>
          </Tabs>
        ) : (
          // Minting interface (for non-migrated tokens)
          <div className="space-y-4">
            {coin.user_mintable ? (
              <>
                <div className="p-3 rounded-md bg-primary/5 text-sm flex items-start">
                  <Gift className="h-5 w-5 mr-2 text-primary shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">Free Token Minting</p>
                    <p className="text-muted-foreground mt-1">
                      This token is available for direct minting from the Mind9 protocol. Connect your wallet and mint your tokens now!
                    </p>
                  </div>
                </div>
                
                <div className="space-y-2 mt-4">
                  <Label htmlFor="mintAmount">Amount to Mint</Label>
                  <Input
                    id="mintAmount"
                    type="number" 
                    step="100"
                    min="100"
                    max="10000"
                    value={mintAmount}
                    onChange={(e) => setMintAmount(e.target.value)}
                    placeholder="1000"
                  />
                  <p className="text-xs text-muted-foreground">Min: 100, Max: 10,000 tokens</p>
                </div>
                
                <Button 
                  className="w-full mt-4" 
                  onClick={handleMint} 
                  disabled={!isConnected || isMinting || !coin.user_mintable}
                >
                  {isMinting ? 'Minting...' : `Mint ${coin.symbol} Tokens`}
                </Button>
              </>
            ) : (
              <div className="p-4 border rounded-md bg-muted/20 text-sm">
                <p className="font-medium text-center mb-2">Token Not Available for Minting Yet</p>
                <p className="text-muted-foreground text-center">
                  This token is still in preparation phase and not yet available for public minting. Check back soon!
                </p>
                {coin.liquidity_progress !== undefined && (
                  <div className="mt-4">
                    <div className="font-medium mb-1 text-center">Preparation Progress:</div>
                    <div className="flex items-center mt-2">
                      <div className="w-full bg-muted rounded-full h-2 mr-2">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ width: `${coin.liquidity_progress || 0}%` }}
                        ></div>
                      </div>
                      <span className="text-xs">{coin.liquidity_progress || 0}%</span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </CardContent>
      
      <Separator />
      
      <CardFooter className="flex flex-col items-start pt-4">
        {canTrade ? (
          // Trading details for migrated tokens
          <div className="w-full space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Price:</span>
              <span>{currentPrice ? `${currentPrice.toFixed(6)} SOL per ${coin.symbol}` : 'Loading...'}</span>
            </div>
            
            {fees && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Trading Fee (2%):</span>
                <span>{fees.totalFee.toFixed(6)} SOL</span>
              </div>
            )}
            
            {slippage > 0 && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Slippage:</span>
                <span>{slippage.toFixed(2)}%</span>
              </div>
            )}
            
            {priceImpact > 0 && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Price Impact:</span>
                <span className={priceImpact > 5 ? "text-red-500" : ""}>{priceImpact.toFixed(2)}%</span>
              </div>
            )}
          </div>
        ) : (
          // Minting details for non-migrated tokens
          <div className="w-full space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Mint Fee:</span>
              <span>FREE</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-muted-foreground">Network Fee:</span>
              <span>~0.000005 SOL</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-muted-foreground">Token Standard:</span>
              <span>Solana SPL</span>
            </div>
          </div>
        )}
        
        {!isConnected && (
          <div className="mt-4 w-full p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg flex items-center text-sm">
            <AlertCircle size={16} className="text-yellow-500 mr-2 flex-shrink-0" />
            <span>Connect your wallet to {canTrade ? 'trade' : 'mint'} {coin.symbol} tokens.</span>
          </div>
        )}
      </CardFooter>
    </Card>
  );
}