import React, { useState, useEffect } from 'react';
import { Coin } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useWallet } from '@/lib/solana';
import { truncateWalletAddress } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FiArrowUp, FiArrowDown, FiInfo, FiMaximize2, FiChevronDown } from 'react-icons/fi';

interface TradingPanelProps {
  coin: Coin;
}

export function TradingPanel({ coin }: TradingPanelProps) {
  const { toast } = useToast();
  const { walletAddress, connecting, isConnected } = useWallet();
  const [amount, setAmount] = useState<string>('');
  const [slippage, setSlippage] = useState<number>(1); // 1%
  const [isBuying, setIsBuying] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showSlippageOptions, setShowSlippageOptions] = useState<boolean>(false);
  const [walletBalance, setWalletBalance] = useState<number | null>(null);

  // Calculate max amount user can buy or sell
  const maxAmount = isBuying ? (walletBalance || 0) : calculateTokenBalance();

  // Fetch wallet balance when wallet connects
  useEffect(() => {
    async function getBalance() {
      if (walletAddress) {
        try {
          const response = await apiRequest(`/api/ai-wallet/balance`, {
            method: 'GET',
          });
          const data = await response.json();
          setWalletBalance(data.balance);
        } catch (error) {
          console.error('Failed to fetch wallet balance:', error);
        }
      } else {
        setWalletBalance(null);
      }
    }

    getBalance();
  }, [walletAddress]);

  // Function to calculate how many tokens the user has
  function calculateTokenBalance() {
    // This would come from an API call or wallet state in production
    // For now, we'll return a placeholder value
    return 100;
  }

  // Handle amount input change
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Allow only numbers and up to 4 decimal places
    if (/^\d*\.?\d{0,4}$/.test(value) || value === '') {
      setAmount(value);
    }
  };

  // Set amount to max available
  const handleMaxAmount = () => {
    setAmount(maxAmount.toString());
  };

  // Handle slippage change
  const handleSlippageChange = (newSlippage: number) => {
    setSlippage(newSlippage);
    setShowSlippageOptions(false);
  };

  // Connect wallet handler - in our case will show phantom dialog
  const connectWallet = () => {
    // This function will call phantom's connect 
    window.open('https://phantom.app/', '_blank');

    toast({
      title: 'Wallet Connection',
      description: 'Please connect using your Phantom wallet app',
    });
  };

  // Execute the trade
  const handleTrade = async () => {
    if (!walletAddress) {
      toast({
        title: 'Wallet not connected',
        description: 'Please connect your wallet to trade',
        variant: 'destructive',
      });
      return;
    }

    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: 'Invalid amount',
        description: 'Please enter a valid amount',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await apiRequest('/api/trade', {
        method: 'POST',
        body: JSON.stringify({
          coinId: coin.id,
          walletAddress: walletAddress,
          amount: parseFloat(amount),
          action: isBuying ? 'buy' : 'sell',
          slippage,
        }),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: 'Trade Successful',
          description: `Successfully ${isBuying ? 'bought' : 'sold'} ${coin.symbol} tokens`,
        });
        
        // Reset form
        setAmount('');
        
        // Refresh wallet balance
        const balanceResponse = await apiRequest(`/api/ai-wallet/balance`, {
          method: 'GET',
        });
        const balanceData = await balanceResponse.json();
        setWalletBalance(balanceData.balance);
      } else {
        throw new Error(result.message || 'Trade failed');
      }
    } catch (error) {
      console.error('Error executing trade:', error);
      toast({
        title: 'Trade Failed',
        description: error instanceof Error ? error.message : 'Failed to execute trade',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Calculate estimated tokens to receive or SOL to receive
  const calculateEstimate = () => {
    if (!amount || parseFloat(amount) <= 0) return '0';
    
    // This is a placeholder calculation
    // In production, this would call an API to get the exact amount based on the bonding curve
    const inputAmount = parseFloat(amount);
    
    if (isBuying) {
      // Buying: SOL -> Tokens, with current token price from the most recent chart data point
      // For example, 1 SOL might get you 20 tokens at a price of 0.05 SOL per token
      const estimatedTokens = inputAmount / 0.05;
      return estimatedTokens.toFixed(4);
    } else {
      // Selling: Tokens -> SOL
      const estimatedSol = inputAmount * 0.05;
      return estimatedSol.toFixed(4);
    }
  };

  return (
    <div className="w-full bg-black bg-opacity-80 border border-terminal-green p-4 rounded-sm">
      <h3 className="text-terminal-green font-mono text-lg mb-4">
        TRADE ${coin.symbol}
      </h3>
      
      <Tabs defaultValue="buy" className="w-full">
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger 
            value="buy"
            onClick={() => setIsBuying(true)}
            className="data-[state=active]:bg-terminal-green data-[state=active]:text-black"
          >
            BUY
          </TabsTrigger>
          <TabsTrigger 
            value="sell"
            onClick={() => setIsBuying(false)}
            className="data-[state=active]:bg-terminal-green data-[state=active]:text-black"
          >
            SELL
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="buy" className="mt-0">
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-sm text-terminal-darkGreen font-mono">
                  AMOUNT (SOL)
                </label>
                {walletAddress && (
                  <span className="text-xs text-terminal-darkGreen font-mono">
                    Balance: {walletBalance !== null ? `${walletBalance} SOL` : 'Loading...'}
                  </span>
                )}
              </div>
              
              <div className="relative">
                <input
                  type="text"
                  value={amount}
                  onChange={handleAmountChange}
                  placeholder="0.0"
                  className="w-full bg-black border border-terminal-green p-2 text-terminal-green font-mono focus:outline-none focus:ring-1 focus:ring-terminal-green"
                />
                {walletAddress && (
                  <button
                    onClick={handleMaxAmount}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-terminal-amber font-mono text-xs"
                  >
                    MAX
                  </button>
                )}
              </div>
              
              <div className="flex justify-between mt-2">
                <button
                  onClick={() => setAmount('0.1')}
                  className="px-2 py-1 border border-terminal-darkGreen text-terminal-darkGreen text-xs font-mono hover:bg-terminal-darkGreen hover:text-black"
                >
                  0.1 SOL
                </button>
                <button
                  onClick={() => setAmount('0.5')}
                  className="px-2 py-1 border border-terminal-darkGreen text-terminal-darkGreen text-xs font-mono hover:bg-terminal-darkGreen hover:text-black"
                >
                  0.5 SOL
                </button>
                <button
                  onClick={() => setAmount('1')}
                  className="px-2 py-1 border border-terminal-darkGreen text-terminal-darkGreen text-xs font-mono hover:bg-terminal-darkGreen hover:text-black"
                >
                  1 SOL
                </button>
                <button
                  onClick={() => setAmount('2')}
                  className="px-2 py-1 border border-terminal-darkGreen text-terminal-darkGreen text-xs font-mono hover:bg-terminal-darkGreen hover:text-black"
                >
                  2 SOL
                </button>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between">
                <span className="text-sm text-terminal-darkGreen font-mono">
                  SLIPPAGE TOLERANCE
                </span>
                <div className="relative">
                  <button 
                    onClick={() => setShowSlippageOptions(!showSlippageOptions)}
                    className="text-xs font-mono text-terminal-green flex items-center"
                  >
                    {slippage}% <FiChevronDown className="ml-1" />
                  </button>
                  
                  {showSlippageOptions && (
                    <div className="absolute right-0 mt-1 bg-black border border-terminal-green z-10">
                      {[0.5, 1, 1.5, 2, 3, 5].map((value) => (
                        <div
                          key={value}
                          onClick={() => handleSlippageChange(value)}
                          className="px-3 py-1 hover:bg-terminal-green hover:text-black cursor-pointer text-xs font-mono"
                        >
                          {value}%
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-terminal-green opacity-50">
              <div className="flex justify-between mb-2">
                <span className="text-sm text-terminal-darkGreen font-mono">
                  ESTIMATED RECEIVE
                </span>
                <span className="text-sm text-terminal-green font-mono">
                  ≈ {calculateEstimate()} {coin.symbol}
                </span>
              </div>
              
              <div className="flex justify-between mb-4">
                <span className="text-sm text-terminal-darkGreen font-mono">
                  CURRENT PRICE
                </span>
                <span className="text-sm text-terminal-green font-mono">
                  0.05 SOL per {coin.symbol}
                </span>
              </div>
            </div>
            
            {!walletAddress ? (
              <button
                onClick={connectWallet}
                className="w-full py-3 bg-terminal-green text-black font-mono"
              >
                CONNECT WALLET TO TRADE
              </button>
            ) : (
              <button
                onClick={handleTrade}
                disabled={isLoading || !amount || parseFloat(amount) <= 0}
                className={`w-full py-3 font-mono ${
                  isLoading || !amount || parseFloat(amount) <= 0
                    ? 'bg-terminal-darkGreen text-black opacity-50 cursor-not-allowed'
                    : 'bg-terminal-green text-black hover:bg-terminal-amber'
                }`}
              >
                {isLoading ? 'PROCESSING...' : 'BUY'}
              </button>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="sell" className="mt-0">
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-sm text-terminal-darkGreen font-mono">
                  AMOUNT ({coin.symbol})
                </label>
                {walletAddress && (
                  <span className="text-xs text-terminal-darkGreen font-mono">
                    Balance: {calculateTokenBalance()} {coin.symbol}
                  </span>
                )}
              </div>
              
              <div className="relative">
                <input
                  type="text"
                  value={amount}
                  onChange={handleAmountChange}
                  placeholder="0.0"
                  className="w-full bg-black border border-terminal-green p-2 text-terminal-green font-mono focus:outline-none focus:ring-1 focus:ring-terminal-green"
                />
                {walletAddress && (
                  <button
                    onClick={handleMaxAmount}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-terminal-amber font-mono text-xs"
                  >
                    MAX
                  </button>
                )}
              </div>
              
              <div className="flex justify-between mt-2">
                <button
                  onClick={() => setAmount((calculateTokenBalance() * 0.25).toString())}
                  className="px-2 py-1 border border-terminal-darkGreen text-terminal-darkGreen text-xs font-mono hover:bg-terminal-darkGreen hover:text-black"
                >
                  25%
                </button>
                <button
                  onClick={() => setAmount((calculateTokenBalance() * 0.5).toString())}
                  className="px-2 py-1 border border-terminal-darkGreen text-terminal-darkGreen text-xs font-mono hover:bg-terminal-darkGreen hover:text-black"
                >
                  50%
                </button>
                <button
                  onClick={() => setAmount((calculateTokenBalance() * 0.75).toString())}
                  className="px-2 py-1 border border-terminal-darkGreen text-terminal-darkGreen text-xs font-mono hover:bg-terminal-darkGreen hover:text-black"
                >
                  75%
                </button>
                <button
                  onClick={() => setAmount(calculateTokenBalance().toString())}
                  className="px-2 py-1 border border-terminal-darkGreen text-terminal-darkGreen text-xs font-mono hover:bg-terminal-darkGreen hover:text-black"
                >
                  100%
                </button>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between">
                <span className="text-sm text-terminal-darkGreen font-mono">
                  SLIPPAGE TOLERANCE
                </span>
                <div className="relative">
                  <button 
                    onClick={() => setShowSlippageOptions(!showSlippageOptions)}
                    className="text-xs font-mono text-terminal-green flex items-center"
                  >
                    {slippage}% <FiChevronDown className="ml-1" />
                  </button>
                  
                  {showSlippageOptions && (
                    <div className="absolute right-0 mt-1 bg-black border border-terminal-green z-10">
                      {[0.5, 1, 1.5, 2, 3, 5].map((value) => (
                        <div
                          key={value}
                          onClick={() => handleSlippageChange(value)}
                          className="px-3 py-1 hover:bg-terminal-green hover:text-black cursor-pointer text-xs font-mono"
                        >
                          {value}%
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-terminal-green opacity-50">
              <div className="flex justify-between mb-2">
                <span className="text-sm text-terminal-darkGreen font-mono">
                  ESTIMATED RECEIVE
                </span>
                <span className="text-sm text-terminal-green font-mono">
                  ≈ {calculateEstimate()} SOL
                </span>
              </div>
              
              <div className="flex justify-between mb-4">
                <span className="text-sm text-terminal-darkGreen font-mono">
                  CURRENT PRICE
                </span>
                <span className="text-sm text-terminal-green font-mono">
                  0.05 SOL per {coin.symbol}
                </span>
              </div>
            </div>
            
            {!walletAddress ? (
              <button
                onClick={connectWallet}
                className="w-full py-3 bg-terminal-green text-black font-mono"
              >
                CONNECT WALLET TO TRADE
              </button>
            ) : (
              <button
                onClick={handleTrade}
                disabled={isLoading || !amount || parseFloat(amount) <= 0}
                className={`w-full py-3 font-mono ${
                  isLoading || !amount || parseFloat(amount) <= 0
                    ? 'bg-terminal-darkGreen text-black opacity-50 cursor-not-allowed'
                    : 'bg-terminal-green text-black hover:bg-terminal-amber'
                }`}
              >
                {isLoading ? 'PROCESSING...' : 'SELL'}
              </button>
            )}
          </div>
        </TabsContent>
      </Tabs>
      
      <div className="mt-6 pt-4 border-t border-terminal-green opacity-50">
        <div className="flex items-center justify-center text-xs text-terminal-darkGreen font-mono">
          <FiInfo className="mr-1" />
          <span>Trading via Mind9 autonomous liquidity protocol</span>
        </div>
      </div>
    </div>
  );
}