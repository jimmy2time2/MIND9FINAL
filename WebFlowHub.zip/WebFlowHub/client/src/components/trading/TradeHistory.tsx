import React, { useState, useEffect } from 'react';
import { Coin } from '@/lib/types';
import { FiClock, FiArrowUp, FiArrowDown } from 'react-icons/fi';

interface TradeHistoryProps {
  coin: Coin;
}

export function TradeHistory({ coin }: TradeHistoryProps) {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  
  // Format the timestamp into a relative time (e.g., "2 hours ago")
  function formatRelativeTime(timestamp: string): string {
    const now = new Date();
    const tradeTime = new Date(timestamp);
    const diffInSeconds = Math.floor((now.getTime() - tradeTime.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return `${diffInSeconds} sec ago`;
    } else if (diffInSeconds < 3600) {
      return `${Math.floor(diffInSeconds / 60)} min ago`;
    } else if (diffInSeconds < 86400) {
      return `${Math.floor(diffInSeconds / 3600)} hr ago`;
    } else {
      return `${Math.floor(diffInSeconds / 86400)} day ago`;
    }
  }
  
  return (
    <div className="w-full bg-black bg-opacity-80 border border-terminal-green p-4 rounded-sm">
      <h3 className="text-terminal-green font-mono text-lg mb-4">TRADE HISTORY</h3>
      
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="border-b border-terminal-green border-opacity-30">
            <tr className="text-terminal-darkGreen text-xs font-mono">
              <th className="py-2">TYPE</th>
              <th className="py-2">PRICE</th>
              <th className="py-2">AMOUNT</th>
              <th className="py-2">WALLET</th>
              <th className="py-2">TIME</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td colSpan={5} className="py-10 text-center">
                <div className="flex flex-col items-center justify-center space-y-3">
                  <div className="text-terminal-green font-mono">NO TRADES YET</div>
                  <div className="text-terminal-darkGreen text-sm">
                    This token hasn't been traded yet.
                  </div>
                  <div className="p-3 border border-terminal-darkGreen border-dashed text-terminal-green text-sm mt-4">
                    Be the first to trade {coin.symbol} tokens
                  </div>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}