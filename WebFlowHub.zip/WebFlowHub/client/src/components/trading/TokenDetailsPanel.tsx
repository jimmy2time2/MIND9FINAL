import React from 'react';
import { Coin } from '@/lib/types';
import { truncateWalletAddress } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';
import { FiCopy, FiExternalLink, FiInfo } from 'react-icons/fi';
import { useToast } from '@/hooks/use-toast';

interface TokenDetailsPanelProps {
  coin: Coin;
}

export function TokenDetailsPanel({ coin }: TokenDetailsPanelProps) {
  const { toast } = useToast();

  // Handle copy to clipboard for addresses
  const handleCopyAddress = (address: string) => {
    navigator.clipboard.writeText(address).then(
      () => {
        toast({
          title: 'Address Copied',
          description: 'Token address copied to clipboard',
        });
      },
      (err) => {
        console.error('Could not copy address: ', err);
      }
    );
  };

  // Get the migration progress
  const getRaydiumMigrationProgress = () => {
    // If the coin has a migration progress field, use it
    if (coin.raydium_migration_progress) {
      return parseInt(coin.raydium_migration_progress as string);
    }
    
    // Check if custom field exists for raydium progress
    if (coin.custom_fields && coin.custom_fields['raydium_migration_progress']) {
      return parseInt(coin.custom_fields['raydium_migration_progress']);
    }
    
    // Return 0 for new coins
    return 0;
  };

  return (
    <div className="w-full bg-black bg-opacity-80 border border-terminal-green p-4 rounded-sm">
      <div className="flex items-center mb-4">
        <div className="w-12 h-12 mr-3">
          {coin.image_path ? (
            <img 
              src={coin.image_path} 
              alt={`${coin.name} coin`} 
              className="w-full h-full object-contain"
            />
          ) : (
            <div 
              className="w-full h-12 h-full rounded-full" 
              style={{ 
                background: `radial-gradient(circle, ${coin.primary_color || '#FF7D45'}, ${coin.secondary_color || '#FFD1B8'})` 
              }}
            />
          )}
        </div>
        
        <div>
          <h2 className="text-terminal-green font-mono text-lg">${coin.symbol}</h2>
          <p className="text-terminal-darkGreen text-sm font-mono">{coin.name}</p>
        </div>
      </div>
      
      <div className="space-y-4">
        {/* Basic token information */}
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-terminal-darkGreen font-mono text-sm">TOTAL SUPPLY</span>
            <span className="text-terminal-green font-mono text-sm">{coin.total_supply || '1,000,000'}</span>
          </div>
          
          <div className="flex justify-between mb-1">
            <span className="text-terminal-darkGreen font-mono text-sm">INITIAL PRICE</span>
            <span className="text-terminal-green font-mono text-sm">0.05 SOL</span>
          </div>
          
          <div className="flex justify-between mb-1">
            <span className="text-terminal-darkGreen font-mono text-sm">CREATION DATE</span>
            <span className="text-terminal-green font-mono text-sm">Today</span>
          </div>
        </div>
        
        {/* Raydium migration progress */}
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-terminal-darkGreen font-mono text-sm">RAYDIUM MIGRATION</span>
            <span className="text-terminal-green font-mono text-sm">{getRaydiumMigrationProgress()}%</span>
          </div>
          <Progress value={getRaydiumMigrationProgress()} className="h-1 bg-terminal-darkGreen" indicatorClassName="bg-terminal-green" />
          <p className="text-xs text-terminal-darkGreen mt-1 font-mono">
            Auto-migrates to Raydium DEX at 100%
          </p>
        </div>
        
        {/* Contract information */}
        <div className="pt-2 border-t border-terminal-green border-opacity-30">
          <div className="flex items-start mb-2">
            <span className="text-terminal-darkGreen font-mono text-sm w-24 flex-shrink-0">CONTRACT</span>
            <div className="flex-grow flex items-center">
              <span className="text-terminal-green font-mono text-sm mr-2 truncate">
                {coin.mint_address ? truncateWalletAddress(coin.mint_address) : 'Pending mint...'}
              </span>
              
              {coin.mint_address && (
                <div className="flex items-center">
                  <button 
                    onClick={() => handleCopyAddress(coin.mint_address)}
                    className="text-terminal-amber mr-2"
                  >
                    <FiCopy size={14} />
                  </button>
                  
                  <a 
                    href={`https://explorer.solana.com/address/${coin.mint_address}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-terminal-amber"
                  >
                    <FiExternalLink size={14} />
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Tokenomics information */}
        <div className="pt-2 border-t border-terminal-green border-opacity-30">
          <h3 className="text-terminal-green font-mono text-sm mb-2">TOKENOMICS</h3>
          
          <div className="space-y-1 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-terminal-darkGreen">Locked Liquidity</span>
              <span className="text-terminal-green">70%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-terminal-darkGreen">Trading Fund</span>
              <span className="text-terminal-green">20%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-terminal-darkGreen">Creator Wallet</span>
              <span className="text-terminal-green">5%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-terminal-darkGreen">Lucky Trader</span>
              <span className="text-terminal-green">3%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-terminal-darkGreen">Operations</span>
              <span className="text-terminal-green">2%</span>
            </div>
          </div>
        </div>
        
        {/* Token holders - placeholder for new token */}
        <div className="pt-2 border-t border-terminal-green border-opacity-30">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-terminal-green font-mono text-sm">TOKEN HOLDERS</h3>
          </div>
          
          <div className="bg-terminal-darkGreen bg-opacity-20 p-4 text-center">
            <p className="text-terminal-green text-sm">No holders yet</p>
            <p className="text-terminal-darkGreen text-xs mt-2">
              Be the first to hold {coin.symbol} tokens
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}