import React, { useState } from 'react';
import { Coin } from '@/lib/types';

interface TradingChartProps {
  coin: Coin;
  darkMode?: boolean;
  height?: number;
}

export function TradingChart({ coin, darkMode = true, height = 400 }: TradingChartProps) {
  const [timeframe, setTimeframe] = useState<string>('1h');

  const handleTimeframeChange = (newTimeframe: string) => {
    setTimeframe(newTimeframe);
  };

  return (
    <div className="w-full bg-black bg-opacity-80 border border-terminal-green p-4 rounded-sm">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center">
          <h3 className="text-terminal-green font-mono text-lg">${coin.symbol} PRICE CHART</h3>
        </div>
        
        <div className="flex space-x-2">
          {['1m', '5m', '15m', '1h', '4h', '1d'].map((tf) => (
            <button
              key={tf}
              onClick={() => handleTimeframeChange(tf)}
              className={`px-2 py-1 text-xs rounded ${
                timeframe === tf
                  ? 'bg-terminal-green text-black'
                  : 'bg-transparent text-terminal-green border border-terminal-green'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>
      
      <div className="flex flex-col justify-center items-center" style={{ height: `${height}px` }}>
        <div className="mb-4 text-terminal-green text-center">
          <div className="text-lg mb-2">NO TRADING DATA AVAILABLE</div>
          <div className="text-sm">
            This token was recently created and has no trading history yet.
          </div>
          <div className="text-sm mt-4">
            Be the first to trade {coin.symbol} using the trading panel.
          </div>
        </div>
        
        <div className="bg-terminal-darkGreen bg-opacity-20 p-6 mt-4 border border-terminal-darkGreen border-dashed">
          <div className="flex items-center text-terminal-green">
            <span className="mr-2">●</span>
            <span>PRICE DATA WILL APPEAR HERE AFTER FIRST TRADE</span>
            <span className="ml-2 animate-blink">█</span>
          </div>
        </div>
      </div>
      
      <div className="text-xs text-terminal-darkGreen mt-4 font-mono text-center">
        {coin.symbol} is ready to be traded on the Mind9 platform
      </div>
    </div>
  );
}