import React, { useState, useEffect } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import TradePanel from "@/components/TradePanel";
import PriceChart from "@/components/PriceChart";
import { apiRequest } from '@/lib/queryClient';
import { truncateWalletAddress } from '@/lib/utils';
import { Coins, Brain, Zap, ArrowUpDown, LineChart } from 'lucide-react';
import type { Coin } from '@/lib/types';

interface CoinDetailsProps {
  coinId: number;
  onBackClick?: () => void;
}

export default function CoinDetails({ coinId, onBackClick }: CoinDetailsProps) {
  const [coin, setCoin] = useState<Coin | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();
  const [parsedTokenomics, setParsedTokenomics] = useState<any | null>(null);

  useEffect(() => {
    const fetchCoin = async () => {
      setLoading(true);
      try {
        const response = await apiRequest(`/api/coin/${coinId}`);
        if (!response.ok) {
          throw new Error('Failed to fetch coin details');
        }
        const data = await response.json();
        setCoin(data);
        
        // Process tokenomics from string
        if (data.tokenomics) {
          // Extract percentages from the string format like "70% Locked LP, 20% Trading Fund, 5% Creator Wallet, 3% Lucky Trader, 2% System Operations"
          const tokenomicsObj = {
            liquidityPool: 70,
            tradingFund: 20,
            creatorWallet: 5,
            luckyTrader: 3,
            systemOperations: 2,
            aiGenerationConfidence: 0.85
          };
          
          // Try to parse values from the string if possible, but use defaults if parsing fails
          try {
            const parts = data.tokenomics.split(',').map(part => part.trim());
            parts.forEach(part => {
              if (part.includes('Locked LP') || part.includes('Liquidity')) {
                const match = part.match(/(\d+)%/);
                if (match) tokenomicsObj.liquidityPool = parseInt(match[1]);
              } else if (part.includes('Trading Fund')) {
                const match = part.match(/(\d+)%/);
                if (match) tokenomicsObj.tradingFund = parseInt(match[1]);
              } else if (part.includes('Creator')) {
                const match = part.match(/(\d+)%/);
                if (match) tokenomicsObj.creatorWallet = parseInt(match[1]);
              } else if (part.includes('Lucky Trader')) {
                const match = part.match(/(\d+)%/);
                if (match) tokenomicsObj.luckyTrader = parseInt(match[1]);
              } else if (part.includes('Operations') || part.includes('System')) {
                const match = part.match(/(\d+)%/);
                if (match) tokenomicsObj.systemOperations = parseInt(match[1]);
              }
            });
          } catch (e) {
            console.log('Using default tokenomics values');
          }
          
          setParsedTokenomics(tokenomicsObj);
        }
      } catch (err: any) {
        setError(err.message || 'An error occurred');
        toast({
          title: "Error",
          description: "Failed to load coin details",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    if (coinId) {
      fetchCoin();
    }
  }, [coinId, toast]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading coin details...</p>
        </div>
      </div>
    );
  }

  if (error || !coin) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <p className="text-red-500 mb-4">Failed to load coin data: {error}</p>
        <Button onClick={onBackClick}>Go Back</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Button variant="ghost" onClick={onBackClick} className="mr-2">
            ←
          </Button>
          <h2 className="text-2xl font-bold">{coin.name}</h2>
          <Badge variant="outline" className="ml-2">{coin.symbol}</Badge>
        </div>
        <Badge variant="secondary" className="font-mono text-xs">
          {truncateWalletAddress(coin.mint_address)}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <LineChart className="mr-2 h-5 w-5" />
                Price Chart
              </CardTitle>
            </CardHeader>
            <CardContent>
              <PriceChart mintAddress={coin.mint_address} symbol={coin.symbol} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="mr-2 h-5 w-5" />
                AI-Generated Description
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground whitespace-pre-line">{coin.description}</p>
            </CardContent>
          </Card>

          <Tabs defaultValue="tokenomics">
            <TabsList>
              <TabsTrigger value="tokenomics">Tokenomics</TabsTrigger>
              <TabsTrigger value="distribution">Distribution</TabsTrigger>
              <TabsTrigger value="details">Technical Details</TabsTrigger>
            </TabsList>
            
            <TabsContent value="tokenomics" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Coins className="mr-2 h-5 w-5" />
                    Token Economics
                  </CardTitle>
                  <CardDescription>
                    Autonomous AI-generated token model for optimal market performance
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {parsedTokenomics ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="border rounded-lg p-4">
                          <div className="text-sm text-muted-foreground mb-1">Total Supply</div>
                          <div className="font-bold">{coin.total_supply}</div>
                        </div>
                        <div className="border rounded-lg p-4">
                          <div className="text-sm text-muted-foreground mb-1">Liquidity Pool</div>
                          <div className="font-bold">{parsedTokenomics.liquidityPool}%</div>
                        </div>
                        <div className="border rounded-lg p-4">
                          <div className="text-sm text-muted-foreground mb-1">Trading Fund</div>
                          <div className="font-bold">{parsedTokenomics.tradingFund}%</div>
                        </div>
                        <div className="border rounded-lg p-4">
                          <div className="text-sm text-muted-foreground mb-1">Lucky Trader</div>
                          <div className="font-bold">{parsedTokenomics.luckyTrader}%</div>
                        </div>
                        <div className="border rounded-lg p-4">
                          <div className="text-sm text-muted-foreground mb-1">Creator Wallet</div>
                          <div className="font-bold">{parsedTokenomics.creatorWallet}%</div>
                        </div>
                        <div className="border rounded-lg p-4">
                          <div className="text-sm text-muted-foreground mb-1">System Operations</div>
                          <div className="font-bold">{parsedTokenomics.systemOperations}%</div>
                        </div>
                      </div>
                      {/* Show the original tokenomics string as well */}
                      <div className="mt-4 p-4 border rounded-lg bg-black/10">
                        <div className="text-sm text-muted-foreground mb-1">Original Tokenomics</div>
                        <div className="text-xs font-mono">{coin.tokenomics}</div>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <p className="text-muted-foreground mb-4">Using default tokenomics distribution:</p>
                      <div className="p-4 border rounded-lg bg-black/10">
                        <div className="text-xs font-mono">{coin.tokenomics || "70% Locked LP, 20% Trading Fund, 5% Creator Wallet, 3% Lucky Trader, 2% System Operations"}</div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="distribution" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <ArrowUpDown className="mr-2 h-5 w-5" />
                    Token Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border rounded-lg p-4">
                      <div className="text-sm text-muted-foreground mb-1">Initial Liquidity</div>
                      <div className="font-bold">{coin.liquidity_amount} {coin.symbol}</div>
                    </div>
                    <div className="border rounded-lg p-4">
                      <div className="text-sm text-muted-foreground mb-1">SOL Pool Size</div>
                      <div className="font-bold">{coin.liquidity_sol} SOL</div>
                    </div>
                    <div className="border rounded-lg p-4">
                      <div className="text-sm text-muted-foreground mb-1">Lucky Trader Wallet</div>
                      <div className="font-bold font-mono text-xs">{truncateWalletAddress(coin.lucky_trader_wallet)}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="details" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Zap className="mr-2 h-5 w-5" />
                    Technical Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border rounded-lg p-4">
                      <div className="text-sm text-muted-foreground mb-1">Created At</div>
                      <div className="font-bold">{new Date(coin.timestamp).toLocaleString()}</div>
                    </div>
                    <div className="border rounded-lg p-4">
                      <div className="text-sm text-muted-foreground mb-1">Token Address</div>
                      <div className="font-bold font-mono text-xs break-all">{coin.mint_address}</div>
                    </div>
                    <div className="border rounded-lg p-4">
                      <div className="text-sm text-muted-foreground mb-1">Explorer Link</div>
                      <a 
                        href={`https://solscan.io/token/${coin.mint_address}`} 
                        target="_blank" 
                        rel="noreferrer" 
                        className="text-primary hover:underline"
                      >
                        View on Solscan
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="space-y-6">
          <TradePanel coin={coin} />
          
          <Card className="border-2 border-primary/10 dark:bg-black/40 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-lg">Raydium DEX Migration</CardTitle>
              <CardDescription>
                This token automatically migrates to Raydium DEX when market cap reaches $100K
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Once token market cap reaches $100K, Mind9 will automatically migrate liquidity to 
                Raydium DEX for broader market access.
              </p>
              {coin.raydium_migrated ? (
                <Button 
                  className="w-full" 
                  variant="outline"
                  onClick={() => window.open(`https://raydium.io/swap/?inputCurrency=sol&outputCurrency=${coin.mint_address}`, '_blank')}
                >
                  View on Raydium
                </Button>
              ) : (
                <div className="p-3 border rounded-md bg-muted/20 text-sm">
                  <div className="font-medium mb-1">Migration Progress:</div>
                  <div className="flex items-center mt-2">
                    <div className="w-full bg-muted rounded-full h-2 mr-2">
                      <div 
                        className="bg-primary h-2 rounded-full" 
                        style={{ width: `${coin.liquidity_progress || 0}%` }}
                      ></div>
                    </div>
                    <span className="text-xs">{coin.liquidity_progress || 0}%</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    {coin.estimated_time_to_migration || "Migration occurs when market cap reaches $100,000"}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}