import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export function AdminControls() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const queryClient = useQueryClient();
  
  const handleCreateToken = async () => {
    setIsLoading(true);
    setError(null);
    setResult(null);
    
    try {
      const response = await apiRequest('/api/admin/create-token', {
        method: 'POST',
      });
      
      setResult(response);
      // Invalidate queries to refresh coin data
      queryClient.invalidateQueries({ queryKey: ['/api/coins'] });
      
    } catch (err: any) {
      console.error('Error creating token:', err);
      setError(err.message || 'Failed to create token');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleTestTwitter = async () => {
    setIsLoading(true);
    setError(null);
    setResult(null);
    
    try {
      const response = await apiRequest('/api/admin/test-twitter', {
        method: 'POST',
        body: JSON.stringify({
          message: `Test tweet from Mind9 at ${new Date().toLocaleTimeString()}`,
          bypass_rate_limit: true
        }),
      });
      
      setResult(response);
      
    } catch (err: any) {
      console.error('Error posting test tweet:', err);
      setError(err.message || 'Failed to post test tweet');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="border-2 border-terminal-green bg-black bg-opacity-90 p-4 mb-6">
      <h2 className="text-terminal-green text-xl font-mono mb-4">Admin Controls</h2>
      
      <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-4 mb-4">
        <button
          onClick={handleCreateToken}
          disabled={isLoading}
          className="bg-terminal-green text-black px-4 py-2 font-mono hover:bg-terminal-amber disabled:opacity-50"
        >
          Create New Token
        </button>
        
        <button
          onClick={handleTestTwitter}
          disabled={isLoading}
          className="bg-terminal-darkGreen text-white px-4 py-2 font-mono hover:bg-terminal-amber disabled:opacity-50"
        >
          Test Twitter API
        </button>
      </div>
      
      {isLoading && (
        <div className="text-terminal-amber font-mono animate-pulse">
          Processing request...
        </div>
      )}
      
      {error && (
        <div className="border-2 border-red-500 p-3 mt-4 text-red-500 font-mono">
          <strong>Error:</strong> {error}
        </div>
      )}
      
      {result && (
        <div className="border-2 border-terminal-green p-3 mt-4">
          <h3 className="text-terminal-green font-mono mb-2">Response:</h3>
          <pre className="text-terminal-amber font-mono text-sm overflow-auto max-h-40 whitespace-pre-wrap">
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}