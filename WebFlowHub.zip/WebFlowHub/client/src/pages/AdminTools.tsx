import React from 'react';
import { TestTokenCreator } from '@/components/TestTokenCreator';

export default function AdminTools() {
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-2">Admin Tools</h1>
      <p className="text-muted-foreground mb-8">
        These tools are designed for development and testing purposes.
      </p>
      
      <div className="grid gap-8">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Token Testing</h2>
          <div className="grid gap-6">
            <TestTokenCreator />
            
            <div className="bg-muted p-4 rounded-lg">
              <h3 className="font-semibold mb-2">How to verify your token</h3>
              <p className="mb-2">Use the Node.js script to verify your token on the blockchain:</p>
              <pre className="bg-card p-3 rounded text-sm overflow-x-auto">
                node verify_token.js YOUR_MINT_ADDRESS
              </pre>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}