import React, { useState } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Coin } from '@shared/schema';
import { FiArrowLeft, FiTwitter, FiCopy, FiCheck, FiShoppingCart, FiDownload, FiBarChart2 } from 'react-icons/fi';
import { useWallet } from '@/lib/solana';
import { useToast } from '@/hooks/use-toast';
import { TradingChart } from '@/components/trading/TradingChart';
import { TradingPanel } from '@/components/trading/TradingPanel';
import { TokenDetailsPanel } from '@/components/trading/TokenDetailsPanel';
import { TradeHistory } from '@/components/trading/TradeHistory';

export function CoinPage() {
  const { id } = useParams();
  const { walletAddress } = useWallet();
  const { toast } = useToast();
  
  // All state values in one place to maintain hook order
  const [copied, setCopied] = useState(false);
  const [mintStatus, setMintStatus] = useState<'idle' | 'minting' | 'success' | 'error'>('idle');
  const [showPreview, setShowPreview] = useState(false);
  const [previewAmount, setPreviewAmount] = useState(1000); // Default amount
  const [mintAmount, setMintAmount] = useState(1000);
  const [isValidAmount, setIsValidAmount] = useState(true);
  const [actionType, setActionType] = useState<'mint' | 'buy'>('mint');
  const [buyStatus, setBuyStatus] = useState<'idle' | 'buying' | 'success' | 'error'>('idle');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<any>(null);
  
  // Fetch coin data with proper error handling
  const { data: coin, isLoading, error } = useQuery<Coin>({
    queryKey: [`/api/coin/${id}`],
    retry: 2,
    staleTime: 30000,
  });
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black text-terminal-green">
        <p className="font-mono text-xl animate-pulse">ACCESSING PROTOCOL...</p>
      </div>
    );
  }
  
  if (error || !coin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black text-terminal-green">
        <p className="font-mono text-xl mb-4">ACCESS DENIED</p>
        <Link to="/" className="font-mono text-terminal-amber hover:underline">
          &lt; RETURN TO MAIN PROTOCOL
        </Link>
      </div>
    );
  }
  
  // Format date
  const formattedDate = new Date(coin.timestamp).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
  
  // Handle copying mint address to clipboard
  const handleCopyAddress = () => {
    navigator.clipboard.writeText(coin.mint_address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  // Handle minting coin with transaction preview for security
  const handleMint = async () => {
    if (!coin.user_mintable || mintStatus === 'minting') return;
    
    try {
      // Check if wallet is connected
      if (!walletAddress) {
        toast({
          title: "Wallet Not Connected",
          description: "Please connect your Phantom wallet first to receive tokens",
          variant: "destructive",
        });
        setMintStatus('error');
        return;
      }
      
      // Validate amount before proceeding
      if (!isValidAmount) {
        toast({
          title: "Invalid Amount",
          description: "Please enter a valid amount between 100 and 10,000 tokens",
          variant: "destructive",
        });
        setMintStatus('error');
        return;
      }
      
      // Show transaction preview first for security
      if (!showPreview) {
        setActionType('mint');
        setShowPreview(true);
        return;
      }
      
      // User has confirmed after preview
      setShowPreview(false);
      setMintStatus('minting');
      
      console.log(`Minting ${mintAmount} ${coin.symbol} tokens to wallet ${walletAddress.substring(0, 4)}...${walletAddress.substring(walletAddress.length - 4)}`);
      
      // Call mint API with wallet address and amount
      const response = await apiRequest(`/api/coins/mint/${coin.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          wallet_address: walletAddress,
          amount: mintAmount
        })
      });
      
      // Parse the response
      const result = await response.json();
      
      // Check if the response indicates an error
      if (!result.success) {
        throw new Error(result.message || "Failed to mint tokens");
      }
      
      // Create transaction info for logs with partial address for privacy
      const txInfo = {
        coin: coin.symbol,
        mintAddress: `${coin.mint_address.substring(0, 4)}...${coin.mint_address.substring(coin.mint_address.length - 4)}`,
        walletAddress: `${walletAddress.substring(0, 4)}...${walletAddress.substring(walletAddress.length - 4)}`,
        amount: mintAmount,
        txId: result.transaction?.signature || 'completed',
        timestamp: new Date().toISOString()
      };
      
      // Log transaction for user reference
      console.log('Transaction completed:', txInfo);
      
      // Display success toast with transaction details
      toast({
        title: "Tokens Minted Successfully!",
        description: `Successfully minted ${mintAmount} ${coin.symbol} tokens. Check your Phantom wallet.`,
        variant: "default",
      });
      
      // Refresh coin data after successful mint
      queryClient.invalidateQueries({ queryKey: [`/api/coin/${coin.id}`] });
      
      setMintStatus('success');
    } catch (error) {
      console.error("Error minting coin:", error);
      setShowPreview(false);
      
      // Display error toast with details
      toast({
        title: "Minting Failed",
        description: error instanceof Error ? error.message : "Failed to mint tokens. Please try again.",
        variant: "destructive",
      });
      
      setMintStatus('error');
    }
  };
  
  // Handle buying tokens directly
  const handleBuyTokens = async () => {
    if (!coin.user_mintable || buyStatus === 'buying') return;
    
    try {
      // Check if wallet is connected
      if (!walletAddress) {
        toast({
          title: "Wallet Not Connected",
          description: "Please connect your Phantom wallet first to receive tokens",
          variant: "destructive",
        });
        setBuyStatus('error');
        return;
      }
      
      // Show transaction preview first for security
      if (!showPreview) {
        setActionType('buy');
        setShowPreview(true);
        return;
      }
      
      // User has confirmed after preview
      setShowPreview(false);
      setBuyStatus('buying');
      
      // Call buy API with wallet address and amount
      const response = await apiRequest(`/api/coins/buy/${coin.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          wallet_address: walletAddress,
          amount: mintAmount
        })
      });
      
      // Create transaction info for logs with partial address for privacy
      const txInfo = {
        coin: coin.symbol,
        mintAddress: `${coin.mint_address.substring(0, 4)}...${coin.mint_address.substring(coin.mint_address.length - 4)}`,
        walletAddress: `${walletAddress.substring(0, 4)}...${walletAddress.substring(walletAddress.length - 4)}`,
        amount: mintAmount,
        txId: 'completed',
        timestamp: new Date().toISOString()
      };
      
      // Log transaction for user reference
      console.log('Purchase completed:', txInfo);
      
      // Display success toast with transaction details
      toast({
        title: "Tokens Purchased Successfully!",
        description: `Successfully purchased ${mintAmount} ${coin.symbol} tokens. Check your Phantom wallet.`,
        variant: "default",
      });
      
      setBuyStatus('success');
    } catch (error) {
      console.error("Error buying tokens:", error);
      setShowPreview(false);
      
      // Display error toast with details
      toast({
        title: "Purchase Failed",
        description: error instanceof Error ? error.message : "Failed to purchase tokens. Please try again.",
        variant: "destructive",
      });
      
      setBuyStatus('error');
    }
  };
  
  // Cancel transaction preview
  const handleCancelMint = () => {
    setShowPreview(false);
    setActionType('mint');
  };
  
  // Handle sharing on Twitter
  const handleTwitterShare = () => {
    const text = `I just discovered ${coin.name} (${coin.symbol}) - Created by Mind9, the autonomous AI protocol. Check it out: `;
    const url = window.location.href;
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
  };
  
  // Handle verification of the coin on Solana blockchain
  const handleVerifyCoin = async () => {
    if (isVerifying) return;
    
    setIsVerifying(true);
    setVerificationResult(null);
    
    try {
      // Make a request to verify the token on the blockchain
      const response = await apiRequest(`/api/coins/verify/${coin.id}`, {
        method: 'POST'
      });
      
      const result = await response.json();
      
      if (result.success) {
        setVerificationResult(result);
        toast({
          title: "Verification Successful",
          description: `${coin.symbol} token verified on Solana blockchain`,
          variant: "default"
        });
        
        // Refresh coin data after verification
        queryClient.invalidateQueries({ queryKey: [`/api/coin/${id}`] });
      } else {
        throw new Error(result.message || "Verification failed");
      }
    } catch (error) {
      console.error("Error verifying coin:", error);
      toast({
        title: "Verification Failed",
        description: error instanceof Error ? error.message : "Failed to verify token on blockchain",
        variant: "destructive"
      });
    } finally {
      setIsVerifying(false);
    }
  };
  

  
  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <div className="border-b-2 border-terminal-green p-4 flex justify-between items-center">
        <Link to="/" className="text-terminal-green hover:text-terminal-amber flex items-center font-mono">
          <FiArrowLeft className="mr-2" />
          BACK TO PROTOCOL
        </Link>
        <div className="text-terminal-green font-mono">MIND9 COIN INTERFACE</div>
      </div>
      
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="bg-black border-2 border-terminal-green p-6 mb-8">
          {/* Coin details header */}
          <div className="flex flex-col md:flex-row items-center mb-8">
            {/* Coin image */}
            <div className="w-32 h-32 mb-4 md:mb-0 md:mr-8 relative">
              {coin.image_path ? (
                <img 
                  src={coin.image_path} 
                  alt={`${coin.name} coin`} 
                  className="w-full h-full object-contain rounded-full"
                  onError={(e) => {
                    console.error(`Failed to load image: ${coin.image_path}`);
                    // Fallback to gradient on image load error
                    e.currentTarget.style.display = 'none';
                  }}
                />
              ) : (
                <div 
                  className="w-full h-full rounded-full" 
                  style={{ 
                    background: `radial-gradient(circle, ${coin.primary_color || '#FF7D45'}, ${coin.secondary_color || '#FFD1B8'})` 
                  }}
                />
              )}
            </div>
            
            {/* Coin title info */}
            <div className="text-center md:text-left">
              <h1 className="text-terminal-green text-3xl font-mono">${coin.symbol}</h1>
              <h2 className="text-xl mt-1">{coin.name}</h2>
              <p className="text-terminal-darkGreen text-sm mt-1">Created by Mind9</p>
              <p className="text-terminal-amber mt-3 font-mono">{coin.tagline || ''}</p>
            </div>
          </div>
          
          {/* Mint information */}
          <div className="border-2 border-terminal-darkGreen bg-black bg-opacity-80 p-4 mb-6">
            <h3 className="text-terminal-green font-mono mb-3 text-lg">MINT INFORMATION</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-terminal-darkGreen text-sm mb-1">MINT ADDRESS:</p>
                <div className="flex items-center">
                  <code className="bg-black text-terminal-green p-2 font-mono text-sm flex-grow">
                    {coin.mint_address.substring(0, 10)}...{coin.mint_address.substring(coin.mint_address.length - 10)}
                  </code>
                  <button 
                    onClick={handleCopyAddress}
                    className="ml-2 p-2 border border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black"
                  >
                    {copied ? <FiCheck /> : <FiCopy />}
                  </button>
                </div>
              </div>
              
              <div>
                <p className="text-terminal-darkGreen text-sm mb-1">TOTAL SUPPLY:</p>
                <p className="bg-black text-terminal-green p-2 font-mono text-sm">{coin.total_supply}</p>
              </div>
              
              <div>
                <p className="text-terminal-darkGreen text-sm mb-1">CREATED ON:</p>
                <p className="bg-black text-terminal-green p-2 font-mono text-sm">{formattedDate}</p>
              </div>
              
              <div>
                <p className="text-terminal-darkGreen text-sm mb-1">CURRENT STATUS:</p>
                <p className="bg-black text-terminal-green p-2 font-mono text-sm">
                  {coin.raydium_migrated ? "Migrated to Raydium DEX" : 
                    (coin.user_mintable ? "Available for minting" : 
                      (coin.minted ? "Minted but locked" : "Created"))}
                </p>
              </div>
            </div>
          </div>
          
          {/* Token description */}
          <div className="mb-6">
            <h3 className="text-terminal-green font-mono mb-3 text-lg">ABOUT THIS TOKEN</h3>
            <p className="text-white">{coin.description}</p>
          </div>
          
          {/* Tokenomics */}
          {coin.tokenomics && (
            <div className="mb-6">
              <h3 className="text-terminal-green font-mono mb-3 text-lg">TOKENOMICS</h3>
              <div className="border-2 border-terminal-darkGreen p-4 bg-black bg-opacity-80">
                {coin.tokenomics.split(',').map((item, index) => (
                  <div key={index} className="mb-2 flex items-center">
                    <div className="w-2 h-2 bg-terminal-green mr-2"></div>
                    <span>{item.trim()}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Actions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <button 
              className="p-3 border-2 border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black flex items-center justify-center"
              onClick={handleTwitterShare}
            >
              <FiTwitter className="mr-2" />
              Share on Twitter
            </button>
            
            <button 
              className="p-3 border-2 border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black flex items-center justify-center"
              onClick={handleVerifyCoin}
              disabled={isVerifying}
            >
              {isVerifying ? (
                <div className="flex items-center">
                  <div className="animate-spin mr-2 h-4 w-4 border-2 border-white rounded-full border-t-transparent"></div>
                  Verifying...
                </div>
              ) : (
                <>
                  <FiCheck className="mr-2" />
                  Verify on Blockchain
                </>
              )}
            </button>
            
            {!coin.raydium_migrated && coin.user_mintable ? (
              // If tokens are mintable, show the mint button that also links to trading
              <button 
                className={`p-3 border-2 ${mintStatus === 'minting' 
                  ? 'border-terminal-amber text-terminal-amber' 
                  : 'border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black'
                } flex items-center justify-center`}
                onClick={() => {
                  handleMint();
                  // After successful minting, redirect to trading page
                  if (mintStatus !== 'minting') {
                    window.location.href = `/trading/coin/${id}`;
                  }
                }}
                disabled={mintStatus === 'minting'}
              >
                {mintStatus === 'minting' ? (
                  <div className="flex items-center">
                    <div className="animate-spin mr-2 h-4 w-4 border-2 border-terminal-amber rounded-full border-t-transparent"></div>
                    Minting...
                  </div>
                ) : (
                  <>
                    <FiDownload className="mr-2" />
                    Mint & Trade Tokens
                  </>
                )}
              </button>
            ) : coin.minted && (
              // If already minted but not mintable by users, show only trading link
              <Link
                to={`/trading/coin/${id}`}
                className="p-3 border-2 border-terminal-amber text-terminal-amber hover:bg-terminal-amber hover:text-black flex items-center justify-center"
              >
                <FiBarChart2 className="mr-2" />
                Advanced Trading
              </Link>
            )}
          </div>
          
          {showPreview && (
            <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center p-4 z-50">
              <div className="max-w-md w-full bg-black border-2 border-terminal-green p-6">
                <h3 className="text-terminal-green font-mono text-xl mb-4">Transaction Preview</h3>
                
                <div className="mb-4">
                  <p className="text-terminal-darkGreen text-sm mb-1">OPERATION:</p>
                  <p className="bg-black text-terminal-green p-2 font-mono">
                    {actionType === 'mint' ? 'Mint New Tokens' : 'Buy Tokens'}
                  </p>
                </div>
                
                <div className="mb-4">
                  <p className="text-terminal-darkGreen text-sm mb-1">TOKEN:</p>
                  <p className="bg-black text-terminal-green p-2 font-mono">{coin.symbol} ({coin.name})</p>
                </div>
                
                <div className="mb-4">
                  <p className="text-terminal-darkGreen text-sm mb-1">AMOUNT:</p>
                  <div className="flex items-center">
                    <input
                      type="number"
                      className="bg-black text-terminal-green p-2 font-mono border border-terminal-darkGreen w-full"
                      value={mintAmount}
                      onChange={(e) => {
                        const value = parseInt(e.target.value);
                        setMintAmount(value);
                        setIsValidAmount(value >= 100 && value <= 10000);
                      }}
                      min={100}
                      max={10000}
                    />
                    <span className="ml-2">{coin.symbol}</span>
                  </div>
                  {!isValidAmount && (
                    <p className="text-red-500 text-xs mt-1">Amount must be between 100 and 10,000</p>
                  )}
                </div>
                
                <div className="mb-6">
                  <p className="text-terminal-darkGreen text-sm mb-1">DESTINATION WALLET:</p>
                  <p className="bg-black text-terminal-green p-2 font-mono overflow-hidden text-ellipsis">
                    {walletAddress || 'No wallet connected'}
                  </p>
                </div>
                
                <div className="flex space-x-3">
                  <button 
                    className="flex-1 p-2 border border-terminal-darkGreen text-terminal-darkGreen hover:text-white"
                    onClick={handleCancelMint}
                  >
                    Cancel
                  </button>
                  <button 
                    className="flex-1 p-2 border border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black"
                    onClick={actionType === 'mint' ? handleMint : handleBuyTokens}
                    disabled={!isValidAmount}
                  >
                    Confirm
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}