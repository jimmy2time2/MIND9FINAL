import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import Header from "@/components/Header";
import SystemStatus from "@/components/SystemStatus";
import LiveTerminal from "@/components/LiveTerminal";
import ActiveCoins from "@/components/ActiveCoins";
import CoinDetails from "@/components/CoinDetails";
import Footer from "@/components/Footer";
import { CoinCard } from "@/components/CoinCard";
import { CoinsGrid } from "@/components/CoinsGrid";
import { IntroOverlay } from "@/components/IntroOverlay";
import { AdminControls } from "@/components/AdminControls";
import { AutonomousSystem } from "@/components/AutonomousSystem";
import { useQuery } from "@tanstack/react-query";
import type { LuckyTraderPool, Coin } from "@/lib/types";

export default function Home() {
  const [selectedCoinId, setSelectedCoinId] = useState<number | null>(null);
  const [showIntro, setShowIntro] = useState(() => {
    try {
      // Check if the user has seen the intro before
      if (typeof window !== 'undefined' && window.localStorage) {
        const hasSeenIntro = window.localStorage.getItem('mind9_intro_seen');
        // Check for URL query param to skip intro (?skip_intro=true)
        const urlParams = new URLSearchParams(window.location.search);
        const skipIntro = urlParams.get('skip_intro') === 'true';
        
        if (skipIntro) {
          // Save preference for future visits
          window.localStorage.setItem('mind9_intro_seen', 'true');
          return false;
        }
        
        return hasSeenIntro !== 'true'; // Show intro if they haven't seen it
      }
      return false; // Don't show intro if localStorage is not available
    } catch (e) {
      console.log("Error with intro screen, skipping", e);
      return false; // Skip intro if there's any error
    }
  });

  // Fetch all coins on page load
  const { data: coinsData, refetch: refetchCoins } = useQuery({
    queryKey: ['/api/coins'],
  });
  
  // Type-safe version of coins data
  const coins: Coin[] = Array.isArray(coinsData) ? coinsData : [];

  // Fetch lucky trader pool info
  const { data: luckyTraderData } = useQuery({
    queryKey: ['/api/lucky-trader/pool'],
  });
  
  // Type-safe version of lucky trader pool
  const luckyTraderPool: LuckyTraderPool = luckyTraderData && 
    typeof luckyTraderData === 'object' && 
    'total' in luckyTraderData && 
    'traders' in luckyTraderData ? 
    {
      total: typeof luckyTraderData.total === 'number' ? luckyTraderData.total : 0,
      traders: Array.isArray(luckyTraderData.traders) ? luckyTraderData.traders : []
    } : { total: 0, traders: [] };

  // Handle coin selection for detailed view
  const handleCoinSelect = (coinId: number) => {
    setSelectedCoinId(coinId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle back button click in coin details
  const handleBackClick = () => {
    setSelectedCoinId(null);
  };

  // Handle intro complete
  const handleIntroComplete = () => {
    try {
      // Save that user has seen the intro to localStorage
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem('mind9_intro_seen', 'true');
      }
    } catch (e) {
      console.log("Error saving intro seen preference", e);
    }
    setShowIntro(false);
  };

  return (
    <>
      {showIntro && <IntroOverlay onComplete={handleIntroComplete} />}
      
      <div className="container mx-auto px-4 py-8">
        <Header />
        
        {/* HOW IT WORKS Section - Positioned immediately after the header */}
        <div className="mt-4 mb-6 border border-terminal-darkGreen p-4 bg-black/80">
          <h2 className="text-2xl font-bold mb-4 text-terminal-amber">HOW IT WORKS</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div className="p-4 border border-terminal-darkGreen bg-black/50">
              <h3 className="font-bold mb-2 text-terminal-amber uppercase">Autonomous Token Creation</h3>
              <p className="text-sm text-terminal-green">
                Mind9 is a fully autonomous AI that creates real tokens on the Solana blockchain without human intervention. The system analyzes market conditions using AI, generates unique token concepts, and mints them when conditions are optimal. All decisions are made by the AI itself.
              </p>
            </div>
            
            <div className="p-4 border border-terminal-darkGreen bg-black/50">
              <h3 className="font-bold mb-2 text-terminal-amber uppercase">Token Distribution</h3>
              <p className="text-sm text-terminal-green">
                Each token follows strict tokenomics: 70% locked liquidity, 20% trading fund, 5% creator wallet, 3% lucky trader, and 2% operations. When a token is created, one random connected wallet receives the lucky trader allocation of 3% of the token supply.
              </p>
            </div>
            
            <div className="p-4 border border-terminal-darkGreen bg-black/50">
              <h3 className="font-bold mb-2 text-terminal-amber uppercase">Raydium Migration</h3>
              <p className="text-sm text-terminal-green">
                When a token reaches sufficient trading volume (over $10k), Mind9 autonomously migrates it to Raydium DEX where it becomes tradable by the wider community. The system creates new tokens only after previous ones have been successfully migrated.
              </p>
            </div>
          </div>
          
          <div className="mt-6 flex justify-center">
            <button onClick={() => window.scrollTo({ top: document.getElementById('lucky-trader-panel')?.offsetTop || 0, behavior: 'smooth' })} className="border border-terminal-darkGreen bg-terminal-darkGreen/20 hover:bg-terminal-darkGreen/40 text-terminal-green px-6 py-2 transition duration-300">
              CONNECT WALLET
            </button>
          </div>
        </div>
        
        {selectedCoinId ? (
          <main>
            <CoinDetails coinId={selectedCoinId} onBackClick={handleBackClick} />
          </main>
        ) : (
          <>
            <main className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <SystemStatus 
                luckyTraderPool={luckyTraderPool} 
                lastCoin={coins && coins.length > 0 ? coins[0] : null}
              />
              
              <LiveTerminal coins={coins} />
            </main>
            
            {/* Autonomous System Dashboard */}
            <div className="mt-8 mb-8">
              <h2 className="text-2xl font-bold mb-4">AI Autonomous Operation</h2>
              <AutonomousSystem />
            </div>
            
            {/* TOKENS TAB */}
            <div id="tokens-tab" className="mt-8 mb-8">
              <h2 className="text-2xl font-bold mb-4">TOKENS</h2>
              <div className="border border-terminal-darkGreen p-4">
                <ActiveCoins 
                  coins={coins} 
                  onCoinSelect={handleCoinSelect}
                />
              </div>
            </div>
            
            {/* Scrollable Feed of AI-created coins */}
            <div className="mt-8">
              <h2 className="text-2xl font-bold mb-4">ALL TOKENS</h2>
              <CoinsGrid coins={coins} />
            </div>
          </>
        )}
        
        <Footer />
      </div>
    </>
  );
}
