import React, { useState } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Coin } from '@/lib/types';
import { FiArrowLeft, FiTwitter, FiCopy, FiCheck } from 'react-icons/fi';
import { useWallet } from '@/lib/solana';
import { useToast } from '@/hooks/use-toast';
import { TradingChart } from '@/components/trading/TradingChart';
import { TradingPanel } from '@/components/trading/TradingPanel';
import { TokenDetailsPanel } from '@/components/trading/TokenDetailsPanel';
import { TradeHistory } from '@/components/trading/TradeHistory';

export function CoinPage() {
  const { id } = useParams();
  const { walletAddress } = useWallet();
  const { toast } = useToast();
  
  // State for clipboard operations
  const [copied, setCopied] = useState(false);
  
  // Fetch coin data with proper error handling
  const { data: coin, isLoading, error } = useQuery<Coin>({
    queryKey: [`/api/coin/${id}`],
    retry: 2,
    staleTime: 30000,
  });
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black text-terminal-green">
        <p className="font-mono text-xl animate-pulse">ACCESSING PROTOCOL<span className="animate-blink">█</span></p>
      </div>
    );
  }
  
  if (error || !coin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black text-terminal-green">
        <p className="font-mono text-xl mb-4">ACCESS DENIED</p>
        <Link to="/" className="font-mono text-terminal-amber hover:underline">
          &lt; RETURN TO MAIN PROTOCOL
        </Link>
      </div>
    );
  }
  
  // Handle copying mint address to clipboard
  const handleCopyAddress = () => {
    if (coin.mint_address) {
      navigator.clipboard.writeText(coin.mint_address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      
      toast({
        title: "Address Copied",
        description: "Token address copied to clipboard",
      });
    } else {
      toast({
        title: "No Address Available",
        description: "This token hasn't been minted yet",
        variant: "destructive",
      });
    }
  };
  
  // Handle sharing on Twitter
  const handleTwitterShare = () => {
    const text = `I just discovered ${coin.name} (${coin.symbol}) - Created by Mind9, the autonomous AI protocol. Check it out: `;
    const url = window.location.href;
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-black text-white pb-12">
      {/* Header */}
      <div className="border-b-2 border-terminal-green p-4 flex justify-between items-center">
        <Link to="/" className="text-terminal-green hover:text-terminal-amber flex items-center font-mono">
          <FiArrowLeft className="mr-2" />
          BACK TO PROTOCOL
        </Link>
        <div className="text-terminal-green font-mono">MIND9 TRADING INTERFACE</div>
      </div>
      
      {/* Coin Header */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row items-center justify-between mb-8 border-b border-terminal-green pb-6">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="w-12 h-12 mr-4">
              {coin.image_path ? (
                <img 
                  src={coin.image_path} 
                  alt={`${coin.name} coin`} 
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    console.error(`Failed to load image: ${coin.image_path}`);
                    e.currentTarget.style.display = 'none';
                  }}
                />
              ) : (
                <div 
                  className="w-full h-full rounded-full" 
                  style={{ 
                    background: `radial-gradient(circle, ${coin.primary_color || '#FF7D45'}, ${coin.secondary_color || '#FFD1B8'})` 
                  }}
                />
              )}
            </div>
            
            <div>
              <div className="flex items-center">
                <h1 className="text-terminal-green text-2xl font-mono">${coin.symbol}</h1>
                {coin.minted && (
                  <span 
                    className="ml-2 px-1.5 py-0.5 bg-green-900 text-green-300 text-xs rounded font-mono"
                    title="Verified on blockchain"
                  >
                    VERIFIED
                  </span>
                )}
              </div>
              <p className="text-terminal-darkGreen text-sm">{coin.name}</p>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <button 
              onClick={handleTwitterShare}
              className="px-3 py-2 border border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black flex items-center"
            >
              <FiTwitter className="mr-2" />
              <span className="font-mono text-sm">Share</span>
            </button>
            
            <button 
              onClick={handleCopyAddress}
              className="px-3 py-2 border border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black flex items-center"
            >
              {copied ? <FiCheck className="mr-2" /> : <FiCopy className="mr-2" />}
              <span className="font-mono text-sm">Copy Address</span>
            </button>
          </div>
        </div>
        
        {/* Main Trading Interface Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Section: Chart and Trade History */}
          <div className="lg:col-span-2 space-y-6">
            <TradingChart coin={coin} />
            <TradeHistory coin={coin} />
          </div>
          
          {/* Right Section: Trading Panel and Token Details */}
          <div className="space-y-6">
            <TradingPanel coin={coin} />
            <TokenDetailsPanel coin={coin} />
          </div>
        </div>
      </div>
    </div>
  );
}