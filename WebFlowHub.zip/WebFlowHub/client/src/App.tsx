import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import { CoinPage } from "@/pages/CoinPage";
import { CoinPage as CoinTradingPage } from "@/pages/CoinPageTrading";
import AdminTools from "@/pages/AdminTools";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/coin/:id" component={CoinPage} />
      <Route path="/trading/coin/:id" component={CoinTradingPage} />
      <Route path="/admin/tools" component={AdminTools} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="bg-terminal-black text-terminal-green font-mono antialiased crt-effect scan-lines min-h-screen">
        <Router />
        <Toaster />
      </div>
    </QueryClientProvider>
  );
}

export default App;
