import { useState, useEffect } from 'react';

/**
 * Simple Solana wallet connector
 * In production, this would use @solana/wallet-adapter-react
 */

interface PhantomEvent {
  name: string;
  data: any;
}

interface PhantomProvider {
  connect: (options?: { onlyIfTrusted: boolean }) => Promise<{ publicKey: { toString: () => string } }>;
  disconnect: () => Promise<void>;
  on: (event: string, callback: (args: any) => void) => void;
  isPhantom: boolean;
}

interface Window {
  phantom?: {
    solana?: PhantomProvider;
  };
  solana?: PhantomProvider;
}

const getProvider = (): PhantomProvider | undefined => {
  if (typeof window !== 'undefined') {
    const windowObj = window as unknown as Window;
    
    // First check if it's available via extension (browser has Phantom installed)
    if (windowObj.solana?.isPhantom) {
      return windowObj.solana;
    }
    
    // Then check alternative location (sometimes it's nested in phantom.solana)
    if (windowObj.phantom?.solana?.isPhantom) {
      return windowObj.phantom.solana;
    }
    
    // Check if ethereum provider has solana (some wallet extensions expose this way)
    // @ts-ignore - we know this might not be typed
    if (windowObj.ethereum?.isPhantom || windowObj.ethereum?.isSolana) {
      // @ts-ignore
      return windowObj.ethereum;
    }
  }
  
  return undefined;
};

// State to keep track of if wallet is connected
let walletAddress: string | null = null;
let isConnecting = false;

/**
 * Connect to Phantom wallet with enhanced security measures
 * - Validates wallet provider is genuine
 * - Implements connection timeout
 * - Records last connection time
 */
export const connectWallet = async (): Promise<string | null> => {
  try {
    isConnecting = true;
    
    // Add connection timeout for security
    const connectionTimeout = setTimeout(() => {
      if (isConnecting) {
        isConnecting = false;
        throw new Error('Wallet connection timed out');
      }
    }, 30000); // 30 second timeout
    
    const provider = getProvider();
    
    if (!provider) {
      // Show a more helpful message instead of redirecting automatically
      if (confirm('Phantom wallet extension not detected. Would you like to install it?')) {
        window.open('https://phantom.app/', '_blank');
      }
      clearTimeout(connectionTimeout);
      throw new Error('Phantom wallet not detected in your browser');
    }
    
    // Extra security check to validate the provider is genuine
    if (typeof provider.isPhantom !== 'boolean' || !provider.isPhantom) {
      clearTimeout(connectionTimeout);
      throw new Error('Potential spoofed wallet provider detected');
    }
    
    try {
      // First try to reconnect to already authorized connection
      const reconnectResponse = await provider.connect({ onlyIfTrusted: true });
      walletAddress = reconnectResponse.publicKey.toString();
      console.log('Reconnected to existing wallet connection');
    } catch (reconnectError) {
      // If reconnection fails (not previously connected), try standard connect
      console.log('No existing connection, requesting new connection approval');
      const response = await provider.connect();
      walletAddress = response.publicKey.toString();
    }
    
    // Validate the wallet address format for additional security
    if (!walletAddress || !walletAddress.match(/^[1-9A-HJ-NP-Za-km-z]{32,44}$/)) {
      walletAddress = null;
      clearTimeout(connectionTimeout);
      throw new Error('Invalid wallet address format');
    }
    
    // Store connection timestamp and wallet address
    window.localStorage.setItem('wallet_connection_time', Date.now().toString());
    window.localStorage.setItem('last_connected_wallet', walletAddress);
    
    clearTimeout(connectionTimeout);
    isConnecting = false;
    console.log('Wallet connected successfully:', walletAddress);
    return walletAddress;
  } catch (error) {
    console.error('Error connecting wallet:', error);
    isConnecting = false;
    throw error;
  }
};

/**
 * Disconnect from wallet with cleanup
 * - Properly disconnects from provider
 * - Clears any cached connection data
 * - Removes stored timestamps
 */
export const disconnectWallet = async (): Promise<void> => {
  try {
    const provider = getProvider();
    
    if (provider) {
      await provider.disconnect();
      walletAddress = null;
      
      // Clear connection timestamp and any stored wallet data
      window.localStorage.removeItem('wallet_connection_time');
      console.log('Wallet disconnected successfully');
    }
  } catch (error) {
    console.error('Error disconnecting wallet:', error);
    // Force disconnect even if there was an error with the provider
    walletAddress = null;
  }
};

/**
 * Check if wallet session is expired
 * @param maxSessionTime Maximum session time in minutes
 */
const isWalletSessionExpired = (maxSessionTime = 1440): boolean => { // Set to 24 hours (1440 minutes)
  const connectionTime = window.localStorage.getItem('wallet_connection_time');
  if (!connectionTime) return true;
  
  const connectionTimestamp = parseInt(connectionTime);
  const currentTime = Date.now();
  const sessionLength = (currentTime - connectionTimestamp) / (1000 * 60); // in minutes
  
  return sessionLength > maxSessionTime;
};

/**
 * React hook for wallet integration with security features
 * - Implements automatic session timeout
 * - Periodically verifies wallet connection
 * - Provides wallet state and connection methods
 */
export const useWallet = () => {
  const [wallet, setWallet] = useState<string | null>(walletAddress);
  const [connecting, setConnecting] = useState<boolean>(isConnecting);
  
  useEffect(() => {
    // Try to auto-reconnect on initial load if previously connected
    const attemptAutoReconnect = async () => {
      // If we're not already connected but were previously within session time
      if (!walletAddress && !isWalletSessionExpired()) {
        const provider = getProvider();
        if (provider) {
          try {
            console.log('Attempting to auto-reconnect to previous wallet session...');
            const response = await provider.connect({ onlyIfTrusted: true });
            walletAddress = response.publicKey.toString();
            
            // Refresh the connection timestamp to keep the session alive
            window.localStorage.setItem('wallet_connection_time', Date.now().toString());
            console.log('Auto-reconnected to wallet:', walletAddress);
          } catch (error) {
            console.log('Auto-reconnect failed, user will need to reconnect manually:', error);
          }
        }
      }
    };
    
    attemptAutoReconnect();
    
    const checkWalletConnection = () => {
      // Update state based on current connection
      setWallet(walletAddress);
      setConnecting(isConnecting);
      
      // Security: Auto-disconnect after session timeout
      if (walletAddress && isWalletSessionExpired()) {
        console.log('Wallet session expired, automatically disconnecting for security');
        disconnectWallet();
      }
    };
    
    // Check wallet connection status initially and every second
    checkWalletConnection();
    const interval = setInterval(checkWalletConnection, 1000);
    
    // Security: Set up event listeners for page visibility changes
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        if (walletAddress) {
          // When user returns to the tab, verify wallet connection is still valid
          const provider = getProvider();
          if (!provider) {
            disconnectWallet();
          } else {
            // Refresh the timestamp to keep the session alive
            window.localStorage.setItem('wallet_connection_time', Date.now().toString());
          }
        } else {
          // If not connected, try auto-reconnect when returning to tab
          attemptAutoReconnect();
        }
      }
    };
    
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);
  
  // For compatibility with our trading interface
  return { 
    walletAddress: wallet, 
    connecting, 
    isConnected: !!wallet 
  };
};
