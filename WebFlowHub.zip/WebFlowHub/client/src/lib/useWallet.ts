import { useState, useEffect } from 'react';

interface WalletState {
  wallet: {
    publicKey: string | null;
    isConnected: boolean;
  } | null;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  isConnecting: boolean;
}

// This hook provides wallet integration for the application
export function useWallet(): WalletState {
  const [wallet, setWallet] = useState<{ publicKey: string | null; isConnected: boolean } | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);

  // Check if wallet is already connected on component mount
  useEffect(() => {
    checkWalletConnection();
  }, []);

  // Check if Phantom wallet is connected
  const checkWalletConnection = async () => {
    try {
      // Check if Phantom wallet exists
      const solana = (window as any).solana;
      
      if (solana && solana.isPhantom) {
        // Check if the wallet is already connected
        const response = await solana.connect({ onlyIfTrusted: true });
        
        if (response.publicKey) {
          setWallet({
            publicKey: response.publicKey.toString(),
            isConnected: true
          });
        }
      }
    } catch (error) {
      // If connect({ onlyIfTrusted: true }) fails, the user hasn't connected to this app before
      // or they need to manually connect again, which is fine
      console.log("Wallet not connected yet:", error);
    }
  };

  // Connect to Phantom wallet
  const connectWallet = async () => {
    setIsConnecting(true);
    
    try {
      const solana = (window as any).solana;
      
      if (!solana) {
        window.open("https://phantom.app/", "_blank");
        throw new Error("Phantom wallet not installed");
      }
      
      if (!solana.isPhantom) {
        throw new Error("Please install Phantom wallet");
      }
      
      const response = await solana.connect();
      
      setWallet({
        publicKey: response.publicKey.toString(),
        isConnected: true
      });
    } catch (error) {
      console.error("Error connecting to wallet:", error);
      throw error;
    } finally {
      setIsConnecting(false);
    }
  };

  // Disconnect from wallet
  const disconnectWallet = () => {
    try {
      const solana = (window as any).solana;
      
      if (solana && solana.isPhantom) {
        solana.disconnect();
      }
      
      setWallet(null);
    } catch (error) {
      console.error("Error disconnecting wallet:", error);
    }
  };

  return {
    wallet,
    connectWallet,
    disconnectWallet,
    isConnecting
  };
}