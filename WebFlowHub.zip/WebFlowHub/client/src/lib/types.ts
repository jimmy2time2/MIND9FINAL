export interface Coin {
  id: number;
  name: string;
  symbol: string;
  mint_address: string;
  description: string;
  tagline?: string | null;
  total_supply: string;
  tokenomics: string;
  liquidity_amount: string;
  liquidity_sol: string;
  timestamp: string | Date;
  lucky_trader_wallet?: string | null;
  image_path?: string | null;
  tweet_content?: string | null;
  tweet_id?: string | null;
  minted: boolean;
  user_mintable: boolean;
  primary_color?: string | null;
  secondary_color?: string | null;
  raydium_migrated?: boolean;
  raydium_migrated_at?: string | null;
  liquidity_progress?: number;
  raydium_migration_progress?: string | number; // Progress towards Raydium migration (0-100)
  estimated_time_to_migration?: string | null;
  custom_fields?: Record<string, any>; // For any additional custom data
  statusText?: string; // Added by API
  user_can_mint?: boolean; // Added by API
}

export interface LuckyTrader {
  id: number;
  wallet_address: string;
  joined_at: string;
  times_selected: number;
}

export interface LuckyTraderPool {
  total: number;
  traders: LuckyTrader[];
}

export interface TokenIdea {
  name: string;
  symbol: string;
  description: string;
  totalSupply: string;
  tokenomics: {
    liquidityPool: number;
    creator: number;
    luckyTrader: number;
    tradingFund: number;
    system: number;
  };
}
