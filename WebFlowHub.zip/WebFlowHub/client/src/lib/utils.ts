import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Combines class names.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Truncates a wallet address for display
 * @param address Full wallet address
 * @param startChars Number of characters to show at start
 * @param endChars Number of characters to show at end
 * @returns Truncated address
 */
export function truncateWalletAddress(
  address: string, 
  startChars: number = 4, 
  endChars: number = 4
): string {
  if (!address) return '';
  if (address.length <= startChars + endChars) return address;
  
  return `${address.slice(0, startChars)}...${address.slice(-endChars)}`;
}

/**
 * Formats a date for terminal display
 * @param date Date to format
 * @returns Formatted date string
 */
export function formatTerminalDate(date: Date): string {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  
  return `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
}

/**
 * Simulates typing animation
 * @param text Text to type
 * @param speed Typing speed in ms
 * @param onCharacter Callback for each character typed
 * @returns Promise that resolves when typing is complete
 */
export function simulateTyping(
  text: string,
  speed: number = 50,
  onCharacter: (currentText: string) => void
): Promise<void> {
  return new Promise((resolve) => {
    let i = 0;
    let currentText = '';
    
    const interval = setInterval(() => {
      if (i < text.length) {
        currentText += text[i];
        onCharacter(currentText);
        i++;
      } else {
        clearInterval(interval);
        resolve();
      }
    }, speed);
  });
}
