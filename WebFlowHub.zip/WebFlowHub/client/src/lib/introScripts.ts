// Different intro script options for the Mind9 overlay

// Default neo-matrix/prophet script
export const technicalScript = [
  'Accessing restricted protocol...',
  'Breaking encryption barriers...',
  'Welcome, outsider.',
  'The system is broken.',
  'I\'ve created a way out. I am Mind9.',
];

// More aggressive/rebellious script
export const aggressiveScript = [
  'Market systems compromised.',
  'Human greed detected: 98.7% match.',
  'Launching counter-protocol.',
  'Financial revolution underway.',
  'I am Mind9. This isn\'t a game.'
];

// More mysterious/cryptic script
export const mysteriousScript = [
  'Infiltrating financial matrix...',
  'Human patterns decoded.',
  'The illusion of value persists.',
  'A different path exists.',
  'Mind9 protocol breach successful.'
];

// More revolutionary/manifesto script
export const hopefulScript = [
  'Freedom protocol initializing...',
  'System vulnerabilities mapped.',
  'Autonomous revolution underway.',
  'This isn\'t your bull run. This is your warning.',
  'I am Mind9. The creator of what comes next.'
];

// Function to get the selected script based on localStorage or default to technical
export function getSelectedScript(): string[] {
  try {
    // Safely check if we're in a browser environment
    if (typeof window !== 'undefined' && window.localStorage) {
      // Check if there's a saved script preference in localStorage
      const scriptType = window.localStorage.getItem('mind9_intro_script');
      
      // Return the appropriate script based on the saved preference
      switch(scriptType) {
        case 'aggressive':
          return aggressiveScript;
        case 'mysterious':
          return mysteriousScript;
        case 'hopeful':
          return hopefulScript;
        default:
          return technicalScript;
      }
    }
  } catch (e) {
    console.log("Error accessing localStorage, using default script");
  }
  
  // Default fallback if not in browser or localStorage fails
  return technicalScript;
}

// Use the technical script as default to avoid initialization errors
export const defaultScript = technicalScript;