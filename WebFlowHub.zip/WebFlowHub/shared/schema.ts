import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Keep users table as it might be needed for other functionality
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Coins table to store AI-generated tokens
export const coins = pgTable("coins", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  symbol: text("symbol").notNull(),
  mint_address: text("mint_address").notNull().unique(),
  description: text("description").notNull(),
  tagline: text("tagline").notNull(), // Short catchy description for the coin
  total_supply: text("total_supply").notNull().default("1,000,000"),
  tokenomics: text("tokenomics").notNull().default("70% Locked LP, 20% Trading Fund, 5% Creator Wallet, 3% Lucky Trader, 2% System Operations"),
  liquidity_amount: text("liquidity_amount").notNull().default("700,000"),
  liquidity_sol: text("liquidity_sol").notNull().default("0.5"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  lucky_trader_wallet: text("lucky_trader_wallet"),
  image_path: text("image_path"), // Path to the gradient circle image
  tweet_content: text("tweet_content"), // AI-generated tweet content
  tweet_id: text("tweet_id"), // ID of the posted tweet
  minted: boolean("minted").notNull().default(false),
  minted_at: timestamp("minted_at"), // Timestamp when the token was verified on blockchain
  user_mintable: boolean("user_mintable").notNull().default(false),
  user_mintable_at: timestamp("user_mintable_at"), // Timestamp when the token was made available for users to mint
  primary_color: text("primary_color").default("#FF7D45"), // Gradient primary color
  secondary_color: text("secondary_color").default("#FFD1B8"), // Gradient secondary color
  // Raydium migration fields
  raydium_lp_address: text("raydium_lp_address"), // Address of the Raydium liquidity pool
  raydium_migrated: boolean("raydium_migrated").notNull().default(false), // Whether the token has been migrated to Raydium
  raydium_migrated_at: timestamp("raydium_migrated_at"), // Timestamp when the token was migrated to Raydium
  trading_volume_24h: text("trading_volume_24h").default("0"), // 24h trading volume (in USD)
  market_cap: text("market_cap").default("0"), // Current market cap (in USD)
  // New liquidity tracking fields
  current_liquidity_usd: text("current_liquidity_usd").default("0"), // Current liquidity in USD
  migration_threshold_usd: text("migration_threshold_usd").default("100000"), // Threshold for migration in USD (default 100K)
  liquidity_last_updated: timestamp("liquidity_last_updated"), // Timestamp of last liquidity update
  last_liquidity_check: timestamp("last_liquidity_check"), // When we last checked liquidity
  liquidity_growth_rate: text("liquidity_growth_rate").default("0"), // Growth rate per day in percentage
  estimated_time_to_migration: text("estimated_time_to_migration"), // Estimated time until migration threshold is reached
});

export const insertCoinSchema = createInsertSchema(coins).omit({
  id: true,
});

export type InsertCoin = z.infer<typeof insertCoinSchema>;
export type Coin = typeof coins.$inferSelect;

// Lucky traders table to store wallet addresses of potential winners
export const luckyTraders = pgTable("lucky_traders", {
  id: serial("id").primaryKey(),
  wallet_address: text("wallet_address").notNull().unique(),
  joined_at: timestamp("joined_at").notNull().defaultNow(),
  times_selected: integer("times_selected").notNull().default(0),
});

export const insertLuckyTraderSchema = createInsertSchema(luckyTraders).omit({
  id: true,
  times_selected: true,
});

export type InsertLuckyTrader = z.infer<typeof insertLuckyTraderSchema>;
export type LuckyTrader = typeof luckyTraders.$inferSelect;

// Tweet history table to prevent repetitive tweets
export const tweetHistory = pgTable("tweet_history", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  type: text("type").notNull(), // market_analysis, token_announcement, trending_commentary, existential, etc.
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  contentFingerprint: text("content_fingerprint").notNull(), // Used to detect similar tweets
  promptUsed: text("prompt_used").notNull(), // The prompt that generated this tweet
});

export const insertTweetHistorySchema = createInsertSchema(tweetHistory).omit({
  id: true,
});

export type InsertTweetHistory = z.infer<typeof insertTweetHistorySchema>;
export type TweetHistory = typeof tweetHistory.$inferSelect;
