# How to Deploy Mind9 from Replit Interface

This guide shows you exactly how to deploy Mind9 while ensuring it keeps running autonomously after deployment.

## Step-by-Step Deployment Process

### Step 1: Open Replit Deployment Page

Click on the "Deploy" tab in the left sidebar of your Replit project.

### Step 2: Click Redeploy

![Redeploy Button](attached_assets/image_1746664254255.png)

Click on the "Redeploy" button as shown in the image above.

### Step 3: Edit Commands and Secrets

When prompted, click on "Edit commands and secrets" to configure your deployment.

### Step 4: Set Build and Run Commands

Set these commands exactly as shown:

**Build Command:**
```
npm run build && chmod +x start_persistent.sh
```

**Run Command:**
```
./start_persistent.sh
```

### Step 5: Deploy

Click "Deploy" or "Redeploy" to start the deployment process.

### Step 6: Monitor Deployment Progress

Watch the deployment logs to make sure everything starts up correctly.

You should see messages like:
- "Starting Mind9 in persistent mode with Always On"
- "Starting service monitor..."
- "Service monitor started with PID: [number]"
- "Mind9 started in persistent mode"

### Step 7: Verify Deployment

After deployment completes:
1. Check that your website is accessible at https://mind9.world
2. Verify the deployment shows as "Active" with a green dot
3. Check that all services are running

## What Happens After Deployment

Once deployed:

1. The Mind9 website will be accessible to users
2. The autonomous system will run in the background, even when you're not connected
3. All components (Twitter bot, coin manager, etc.) will operate independently
4. The multi-layered monitoring system will ensure everything keeps running

## Troubleshooting

If something isn't working after deployment:

1. Check deployment logs for error messages
2. Run `./check_mind9_status.sh` from the Replit console to see service status
3. Look at individual log files (mind9.log, twitter_bot.log, etc.)
4. If needed, redeploy using the same steps above

## Need to Make Changes?

If you update your code and need to redeploy:

1. Make your code changes
2. Follow the same deployment steps above
3. The system will update while preserving its autonomous operation