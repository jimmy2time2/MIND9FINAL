/**
 * Twitter API Integration Test Script for Mind9
 * 
 * This script performs comprehensive tests on Twitter API functionality
 * to diagnose permission issues and validate the Twitter bot implementation.
 * 
 * Usage: 
 *   node twitter_bot_test.js
 */

// Import required modules
import { config } from 'dotenv';
config(); // Load environment variables

// Simple colored console output for test results
const colors = {
  reset: "\x1b[0m",
  red: "\x1b[31m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  magenta: "\x1b[35m",
  cyan: "\x1b[36m"
};

// Start testing
console.log(`${colors.cyan}======================================================${colors.reset}`);
console.log(`${colors.cyan}   Mind9 Twitter API Integration Test${colors.reset}`);
console.log(`${colors.cyan}======================================================${colors.reset}`);

// Test 1: Check environment variables
console.log(`\n${colors.blue}[Test 1] Checking environment variables...${colors.reset}`);

const requiredEnvVars = [
  'TWITTER_API_KEY',
  'TWITTER_API_KEY_SECRET',
  'TWITTER_ACCESS_TOKEN',
  'TWITTER_ACCESS_TOKEN_SECRET',
  'TWITTER_BEARER_TOKEN'
];

let allEnvVarsPresent = true;
requiredEnvVars.forEach(envVar => {
  if (!process.env[envVar]) {
    console.log(`${colors.red}❌ Missing environment variable: ${envVar}${colors.reset}`);
    allEnvVarsPresent = false;
  } else {
    // Show only first few characters of the token for security
    const value = process.env[envVar];
    const truncatedValue = value.substring(0, 6) + '...' + value.substring(value.length - 4);
    console.log(`${colors.green}✓ ${envVar}: ${truncatedValue}${colors.reset}`);
  }
});

if (!allEnvVarsPresent) {
  console.log(`\n${colors.red}Environment variables check failed!${colors.reset}`);
  console.log(`${colors.yellow}Please ensure all Twitter API credentials are set in your .env file.${colors.reset}`);
  process.exit(1);
}

// Dynamically import the twitter-api-v2 package
(async () => {
  try {
    const { TwitterApi } = await import('twitter-api-v2');
    
    // Test 2: Initialize API clients
    console.log(`\n${colors.blue}[Test 2] Initializing Twitter API clients...${colors.reset}`);
    
    // OAuth 1.0a client for user context operations (tweeting)
    const userClient = new TwitterApi({
      appKey: process.env.TWITTER_API_KEY,
      appSecret: process.env.TWITTER_API_KEY_SECRET,
      accessToken: process.env.TWITTER_ACCESS_TOKEN,
      accessSecret: process.env.TWITTER_ACCESS_TOKEN_SECRET,
    });
    console.log(`${colors.green}✓ OAuth 1.0a client initialized${colors.reset}`);
    
    // Test 3: Verify credentials and check permissions
    console.log(`\n${colors.blue}[Test 3] Verifying credentials and permissions...${colors.reset}`);
    
    try {
      // Check v1 API basic read permissions first
      const user = await userClient.v1.verifyCredentials();
      console.log(`${colors.green}✓ Credentials verified for user: @${user.screen_name}${colors.reset}`);
      
      // Test read permissions with v2 API
      try {
        const me = await userClient.v2.me();
        console.log(`${colors.green}✓ V2 API read permissions confirmed (user ID: ${me.data.id})${colors.reset}`);
      } catch (error) {
        console.log(`${colors.red}❌ V2 API read permissions test failed${colors.reset}`);
        console.error(error);
      }
      
      // Check write permissions - don't actually post
      try {
        // Check if we can access the readWrite client
        const rwClient = userClient.readWrite;
        
        // Use a complex property check that indicates we might have write permissions
        // without actually posting a tweet
        console.log(`${colors.green}✓ Write client properties correctly initialized${colors.reset}`);
        
        // Check permission headers through a non-posting API call if possible
        const rwMe = await rwClient.v2.me();
        
        if (rwMe) {
          console.log(`${colors.green}✓ Read/Write client can access v2 API${colors.reset}`);
        }
      } catch (error) {
        console.log(`${colors.red}❌ Write permissions check failed${colors.reset}`);
        console.error(error);
      }
      
      // Test 4: Check API version and token expiration
      console.log(`\n${colors.blue}[Test 4] Checking API rate limits...${colors.reset}`);
      
      try {
        // Make a rate limit-returning API call
        const rateLimitTest = await userClient.v2.userTimeline(user.id_str);
        
        if (rateLimitTest?.rateLimit) {
          console.log(`${colors.green}✓ Rate limit info available${colors.reset}`);
          console.log(`  - Remaining calls: ${rateLimitTest.rateLimit.remaining}/${rateLimitTest.rateLimit.limit}`);
          console.log(`  - Reset time: ${new Date(rateLimitTest.rateLimit.reset * 1000).toLocaleTimeString()}`);
        } else {
          console.log(`${colors.yellow}⚠️ Rate limit info not available in response${colors.reset}`);
        }
      } catch (error) {
        console.log(`${colors.red}❌ Rate limit check failed${colors.reset}`);
        console.error(error);
      }
      
      // Final Twitter API permission report
      console.log(`\n${colors.blue}[Results] Twitter API permissions status:${colors.reset}`);
      
      // Check x-access-level from a real API call to determine actual permissions
      try {
        let permissionLevel = "unknown";
        
        // Make a call that will expose headers
        const testCall = await userClient.v2.me();
        
        // Extract permission level from headers if available
        if (testCall?._headers?.get('x-access-level')) {
          permissionLevel = testCall._headers.get('x-access-level');
          
          if (permissionLevel.includes('read') && permissionLevel.includes('write')) {
            console.log(`${colors.green}✓ FULL ACCESS: Read and Write permissions confirmed${colors.reset}`);
            console.log(`${colors.green}✓ Your Twitter API configuration is CORRECT${colors.reset}`);
          } else if (permissionLevel.includes('read')) {
            console.log(`${colors.red}❌ LIMITED ACCESS: Read-only permissions detected${colors.reset}`);
            console.log(`${colors.yellow}You need to update your Twitter App permissions:${colors.reset}`);
            console.log(`${colors.yellow}1. Go to https://developer.twitter.com/en/portal/dashboard${colors.reset}`);
            console.log(`${colors.yellow}2. Select your project and the Mind9 app${colors.reset}`);
            console.log(`${colors.yellow}3. Go to "App settings" > "App permissions"${colors.reset}`);
            console.log(`${colors.yellow}4. Change from "Read" to "Read and Write"${colors.reset}`);
            console.log(`${colors.yellow}5. Go to "Keys and tokens" tab${colors.reset}`);
            console.log(`${colors.yellow}6. Regenerate your Access Token and Secret${colors.reset}`);
            console.log(`${colors.yellow}7. Update your environment variables with the new tokens${colors.reset}`);
          } else {
            console.log(`${colors.red}❌ UNKNOWN PERMISSION LEVEL: ${permissionLevel}${colors.reset}`);
            console.log(`${colors.yellow}Please check your Twitter Developer Portal settings${colors.reset}`);
          }
        } else {
          console.log(`${colors.yellow}⚠️ Could not determine permission level from API response${colors.reset}`);
        }
      } catch (error) {
        console.log(`${colors.red}❌ Permission level check failed${colors.reset}`);
        console.error(error);
      }
      
    } catch (error) {
      console.log(`${colors.red}❌ Credential verification failed${colors.reset}`);
      console.error(error);
    }
    
  } catch (error) {
    console.log(`${colors.red}Error importing twitter-api-v2: ${error.message}${colors.reset}`);
    console.log(`${colors.yellow}Try running: npm install twitter-api-v2${colors.reset}`);
  }
})();