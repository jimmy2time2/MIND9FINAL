#!/bin/bash

# Script to improve the names and descriptions of recovered tokens

echo "==========================================="
echo "   Mind9 Token Enhancement Tool"
echo "==========================================="

# Run the TypeScript improvement script
echo "Enhancing recovered tokens..."
echo ""

npx tsx improve_tokens.ts

echo ""
echo "If you see errors above, try running:"
echo "npm install -g tsx"
echo "tsx improve_tokens.ts"
echo ""
echo "Enhancement complete!"