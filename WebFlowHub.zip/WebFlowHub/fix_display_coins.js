/**
 * Fix Token Display Script
 * 
 * This script fixes the display of minted tokens that aren't showing up in the UI.
 * It queries the Solana blockchain for tokens created by our wallet and
 * ensures they're properly saved in the database.
 */

import { Connection, PublicKey } from '@solana/web3.js';
import { db } from './server/db';
import { coins } from './shared/schema';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Check for required environment variables
if (!process.env.RPC_ENDPOINT || !process.env.CREATOR_WALLET_ADDRESS) {
  console.error('Missing required environment variables: RPC_ENDPOINT, CREATOR_WALLET_ADDRESS');
  process.exit(1);
}

async function main() {
  console.log('Starting coin display fix script...');

  try {
    // Connect to Solana
    const connection = new Connection(process.env.RPC_ENDPOINT);
    const creatorWallet = new PublicKey(process.env.CREATOR_WALLET_ADDRESS);

    console.log(`Connected to Solana RPC: ${process.env.RPC_ENDPOINT}`);
    console.log(`Checking tokens created by: ${creatorWallet.toString()}`);

    // First, check our database to see what tokens we have
    console.log('Querying database for existing tokens...');
    const existingCoins = await db.select().from(coins);
    
    console.log(`Found ${existingCoins.length} coins in the database`);
    const existingMintAddresses = new Set(existingCoins.map(coin => coin.mint_address));

    console.log('Scanning blockchain for tokens...');
    
    // Get token accounts owned by our wallet
    const tokenAccounts = await connection.getParsedTokenAccountsByOwner(
      creatorWallet,
      { programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA') }
    );

    console.log(`Found ${tokenAccounts.value.length} token accounts on the blockchain`);

    // Process each token
    for (const account of tokenAccounts.value) {
      const mintAddress = account.account.data.parsed.info.mint;
      const tokenBalance = account.account.data.parsed.info.tokenAmount.uiAmount;
      const tokenDecimals = account.account.data.parsed.info.tokenAmount.decimals;

      console.log(`Checking token: ${mintAddress} (Balance: ${tokenBalance})`);

      // Skip if already in database
      if (existingMintAddresses.has(mintAddress)) {
        console.log(`  - Token ${mintAddress} already exists in database, skipping`);
        continue;
      }

      // Since this token isn't in our database, let's add it
      try {
        // Try to get token metadata (simplified - in a production environment you'd want to use
        // the metaplex metadata program to get the real name and symbol)
        const tokenName = `Token ${mintAddress.substring(0, 6)}`;
        const tokenSymbol = `T${mintAddress.substring(0, 4)}`;

        console.log(`  - Adding new token to database: ${tokenName} (${tokenSymbol})`);
        
        // Insert into database
        await db.insert(coins).values({
          name: tokenName,
          symbol: tokenSymbol,
          mint_address: mintAddress,
          description: `Automatically detected token from our creator wallet`,
          tagline: `Discovered on chain`,
          total_supply: tokenBalance.toString(),
          tokenomics: "70% Locked LP, 20% Trading Fund, 5% Creator Wallet, 3% Lucky Trader, 2% System Operations",
          liquidity_amount: (tokenBalance * 0.7).toString(),  // 70% in liquidity
          liquidity_sol: "0.01",  // Default SOL liquidity
          timestamp: new Date(),
          minted: true,
          minted_at: new Date(),
          user_mintable: true,
          user_mintable_at: new Date(),
          primary_color: "#FF7D45"
        });

        console.log(`  ✓ Successfully added token ${mintAddress} to database`);
      } catch (error) {
        console.error(`  × Error adding token ${mintAddress} to database:`, error);
      }
    }

    console.log('\nCoin display fix completed!');
    console.log('Please refresh the website to see your tokens.');
  } catch (error) {
    console.error('Error during script execution:', error);
  }
}

main().catch(err => {
  console.error('Unhandled error in main:', err);
  process.exit(1);
});