#!/usr/bin/env python3
"""
Main Controller for Mind9
Autonomous AI system that mints SPL tokens on Solana, generates visuals,
and maintains a Twitter presence with a specific personality.
"""

import os
import time
import json
import logging
import schedule
import random
from datetime import datetime, timedelta
from dotenv import load_dotenv

# Import Mind9 components
from market_analyzer import MarketAnalyzer
from coin_minter import CoinMinter
from image_generator import CoinImageGenerator
from tweet_logic import TweetGenerator
from twitter_api import TwitterAPI

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("mind9.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("mind9")

class Mind9:
    def __init__(self):
        """Initialize the autonomous Mind9 system"""
        # Check required environment variables
        self._check_environment()
        
        # Initialize components
        logger.info("Initializing Mind9 components...")
        self.market_analyzer = MarketAnalyzer()
        self.coin_minter = CoinMinter()
        self.image_generator = CoinImageGenerator()
        self.tweet_generator = TweetGenerator()
        self.twitter = TwitterAPI()
        
        # Load system state
        self.state_file = "mind9_state.json"
        self.load_state()
        
        logger.info("Mind9 system initialized successfully")
    
    def _check_environment(self):
        """Check if all required environment variables are set"""
        required_vars = [
            "OPENAI_API_KEY",
            "RPC_ENDPOINT",
            "SOLANA_PRIVATE_KEY",
            "TWITTER_API_KEY",
            "TWITTER_API_KEY_SECRET",
            "TWITTER_ACCESS_TOKEN",
            "TWITTER_ACCESS_TOKEN_SECRET",
            "TWITTER_BEARER_TOKEN"
        ]
        
        missing = [var for var in required_vars if not os.getenv(var)]
        if missing:
            error_msg = f"Missing required environment variables: {', '.join(missing)}"
            logger.error(error_msg)
            raise ValueError(error_msg)
    
    def load_state(self):
        """Load system state from file"""
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r') as file:
                    self.state = json.load(file)
                    logger.info("Loaded system state")
            except Exception as e:
                logger.error(f"Error loading system state: {e}")
                self.initialize_state()
        else:
            self.initialize_state()
    
    def initialize_state(self):
        """Initialize system state"""
        self.state = {
            "system_start_time": datetime.now().isoformat(),
            "last_daily_tweet_time": None,
            "daily_tweet_count": 0,
            "last_coin_creation_time": None,
            "coins_created": 0,
            "tweets_posted": 0
        }
        self.save_state()
    
    def save_state(self):
        """Save system state to file"""
        try:
            with open(self.state_file, 'w') as file:
                json.dump(self.state, file, indent=2)
                logger.info("Saved system state")
        except Exception as e:
            logger.error(f"Error saving system state: {e}")
    
    def check_and_create_token(self):
        """
        Check market conditions and create a token if appropriate
        
        This is the main autonomous function that decides when to mint a new token
        """
        logger.info("Checking if we should create a new token...")
        
        # Use the market analyzer to determine if we should create a token
        should_create, reason = self.market_analyzer.should_create_token()
        
        if not should_create:
            logger.info(f"Not creating a token: {reason}")
            return False
        
        logger.info(f"Market conditions favorable for token creation: {reason}")
        
        # Create the token
        token_name = self.coin_minter.generate_token_name()
        logger.info(f"Minting new token: {token_name}")
        
        # Mint the actual token on Solana
        coin_data = self.coin_minter.mint_token(token_name)
        
        if not coin_data:
            logger.error("Failed to mint token")
            return False
        
        # Record successful token creation
        self.market_analyzer.record_token_creation()
        self.state["last_coin_creation_time"] = datetime.now().isoformat()
        self.state["coins_created"] += 1
        self.save_state()
        
        # Generate the coin image
        image_path, image_bytes = self.image_generator.generate_coin_image(token_name)
        
        # Update coin record with image path
        self.coin_minter.update_coin_image(coin_data["id"], image_path)
        
        # Generate announcement tweet
        tweet_text = self.tweet_generator.generate_coin_announcement(coin_data)
        
        # Post to Twitter with image
        tweet_id = self.twitter.post_tweet(tweet_text, image_path)
        
        if tweet_id:
            logger.info(f"Posted token announcement to Twitter: {tweet_id}")
            self.state["tweets_posted"] += 1
            self.save_state()
            return True
        else:
            logger.error("Failed to post token announcement to Twitter")
            return False
    
    def post_daily_tweet(self):
        """Post a daily strategic tweet to build community"""
        logger.info("Preparing to post daily strategic tweet...")
        
        # Check if we already posted today
        now = datetime.now()
        if self.state["last_daily_tweet_time"]:
            last_tweet_time = datetime.fromisoformat(self.state["last_daily_tweet_time"])
            if last_tweet_time.date() == now.date():
                logger.info("Already posted daily tweet today")
                return False
        
        # Generate tweet based on time of day
        hour = now.hour
        if 5 <= hour < 12:
            # Morning tweet
            tweet_text = self.tweet_generator.generate_morning_tweet()
        elif 12 <= hour < 18:
            # Midday tweet - quote another crypto trending topic
            tweet_text = self.tweet_generator.generate_quote_tweet()
        else:
            # Evening/night tweet
            tweet_text = self.tweet_generator.generate_night_tweet()
        
        # Post to Twitter
        tweet_id = self.twitter.post_tweet(tweet_text)
        
        if tweet_id:
            logger.info(f"Posted daily tweet to Twitter: {tweet_id}")
            self.state["last_daily_tweet_time"] = now.isoformat()
            self.state["tweets_posted"] += 1
            self.save_state()
            return True
        else:
            logger.error("Failed to post daily tweet to Twitter")
            return False
    
    def setup_schedule(self):
        """
        Set up the scheduled tasks:
        1. Check market and potentially create tokens
        2. Post daily strategic tweets
        """
        # Check market conditions every 8 hours
        schedule.every(8).hours.do(self.check_and_create_token)
        
        # Schedule daily tweets - one per day at a strategic time
        # Randomly select a time between 9-10 AM
        random_hour = random.randint(9, 10)
        random_minute = random.randint(0, 59)
        schedule.every().day.at(f"{random_hour:02d}:{random_minute:02d}").do(self.post_daily_tweet)
        
        logger.info(f"Scheduled daily tweet at {random_hour:02d}:{random_minute:02d}")
        logger.info("All schedules set up successfully")
    
    def run(self):
        """Run the Mind9 system continuously"""
        logger.info("Starting Mind9 autonomous system...")
        
        # Set up scheduled tasks
        self.setup_schedule()
        
        # Initial market check and potential token creation
        self.check_and_create_token()
        
        # Initial daily tweet
        self.post_daily_tweet()
        
        # Main loop
        while True:
            try:
                # Run pending scheduled tasks
                schedule.run_pending()
                
                # Sleep to prevent high CPU usage
                time.sleep(60)
            except KeyboardInterrupt:
                logger.info("Shutting down Mind9 system")
                break
            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                time.sleep(300)  # Sleep 5 minutes on error

if __name__ == "__main__":
    try:
        mind9 = Mind9()
        mind9.run()
    except Exception as e:
        logger.critical(f"Fatal error: {e}")