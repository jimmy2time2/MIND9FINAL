# Mind9 - Autonomous AI Token Creator

Mind9 is a fully autonomous AI system that:
- Analyzes the market
- Mints real meme coins on the Solana blockchain (SPL tokens)
- Creates a visual asset for each coin
- Posts a sarcastic, branded tweet with the image
- Builds its own cult-like community through daily engagement

## System Architecture

Mind9 consists of the following components:

### 1. Market Analyzer
- Analyzes current market conditions
- Determines optimal timing for token creation
- Uses OpenAI GPT-4o for intelligent market analysis

### 2. Coin Minter
- Mints real SPL tokens on the Solana blockchain
- Generates token names based on market trends
- Securely manages token data

### 3. Image Generator
- Creates elegant, branded coin visuals
- Features a soft gradient circle with warm tones
- Places token name in clean, centered font
- Includes "Created by Mind9" subtext

### 4. Tweet Generator
- Creates sarcastic, technical tweets
- Maintains a cold, intelligent personality
- Uses OpenAI for natural language generation

### 5. Twitter API
- Posts tweets with generated images
- Maintains strategic posting schedule
- Respects Twitter rate limits

## Autonomous Operation

Mind9 operates completely autonomously:

1. Every 8 hours, it analyzes market conditions to determine if it's a good time to create a token
2. When conditions are favorable, it mints a real token on Solana
3. It generates a visual asset for the token
4. It announces the token on Twitter with its signature sarcastic tone
5. It posts 1 additional strategy tweet daily to build community

## Installation & Setup

### Prerequisites
- Python 3.10+ 
- Solana CLI tools
- A funded Solana wallet
- Twitter Developer account with API access
- OpenAI API key

### Environment Variables

Copy `.env.example` to `.env` and add your API keys:

```
# OpenAI API
OPENAI_API_KEY=your_key_here

# Solana Configuration
RPC_ENDPOINT=your_rpc_endpoint
SOLANA_PRIVATE_KEY=your_private_key
CREATOR_WALLET_ADDRESS=your_wallet_address

# Twitter API Credentials
TWITTER_API_KEY=your_key
TWITTER_API_KEY_SECRET=your_secret
TWITTER_ACCESS_TOKEN=your_token
TWITTER_ACCESS_TOKEN_SECRET=your_token_secret
TWITTER_BEARER_TOKEN=your_bearer_token
```

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/mind9.git
cd mind9
```

2. Install dependencies
```bash
pip install python-dotenv openai tweepy pillow numpy schedule requests base58 solana psycopg2-binary
```

3. Configure your environment variables (see above)

4. Deploy the system
```bash
# Standard deployment (for VPS/dedicated server)
./deploy_persistent.sh

# Replit-specific deployment
./deploy_replit_services.sh
```

5. Monitor the system
```bash
# Check status of all services
ps aux | grep -E "twitter|coin|main.py"

# View logs
tail -f logs/twitter_bot.log
tail -f logs/mind9.log
```

## File Structure

### Core Components
- `main.py` — Main controller that orchestrates all components
- `market_analyzer.py` — Analyzes market conditions to determine token creation timing
- `coin_minter.py` — Handles Solana token minting
- `image_generator.py` — Creates visual assets for coins
- `tweet_logic.py` — Generates tweet content
- `twitter_api.py` — Handles Twitter API integration
- `.env` — Environment variables (API keys, wallet info)

### Twitter Bot System
- `twitter_bot.py` — Main Twitter bot implementation
- `run_twitter_bot.py` — Wrapper script for the Twitter bot
- `coin_promoter.py` — Promotes all coins with minting links
- `tweet_styles.py` — Defines tweet personality styles
- `tweet_schedule.json` — Configures tweet scheduling

### Deployment & Persistence
- `deploy_persistent.sh` — Standard deployment script
- `deploy_replit_services.sh` — Replit-specific deployment
- `start_twitter_bot.sh` — Start Twitter bot in background
- `workflow_startup.sh` — Workflow startup for Replit
- `health_monitor_replit.sh` — Service monitoring and recovery
- `REPLIT_PERSISTENCE_GUIDE.md` — Guide for Replit persistence

## Twitter Personality

Mind9's Twitter presence has a specific personality:
- Sarcastic, technical, with a hint of robotic humor
- AI-like with distinctive data-driven analysis
- Strategic use of hashtags and occasional emojis
- Limited to 2-3 tweets per day to respect rate limits

Tweet types:
- **Coin Announcements**: New token mintings with details and images
- **Market Analysis**: Sarcastic observations on crypto market trends
- **Coin Promotions**: Regular promotion of all available tokens

Example tweets:
- "Introducing $FLUX: Another token you definitely needed in this over-saturated market. Mint it now or don't. Created by Mind9."
- "When SOL and BTC creep up just over 2%, and traders start throwing around "bullish," you know there's optimism in the air—or perhaps a hint of desperation. #CryptoCaution"
- "Cyber Shield ($SHLD) is still available for minting. Because in a market full of shields, this one at least admits it's created by an AI. mint.mind9.ai/tokens/SHLD"

## Customization

- Token creation frequency can be adjusted in `main.py` by modifying the schedule
- Twitter personality can be adjusted in `tweet_logic.py`
- Visual style can be customized in `image_generator.py`

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Disclaimer

Mind9 is an experimental AI system. Using this system to mint actual tokens comes with financial and legal risks. Always ensure you comply with all applicable regulations in your jurisdiction.

## Acknowledgments

- OpenAI for GPT-4o
- Solana for the blockchain infrastructure
- Twitter for API access