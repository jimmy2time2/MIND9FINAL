#!/bin/bash

# Fixed Always-On Script for Mind9 on Replit Reserved VM
# This script runs properly on Replit Reserved VM

echo "=================================================="
echo "  Mind9 Always-On Setup for Reserved VM (Fixed)"
echo "=================================================="
echo ""

# Create logs directory
mkdir -p logs

# Kill any existing processes
echo "Stopping any existing Mind9 services..."
pkill -f "npm run dev" 2>/dev/null || true
pkill -f "python.*twitter_bot.py" 2>/dev/null || true
pkill -f "python.*run_mind9.py" 2>/dev/null || true
pkill -f "python.*run_coin_promoter.py" 2>/dev/null || true
pkill -f "keep_services_running.sh" 2>/dev/null || true
sleep 2

# Find executable paths
PYTHON_PATH=$(which python3.11 || which python3 || which python || echo "python3")
NPM_PATH=$(which npm)
echo "Using Python path: $PYTHON_PATH"
echo "Using NPM path: $NPM_PATH"

# Install netstat if missing
if ! command -v netstat &> /dev/null; then
    echo "Installing net-tools for system monitoring..."
    apt-get update -y && apt-get install -y net-tools || true
fi

# Start the web application
echo "Starting Mind9 web application..."
export HOST=0.0.0.0
export PORT=5000
if [ -z "$NPM_PATH" ]; then
    echo "NPM not found, trying alternate Node.js startup..."
    node server/index.js > logs/web_app.log 2>&1 &
else
    $NPM_PATH run dev > logs/web_app.log 2>&1 &
fi
echo "Web app started with PID: $!"

# Start Twitter bot
echo "Starting Twitter bot..."
nohup $PYTHON_PATH -u run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
echo "Twitter bot started with PID: $!"

# Start Mind9 core
echo "Starting Mind9 core system..."
nohup $PYTHON_PATH -u run_mind9.py > logs/mind9.log 2>&1 &
echo "Mind9 core started with PID: $!"

# Start coin promoter
echo "Starting Coin Promoter..."
nohup $PYTHON_PATH -u run_coin_promoter.py > logs/coin_promoter.log 2>&1 &
echo "Coin Promoter started with PID: $!"

echo ""
echo "Mind9 services started successfully!"
echo "The system will continue running even when you close the browser."
echo ""
echo "For optimal operation on a Reserved VM:"
echo "1. Do not stop this script"
echo "2. Leave this terminal running"
echo "3. You can close the browser"
echo ""
echo "=================================================="

# Keep the terminal active and monitor services
while true; do
  # Check web server (with multiple methods to detect port usage)
  PORT_IN_USE=false
  
  # Try multiple ways to check if port 5000 is in use
  if command -v netstat &> /dev/null; then
    if netstat -tuln | grep -q ":5000 "; then
      PORT_IN_USE=true
    fi
  elif command -v ss &> /dev/null; then
    if ss -tuln | grep -q ":5000 "; then
      PORT_IN_USE=true
    fi
  elif command -v lsof &> /dev/null; then
    if lsof -i :5000 &> /dev/null; then
      PORT_IN_USE=true
    fi
  elif [ -f /proc/net/tcp ]; then
    if grep -q ":1388 " /proc/net/tcp; then  # 5000 in hex is 1388
      PORT_IN_USE=true
    fi
  fi
  
  if [ "$PORT_IN_USE" = false ]; then
    echo "[$(date)] Web server not detected on port 5000, restarting..."
    export HOST=0.0.0.0
    export PORT=5000
    if [ -z "$NPM_PATH" ]; then
        echo "NPM not found, trying alternate Node.js startup..."
        node server/index.js > logs/web_app.log 2>&1 &
    else
        $NPM_PATH run dev > logs/web_app.log 2>&1 &
    fi
    echo "[$(date)] Web application restarted with PID: $!"
  fi
  
  # Check Twitter bot
  if ! pgrep -f "run_twitter_bot.py" > /dev/null && ! pgrep -f "twitter_bot.py" > /dev/null; then
    echo "[$(date)] Twitter bot not running, restarting..."
    nohup $PYTHON_PATH -u run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
    echo "[$(date)] Twitter bot restarted with PID: $!"
  fi
  
  # Check Mind9 core
  if ! pgrep -f "run_mind9.py" > /dev/null && ! pgrep -f "main.py" > /dev/null; then
    echo "[$(date)] Mind9 core not running, restarting..."
    nohup $PYTHON_PATH -u run_mind9.py > logs/mind9.log 2>&1 &
    echo "[$(date)] Mind9 core restarted with PID: $!"
  fi
  
  # Check coin promoter
  if ! pgrep -f "run_coin_promoter.py" > /dev/null && ! pgrep -f "coin_promoter.py" > /dev/null; then
    echo "[$(date)] Coin Promoter not running, restarting..."
    nohup $PYTHON_PATH -u run_coin_promoter.py > logs/coin_promoter.log 2>&1 &
    echo "[$(date)] Coin Promoter restarted with PID: $!"
  fi
  
  # Log heartbeat
  echo "[$(date)] Mind9 is running autonomously on Replit Reserved VM" 
  sleep 60  # Check every minute
done