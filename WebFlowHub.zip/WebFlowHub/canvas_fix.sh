#!/bin/bash

# Canvas dependency fix for Replit deployment
echo "=================================================="
echo "  Canvas Dependency Fix for Replit"
echo "=================================================="
echo ""

# Create a proper replit.nix file with canvas dependencies
echo "Creating replit.nix with Canvas dependencies..."
cat > replit.nix << EOL
{ pkgs }: {
  deps = [
    pkgs.nodejs-20_x
    pkgs.python311
    pkgs.postgresql_16
    pkgs.nodePackages.typescript
    pkgs.nodePackages.npm
    
    # Canvas dependencies
    pkgs.cairo
    pkgs.pango
    pkgs.libuuid
    pkgs.libpng
    pkgs.libjpeg
    pkgs.giflib
    pkgs.librsvg
    pkgs.pkg-config
  ];
  
  env = {
    LD_LIBRARY_PATH = pkgs.lib.makeLibraryPath [
      pkgs.libuuid
      pkgs.cairo
      pkgs.pango
      pkgs.libpng
      pkgs.libjpeg
      pkgs.giflib
      pkgs.librsvg
    ];
  };
}
EOL

# Set npm config for canvas
export npm_config_canvas_binary_host_mirror=https://github.com/Automattic/node-canvas/releases/download/
export CXXFLAGS="--std=c++14"

# Rebuild canvas specifically
echo "Rebuilding Canvas package..."
npm rebuild canvas --build-from-source

echo ""
echo "Canvas dependencies fixed!"
echo ""
echo "To proceed with deployment:"
echo "1. Run: ./simple_deploy.sh"
echo "2. Go to the Deployments tab in Replit"
echo "3. Click Deploy"
echo ""
echo "=================================================="