
#!/bin/bash

echo "=========================================="
echo "   Mind9 Reserved VM Startup"
echo "=========================================="

# Create necessary directories
mkdir -p logs
mkdir -p .pids

# Source Nix profile if it exists
if [ -f "/nix/var/nix/profiles/default/etc/profile.d/nix-daemon.sh" ]; then
  source /nix/var/nix/profiles/default/etc/profile.d/nix-daemon.sh
  echo "Sourced Nix profile"
fi

# Find and add Node.js to PATH
NODEJS_PATH=$(find /nix/store -maxdepth 1 -name "*nodejs*" -type d | sort -r | head -n1)
if [ -n "$NODEJS_PATH" ]; then
  export PATH="$NODEJS_PATH/bin:$PATH"
  echo "Added Node.js from $NODEJS_PATH to PATH"
fi

# Set HOST and PORT for web server
export HOST=0.0.0.0
export PORT=5000

# Start web application in the background
echo "Starting web application..."
NODE_ENV=production node dist/index.js > logs/web_app.log 2>&1 &
echo $! > .pids/webapp.pid

echo "Waiting for web server to start..."
for i in {1..30}; do
  if curl -s http://localhost:5000 > /dev/null; then
    echo "Web server is running!"
    break
  fi
  echo "Waiting for web server... ($i/30)"
  sleep 2
done

# Start Twitter bot
echo "Starting Twitter bot..."
python run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
echo $! > .pids/twitter_bot.pid

# Start Mind9 autonomous system
echo "Starting Mind9 autonomous system..."
python main.py > logs/mind9.log 2>&1 &
echo $! > .pids/mind9.pid

# Start Coin Promoter
echo "Starting Coin Promoter..."
python coin_promoter.py > logs/coin_promoter.log 2>&1 &
echo $! > .pids/coin_promoter.pid

# Start health monitor
echo "Starting health monitor..."
bash health_monitor_replit.sh > logs/monitor.log 2>&1 &
echo $! > .pids/monitor.pid

echo "All Mind9 services started successfully!"

# Keep the VM active with a simple heartbeat process
while true; do
  # Check and restart services if needed
  for service in webapp twitter_bot mind9 coin_promoter; do
    if [ -f ".pids/${service}.pid" ]; then
      pid=$(cat .pids/${service}.pid)
      if ! ps -p $pid > /dev/null; then
        echo "[$(date)] ${service} is down, restarting..." >> logs/heartbeat.log
        
        case $service in
          webapp)
            NODE_ENV=production node dist/index.js > logs/web_app.log 2>&1 &
            echo $! > .pids/webapp.pid
            ;;
          twitter_bot)
            python run_twitter_bot.py > logs/twitter_bot.log 2>&1 &
            echo $! > .pids/twitter_bot.pid
            ;;
          mind9)
            python main.py > logs/mind9.log 2>&1 &
            echo $! > .pids/mind9.pid
            ;;
          coin_promoter)
            python coin_promoter.py > logs/coin_promoter.log 2>&1 &
            echo $! > .pids/coin_promoter.pid
            ;;
        esac
        
        echo "[$(date)] ${service} restarted with PID: $(cat .pids/${service}.pid)" >> logs/heartbeat.log
      fi
    fi
  done
  
  echo "[$(date)] Mind9 heartbeat check completed" >> logs/heartbeat.log
  sleep 300  # Check every 5 minutes
done
