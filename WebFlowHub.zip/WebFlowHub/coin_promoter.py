#!/usr/bin/env python3
"""
Coin Promoter for Mind9
This module extends the Twitter bot to promote all available coins with minting links.
It ensures each coin gets regular visibility on social media.
"""

import os
import json
import time
import logging
import psycopg2
import random
from datetime import datetime, timedelta
import schedule

# Configure logging
logger = logging.getLogger("coin_promoter")
logger.setLevel(logging.INFO)

if not os.path.exists("logs"):
    os.makedirs("logs")
    
# File handler
file_handler = logging.FileHandler("coin_promoter.log")
file_handler.setLevel(logging.INFO)

# Console handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# Formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# Add handlers
logger.addHandler(file_handler)
logger.addHandler(console_handler)

class CoinPromoter:
    def __init__(self):
        """Initialize the coin promoter module"""
        # Load environment variables
        self._load_env()
        
        # State tracking
        self.state_file = "coin_promotion_state.json"
        self.last_promotion_times = self._load_state()
        
        # Website URL for minting links
        self.website_base_url = os.getenv("WEBSITE_BASE_URL", "https://mind9.ai")
        
        # Configure coin promotion intervals (hours)
        self.promotion_interval = int(os.getenv("COIN_PROMOTION_INTERVAL", "24"))
        
        # Configuration
        self.daily_promotion_limit = 3  # Maximum coins to promote per day
        self.min_time_between_promotions = 8 * 60 * 60  # 8 hours in seconds
        
        logger.info(f"Coin Promoter initialized with {self.promotion_interval}h intervals")
        logger.info(f"Website base URL: {self.website_base_url}")
        logger.info(f"Daily promotion limit: {self.daily_promotion_limit}")
    
    def _load_env(self):
        """Load environment variables"""
        try:
            # Check if dotenv is available
            try:
                from dotenv import load_dotenv
                load_dotenv()
                logger.info("Loaded environment from .env file")
            except ImportError:
                logger.info("dotenv not installed, using system environment variables")
        except Exception as e:
            logger.error(f"Error loading environment: {str(e)}")
    
    def _load_state(self):
        """Load promotion state from file"""
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r') as file:
                    state = json.load(file)
                    logger.info(f"Loaded promotion state for {len(state)} coins")
                    return state
            except Exception as e:
                logger.error(f"Error loading promotion state: {str(e)}")
                return {}
        else:
            logger.info("No previous promotion state found, starting fresh")
            return {}
    
    def _save_state(self):
        """Save promotion state to file"""
        try:
            with open(self.state_file, 'w') as file:
                json.dump(self.last_promotion_times, file)
            logger.info(f"Saved promotion state for {len(self.last_promotion_times)} coins")
        except Exception as e:
            logger.error(f"Error saving promotion state: {str(e)}")
    
    def connect_to_db(self):
        """Connect to the PostgreSQL database"""
        try:
            # Use DATABASE_URL environment variable if available
            if os.getenv("DATABASE_URL"):
                conn = psycopg2.connect(os.getenv("DATABASE_URL"))
                logger.info("Connected to database using DATABASE_URL")
                return conn
            
            # Otherwise use individual connection parameters
            conn = psycopg2.connect(
                host=os.getenv("PGHOST", "localhost"),
                database=os.getenv("PGDATABASE", "postgres"),
                user=os.getenv("PGUSER", "postgres"),
                password=os.getenv("PGPASSWORD", "postgres"),
                port=os.getenv("PGPORT", "5432")
            )
            logger.info("Connected to database using individual parameters")
            return conn
        except Exception as e:
            logger.error(f"Database connection error: {str(e)}")
            return None
    
    def get_mintable_coins(self):
        """Get all coins that are minted and mintable by users"""
        try:
            conn = self.connect_to_db()
            if not conn:
                logger.error("Failed to connect to database")
                return []
                
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, name, symbol, description, mint_address, 
                       primary_color, secondary_color, tagline,
                       total_supply, liquidity_sol, market_cap,
                       user_mintable, minted, raydium_migrated
                FROM coins 
                WHERE minted = true AND user_mintable = true
                ORDER BY timestamp DESC
            """)
            
            coins = []
            for row in cursor.fetchall():
                coins.append({
                    'id': row[0],
                    'name': row[1],
                    'symbol': row[2],
                    'description': row[3],
                    'mint_address': row[4],
                    'primary_color': row[5],
                    'secondary_color': row[6],
                    'tagline': row[7],
                    'total_supply': row[8],
                    'liquidity_sol': row[9],
                    'market_cap': row[10],
                    'user_mintable': row[11],
                    'minted': row[12],
                    'raydium_migrated': row[13],
                    'image_url': None  # Set to None since it's referenced but not in database
                })
                
            cursor.close()
            conn.close()
            logger.info(f"Found {len(coins)} mintable coins")
            return coins
        except Exception as e:
            logger.error(f"Error retrieving mintable coins: {str(e)}")
            return []
    
    def generate_promotion_tweet(self, coin):
        """Generate a tweet to promote a coin with minting link"""
        try:
            from tweet_logic import TweetGenerator
            tweet_gen = TweetGenerator()
            
            # Get coin details
            name = coin['name']
            symbol = coin['symbol']
            description = coin['description'] or ""
            tagline = coin['tagline'] or ""
            mint_link = f"{self.website_base_url}/mint/{coin['symbol'].lower()}"
            
            # Handle Raydium migrated coins differently
            if coin['raydium_migrated']:
                # For Raydium-migrated coins, promote trading on DEX
                prompt = f"Create a tweet promoting {name} (${symbol}) which is now available on Raydium DEX. " + \
                        f"Mention that it was created by Mind9 AI. Include this link: {mint_link}. " + \
                        f"If relevant, include these details: {tagline}. Keep it sarcastic and intelligent. " + \
                        f"Add appropriate hashtags like #Solana #SolanaNFT #AI #Crypto."
            else:
                # For regular coins, promote minting
                prompt = f"Create a tweet promoting the minting of {name} (${symbol}) token. " + \
                        f"Highlight that this is an AI-generated token by Mind9. " + \
                        f"Include this minting link: {mint_link}. " + \
                        f"If relevant, mention: {tagline}. Keep it sarcastic and intelligent. " + \
                        f"Add appropriate hashtags like #Solana #Mind9 #AITokens #Crypto."
            
            # Generate the tweet content
            tweet = tweet_gen.generate_tweet(prompt)
            
            # Ensure the tweet contains the symbol and link
            if symbol not in tweet:
                tweet = tweet.replace(".", f". ${symbol}")
            
            if mint_link not in tweet:
                tweet = f"{tweet}\n\n{mint_link}"
            
            return tweet
        except Exception as e:
            logger.error(f"Error generating promotion tweet: {str(e)}")
            # Fallback to basic template if tweet generation fails
            mint_link = f"{self.website_base_url}/mint/{coin['symbol'].lower()}"
            return f"Discover {coin['name']} (${coin['symbol']}), an AI-generated token by Mind9.\n\nMint now: {mint_link}\n\n#Solana #AITokens #Crypto #Mind9"
    
    def post_promotion_tweet(self, coin):
        """Post a tweet promoting a coin with minting link"""
        try:
            # Import the TwitterAPI from the twitter_bot
            from twitter_api import TwitterAPI
            twitter = TwitterAPI()
            
            # Generate tweet content
            tweet_content = self.generate_promotion_tweet(coin)
            
            # Post the tweet
            tweet_id = twitter.post_tweet(tweet_content)
            
            if tweet_id:
                logger.info(f"Posted promotion tweet for {coin['symbol']} (Tweet ID: {tweet_id})")
                
                # Update promotion state
                self.last_promotion_times[str(coin['id'])] = time.time()
                self._save_state()
                
                return tweet_id
            else:
                logger.warning(f"Failed to post promotion tweet for {coin['symbol']}")
                return None
        except Exception as e:
            logger.error(f"Error posting promotion tweet: {str(e)}")
            return None
    
    def promote_next_coin(self):
        """Promote the next coin that's due for promotion"""
        # Get all mintable coins
        coins = self.get_mintable_coins()
        if not coins:
            logger.warning("No mintable coins found to promote")
            return
        
        # Check if we've hit the daily limit
        today = datetime.now().strftime("%Y-%m-%d")
        daily_count_key = f"daily_count_{today}"
        daily_count = self.last_promotion_times.get(daily_count_key, 0)
        
        if daily_count >= self.daily_promotion_limit:
            logger.info(f"Daily promotion limit reached ({daily_count}/{self.daily_promotion_limit})")
            return
        
        # Calculate promotion priority score for each coin
        prioritized_coins = []
        current_time = time.time()
        
        for coin in coins:
            coin_id = str(coin['id'])
            last_promotion = self.last_promotion_times.get(coin_id, 0)
            hours_since_promotion = (current_time - last_promotion) / 3600
            
            # Skip coins that were promoted too recently
            min_hours = self.min_time_between_promotions / 3600
            if hours_since_promotion < min_hours:
                logger.info(f"Skipping {coin['symbol']} - promoted {hours_since_promotion:.1f}h ago (min {min_hours}h)")
                continue
            
            # Calculate priority score (higher = more urgent to promote)
            # Coins that haven't been promoted recently get higher priority
            priority_score = hours_since_promotion
            
            # Boost score for coins that have never been promoted
            if last_promotion == 0:
                priority_score += 100
            
            # Boost score for coins that have been migrated to Raydium
            if coin['raydium_migrated']:
                priority_score += 20
            
            prioritized_coins.append({
                'coin': coin,
                'priority_score': priority_score,
                'hours_since_promotion': hours_since_promotion
            })
        
        # Sort by priority score (highest first)
        prioritized_coins.sort(key=lambda x: x['priority_score'], reverse=True)
        
        # Log promotion candidates
        logger.info(f"Promotion candidates (top 5 of {len(prioritized_coins)}):")
        for idx, item in enumerate(prioritized_coins[:5]):
            coin = item['coin']
            logger.info(f"  {idx+1}. {coin['symbol']} - Score: {item['priority_score']:.1f}, " +
                       f"Last promoted: {item['hours_since_promotion']:.1f}h ago")
        
        # Promote the highest priority coin
        if prioritized_coins:
            top_coin = prioritized_coins[0]['coin']
            logger.info(f"Promoting coin {top_coin['symbol']} with priority score {prioritized_coins[0]['priority_score']:.1f}")
            
            tweet_id = self.post_promotion_tweet(top_coin)
            
            if tweet_id:
                # Update daily count
                self.last_promotion_times[daily_count_key] = daily_count + 1
                self._save_state()
                
                logger.info(f"Successfully promoted {top_coin['symbol']} (daily: {daily_count + 1}/{self.daily_promotion_limit})")
                return tweet_id
        else:
            logger.info("No coins available for promotion at this time")
            return None
    
    def promote_all_coins(self, force=False, delay_between=7200):
        """Promote all available coins with a longer delay between each promotion for Twitter rate limits"""
        # First check for Twitter rate limiting
        rate_limit_file = 'twitter_rate_limit.json'
        if os.path.exists(rate_limit_file):
            try:
                with open(rate_limit_file, 'r') as f:
                    rate_limit_info = json.load(f)
                    
                if rate_limit_info.get('rate_limited', False):
                    reset_time_str = rate_limit_info.get('reset_time')
                    if reset_time_str:
                        try:
                            reset_time = datetime.fromisoformat(reset_time_str)
                            now = datetime.now()
                            
                            if now < reset_time:
                                wait_time = (reset_time - now).total_seconds()
                                logger.warning(f"Twitter API rate limited. Cannot promote coins until {reset_time_str} ({int(wait_time/60)} minutes from now)")
                                return
                        except Exception as e:
                            logger.error(f"Could not parse reset time: {reset_time_str}, error: {e}")
            except Exception as e:
                logger.error(f"Error reading rate limit file: {e}")
        
        # Get coins that can be promoted
        coins = self.get_mintable_coins()
        if not coins:
            logger.warning("No mintable coins found to promote")
            return
        
        # Respect Twitter's daily tweet limit
        # Only promote up to 2 coins in a single run to avoid hitting rate limits
        max_coins_to_promote = 2
        
        # Sort coins by last promotion time - promote least recently promoted first
        sorted_coins = []
        for coin in coins:
            coin_id = str(coin['id'])
            last_promotion = self.last_promotion_times.get(coin_id, 0)
            hours_since_promotion = (time.time() - last_promotion) / 3600
            sorted_coins.append((coin, hours_since_promotion))
        
        # Sort by time since last promotion (descending) - promote coins that haven't been
        # promoted in the longest time first
        sorted_coins.sort(key=lambda x: x[1], reverse=True)
        
        # Only consider coins that haven't been promoted in the last 24 hours (unless force=True)
        promotable_coins = []
        for coin, hours_since_promotion in sorted_coins:
            if force or hours_since_promotion >= 24:
                promotable_coins.append(coin)
            else:
                logger.info(f"Skipping {coin['symbol']} - promoted {hours_since_promotion:.1f}h ago")
        
        # Limit the number of coins to promote in this batch
        coins_to_promote = promotable_coins[:max_coins_to_promote]
        
        logger.info(f"Promoting {len(coins_to_promote)} coins out of {len(promotable_coins)} eligible")
        
        # Promote each coin with a longer 2-hour delay between to respect Twitter rate limits
        promoted_count = 0
        for i, coin in enumerate(coins_to_promote):
            logger.info(f"Promoting coin {i+1}/{len(coins_to_promote)}: {coin['symbol']}")
            
            # Post promotion tweet
            tweet_id = self.post_promotion_tweet(coin)
            
            if tweet_id:
                promoted_count += 1
                logger.info(f"Successfully promoted {coin['symbol']}")
                
                # Add a longer delay before the next promotion to avoid rate limits
                if i < len(coins_to_promote) - 1:
                    logger.info(f"Waiting {delay_between//60} minutes before next promotion...")
                    time.sleep(delay_between)
            else:
                logger.warning(f"Failed to promote {coin['symbol']}")
                # If we failed to post, we might have hit rate limits, so stop promoting
                break
                
        logger.info(f"Completed promotion batch: {promoted_count} coins promoted")
    
    def schedule_promotions(self):
        """Schedule regular coin promotions"""
        # Schedule one coin promotion every 8 hours
        schedule.every(8).hours.do(self.promote_next_coin)
        
        # Schedule a full promotion check once a week to catch any missed coins
        schedule.every().monday.at("10:00").do(self.check_missed_promotions)
        
        logger.info("Scheduled regular coin promotions (every 8 hours)")
        logger.info("Scheduled weekly missed promotion check (Mondays at 10:00)")
    
    def check_missed_promotions(self):
        """Check for coins that haven't been promoted in a long time"""
        coins = self.get_mintable_coins()
        current_time = time.time()
        promotion_threshold = 7 * 24 * 3600  # 7 days in seconds
        
        missed_coins = []
        
        for coin in coins:
            coin_id = str(coin['id'])
            last_promotion = self.last_promotion_times.get(coin_id, 0)
            
            # If never promoted or not promoted in a long time
            if last_promotion == 0 or (current_time - last_promotion) > promotion_threshold:
                missed_coins.append(coin)
        
        logger.info(f"Found {len(missed_coins)} coins that haven't been promoted in over 7 days")
        
        # Schedule these coins for promotion over the next few days
        for idx, coin in enumerate(missed_coins):
            # Spread promotions over next few days to avoid hitting daily limits
            hours_delay = idx * 8  # 8 hours between each
            
            # Log scheduled promotion
            promotion_time = datetime.now() + timedelta(hours=hours_delay)
            logger.info(f"Scheduling missed promotion for {coin['symbol']} at {promotion_time.strftime('%Y-%m-%d %H:%M')}")

def run_promoter():
    """Run the coin promoter"""
    try:
        promoter = CoinPromoter()
        logger.info("Starting coin promotion scheduler...")
        
        # Schedule regular promotions
        promoter.schedule_promotions()
        
        # Initial promotion of a coin
        logger.info("Promoting initial coin...")
        promoter.promote_next_coin()
        
        # Run the scheduler in a loop
        while True:
            schedule.run_pending()
            time.sleep(60)  # Check every minute
    except Exception as e:
        logger.error(f"Error in coin promoter: {str(e)}")

if __name__ == "__main__":
    run_promoter()