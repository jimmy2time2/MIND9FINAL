#!/bin/bash

# Script to keep Mind9 services running
# This script will continuously check if services are running and restart them if needed

# Create logs directory
mkdir -p logs

# Set status files
echo "$(date)" > .services_running

# Start Twitter bot if not already running
if ! pgrep -f "python.*twitter_bot.py" > /dev/null; then
    echo "Starting Twitter bot..."
    ./start_twitter_bot.sh
fi

# Start Coin Promoter runner if not already running
if ! pgrep -f "python.*run_coin_promoter.py" > /dev/null; then
    echo "Starting Coin Promoter runner..."
    nohup python -u run_coin_promoter.py > logs/coin_promoter_runner.log 2>&1 &
    echo "Started Coin Promoter runner with PID: $!"
fi

# Start Mind9 Core System runner if not already running
if ! pgrep -f "python.*run_mind9.py" > /dev/null; then
    echo "Starting Mind9 Core System runner..."
    nohup python -u run_mind9.py > logs/mind9_runner.log 2>&1 &
    echo "Started Mind9 Core System runner with PID: $!"
fi

# Continuous monitoring loop
while true; do
    echo "[$(date)] Checking Mind9 services..."
    
    # Check and restart Coin Promoter runner
    if ! pgrep -f "python.*run_coin_promoter.py" > /dev/null; then
        echo "[$(date)] Coin Promoter runner not running, starting..."
        nohup python -u run_coin_promoter.py > logs/coin_promoter_runner.log 2>&1 &
        echo "Started Coin Promoter runner with PID: $!"
    fi
    
    # Check and restart Mind9 Core System runner
    if ! pgrep -f "python.*run_mind9.py" > /dev/null; then
        echo "[$(date)] Mind9 Core System runner not running, starting..."
        nohup python -u run_mind9.py > logs/mind9_runner.log 2>&1 &
        echo "Started Mind9 Core System runner with PID: $!"
    fi
    
    # Check Twitter Bot (has self-healing, but double-check)
    if ! pgrep -f "python.*twitter_bot.py" > /dev/null; then
        echo "[$(date)] Twitter Bot not running, starting..."
        ./start_twitter_bot.sh
    fi
    
    # Update timestamp
    echo "$(date)" > .services_running
    
    # Sleep for 60 seconds before checking again
    sleep 60
done