#!/bin/bash

# Script to deploy fixes to the Mind9 VM environment
# This is a simpler version of deploy_vm.sh that focuses on just the critical fixes

# Make the script executable
chmod +x start_vm.sh
chmod +x deploy_vm.sh
chmod +x health_monitor.sh

# Run the fix script to display existing tokens
echo "Running fix to display existing minted tokens..."
node fix_display_coins.js

# Run PM2 to make sure services keep running
echo "Setting up services with PM2..."
if command -v pm2 &> /dev/null; then
  # PM2 is installed, use it
  pm2 start ecosystem.config.js
else
  # Install PM2 first
  echo "Installing PM2..."
  npm install -g pm2
  pm2 start ecosystem.config.js
fi

# Save PM2 configuration
pm2 save

echo "Fix deployment complete! Your website should now display all minted tokens."
echo "The website will continue running even when you close the Replit terminal."