# Mind9 Deployment Settings Guide

## Recommended Deployment Configuration

For Mind9 to run properly 24/7, you should deploy it as a **Reserved VM** rather than an Autoscale deployment.

### Reserved VM vs Autoscale

- **Reserved VM**: Runs continuously 24/7, ideal for autonomous systems like Mind9 that need to run background processes
- **Autoscale**: Spins up only when receiving web requests, goes dormant when inactive (not suitable for autonomous systems)

### Current Issues

Your current deployment is set as an Autoscale deployment, which explains why your services aren't running continuously. Autoscale deployments only run when they receive HTTP requests and shut down after a period of inactivity.

### How to Switch to Reserved VM

1. Run the provided configuration script: `./replit_reserved_vm.sh`
2. When prompted, type 'y' to proceed
3. Follow the on-screen instructions to complete the setup in the Replit Deployments UI

### Important Environment Variables

These environment variables should be set in your deployment:

- `CREATOR_WALLET_ADDRESS`: Your Solana wallet address
- `OPENAI_API_KEY`: For AI generation
- `RPC_ENDPOINT`: Solana RPC endpoint
- `SOLANA_PRIVATE_KEY`: For blockchain transactions
- `TWITTER_*`: Twitter API credentials
- `SESSION_SECRET`: For Express session security
- `DATABASE_URL`: PostgreSQL connection string

### Port Configuration

- Internal port: 5000
- External port: 80

### File Structure

- `persistent_mind9.sh`: Main script for running all services in a Reserved VM
- `health_monitor_replit.sh`: Monitors and restarts services if they fail