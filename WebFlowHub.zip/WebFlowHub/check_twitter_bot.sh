#!/bin/bash

# Script to check if the Twitter bot is running

echo "==========================================="
echo "     Mind9 Twitter Bot Status"
echo "==========================================="

# Check if the Twitter bot is running with PM2
PM2_STATUS=$(pm2 list | grep mind9-twitter)

if [[ ! -z "$PM2_STATUS" ]]; then
    echo "Twitter bot status with PM2:"
    pm2 show mind9-twitter
    echo ""
fi

# Also check for running processes directly
echo "Running Twitter bot processes:"
ps aux | grep -E "twitter_bot\.py|run_twitter_bot\.py" | grep -v grep

echo ""
echo "Twitter API log (last 5 lines):"
tail -n 5 twitter_api.log
echo ""

echo "Twitter bot output log (last 10 lines):"
tail -n 10 twitter_bot_output.log
echo ""

echo "==========================================="
echo "To check more detailed logs, run:"
echo "  tail -f twitter_bot_output.log"
echo "  tail -f twitter_api.log"
echo "==========================================="