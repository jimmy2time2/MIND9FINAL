"""
Coin checker for the Mind9 Twitter bot.
Monitors the database for new coin creations and triggers tweets.
"""

import os
import json
import logging
import psycopg2
from psycopg2.extras import RealDictCursor
from datetime import datetime
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("coin_checker.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("mind9_coin_checker")

# Load environment variables
load_dotenv()

# File to store coins we've already tracked/announced
TRACKED_COINS_FILE = "tracked_coins.json"

class CoinChecker:
    def __init__(self, db_path=None):
        """Initialize coin checker"""
        self.db_url = os.getenv('DATABASE_URL')
        self.connection = None
        
        # Initialize tracked coins as a list, not a loaded value yet
        self.tracked_coins = []
        
        # Connect to the database first, then load tracked coins
        self.connect_to_db()
        
        # Now load tracked coins after connection is established
        self.tracked_coins = self.load_tracked_coins()
        
    def load_tracked_coins(self):
        """Load coins we've already tracked/announced"""
        try:
            if os.path.exists(TRACKED_COINS_FILE):
                with open(TRACKED_COINS_FILE, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            logger.error(f"Error loading tracked coins: {e}")
            return []
            
    def save_tracked_coins(self):
        """Save tracked coins to avoid re-announcing"""
        try:
            with open(TRACKED_COINS_FILE, 'w') as f:
                json.dump(self.tracked_coins, f)
        except Exception as e:
            logger.error(f"Error saving tracked coins: {e}")
            
    def connect_to_db(self):
        """Connect to the database"""
        try:
            if self.db_url:
                self.connection = psycopg2.connect(self.db_url)
                logger.info("Connected to PostgreSQL database")
                
                # Check if we need to create a coins table for testing
                cursor = self.connection.cursor()
                cursor.execute("SELECT to_regclass('public.coins')")
                if cursor.fetchone()[0] is None:
                    logger.info("Coins table doesn't exist, creating for testing")
                    self.create_local_table()
            else:
                logger.error("DATABASE_URL environment variable not set")
        except Exception as e:
            logger.error(f"Error connecting to database: {e}")
            
    def create_local_table(self):
        """Create a local table for testing if it doesn't exist"""
        try:
            if self.connection:
                cursor = self.connection.cursor()
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS coins (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        symbol VARCHAR(20) NOT NULL,
                        mint_address VARCHAR(255) NOT NULL,
                        description TEXT,
                        total_supply VARCHAR(50) DEFAULT '1000000',
                        tokenomics JSONB,
                        liquidity_amount VARCHAR(50),
                        liquidity_sol VARCHAR(50),
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        lucky_trader_wallet VARCHAR(255),
                        minted BOOLEAN DEFAULT FALSE,
                        user_mintable BOOLEAN DEFAULT FALSE
                    )
                """)
                self.connection.commit()
                logger.info("Created coins table for testing")
        except Exception as e:
            logger.error(f"Error creating local table: {e}")
            
    def get_latest_coins(self, limit=5):
        """Get the latest coins from the database"""
        try:
            if not self.connection:
                logger.error("No database connection")
                return []
                
            cursor = self.connection.cursor(cursor_factory=RealDictCursor)
            
            # Query to get latest coins with minted status
            cursor.execute("""
                SELECT * FROM coins 
                ORDER BY timestamp DESC
                LIMIT %s
            """, (limit,))
            
            coins = cursor.fetchall()
            # Handle different return types safely
            result = []
            for coin in coins:
                if isinstance(coin, dict):
                    result.append(coin)
                else:
                    result.append(dict(coin))
            return result
        except Exception as e:
            logger.error(f"Error getting latest coins: {e}")
            return []
            
    def check_for_new_coins(self):
        """Check for new coins and return any that are minted and ready for users"""
        try:
            if not self.connection:
                # Attempt to reconnect if connection was lost
                try:
                    self.connect_to_db()
                    if not self.connection:
                        logger.error("Failed to reconnect to database")
                        return []
                except Exception as reconnect_error:
                    logger.error(f"Database reconnection failed: {reconnect_error}")
                    return []
                
            cursor = self.connection.cursor(cursor_factory=RealDictCursor)
            
            # Ensure tracked_coins is always a list of integers
            if not isinstance(self.tracked_coins, list):
                logger.warning(f"tracked_coins is not a list type, resetting: {type(self.tracked_coins)}")
                self.tracked_coins = []
                self.save_tracked_coins()
            
            # Filter out any non-integer values that might have been saved
            valid_tracked_coins = []
            for coin_id in self.tracked_coins:
                try:
                    valid_tracked_coins.append(int(coin_id))
                except (ValueError, TypeError):
                    logger.warning(f"Invalid coin ID in tracked_coins: {coin_id}")
            
            self.tracked_coins = valid_tracked_coins
            
            # Use proper parameterized queries to avoid SQL injection and syntax errors
            if self.tracked_coins and len(self.tracked_coins) > 0:
                # For multiple IDs, use the IN clause properly
                placeholders = ','.join(['%s'] * len(self.tracked_coins))
                query = f"""
                    SELECT id, name, symbol, mint_address, description, 
                           tokenomics, timestamp, minted, user_mintable, 
                           image_path, lucky_trader_wallet
                    FROM coins 
                    WHERE id NOT IN ({placeholders}) AND minted = TRUE AND user_mintable = TRUE
                    ORDER BY timestamp DESC
                """
                cursor.execute(query, self.tracked_coins)
            else:
                # No tracked coins, simply get all mintable coins
                query = """
                    SELECT id, name, symbol, mint_address, description, 
                           tokenomics, timestamp, minted, user_mintable, 
                           image_path, lucky_trader_wallet
                    FROM coins 
                    WHERE minted = TRUE AND user_mintable = TRUE
                    ORDER BY timestamp DESC
                """
                cursor.execute(query)
            
            # Fetch the results and handle both psycopg2 result types safely
            raw_coins = cursor.fetchall()
            
            # Convert to list of dicts - handle both dict and RealDictRow results
            new_coins = []
            if raw_coins:
                for coin in raw_coins:
                    # Create a standard Python dict from whatever type we received
                    if hasattr(coin, 'keys') and callable(getattr(coin, 'keys')):
                        # It's a dict-like object with keys() method
                        coin_dict = {key: coin[key] for key in coin.keys()}
                    elif isinstance(coin, dict):
                        # It's already a dict
                        coin_dict = coin
                    else:
                        # Unknown type, skip it
                        logger.warning(f"Skipping coin of unexpected type: {type(coin)}")
                        continue
                    
                    # Validate the coin has an ID before adding to tracked coins
                    if 'id' in coin_dict and coin_dict['id'] is not None:
                        new_coins.append(coin_dict)
                        
                        # Add this coin to our tracked list if not already there
                        coin_id = int(coin_dict['id'])
                        if coin_id not in self.tracked_coins:
                            self.tracked_coins.append(coin_id)
                    else:
                        logger.warning(f"Skipping coin with missing ID: {coin_dict}")
            
            # ENHANCEMENT: Check for Node.js created tokens that might not be in our database
            try:
                # Check if tokens table exists
                cursor.execute("SELECT to_regclass('public.tokens')")
                tokens_table_exists = cursor.fetchone()[0] is not None
                
                if tokens_table_exists:
                    logger.info("Found Node.js tokens table, checking for new tokens...")
                    # Get tracked mint addresses to avoid duplicates
                    tracked_mint_addresses = []
                    for coin in new_coins:
                        if 'mint_address' in coin and coin['mint_address']:
                            tracked_mint_addresses.append(coin['mint_address'])
                    
                    # Get the latest tokens created by Node.js system
                    cursor.execute("""
                        SELECT *, created_at as timestamp
                        FROM tokens 
                        ORDER BY created_at DESC
                        LIMIT 10
                    """)
                    
                    nodejs_tokens = cursor.fetchall()
                    nodejs_token_count = 0
                    
                    if nodejs_tokens:
                        for token in nodejs_tokens:
                            # Convert to dict if needed
                            if hasattr(token, 'keys') and callable(getattr(token, 'keys')):
                                token_dict = {key: token[key] for key in token.keys()}
                            elif isinstance(token, dict):
                                token_dict = token
                            else:
                                continue
                            
                            # Skip if we already have this mint address
                            if 'mint_address' not in token_dict or not token_dict['mint_address']:
                                continue
                                
                            if token_dict['mint_address'] in tracked_mint_addresses:
                                logger.debug(f"Skipping already tracked token: {token_dict['mint_address']}")
                                continue
                            
                            # Check if this token exists in our coins table 
                            check_query = "SELECT id FROM coins WHERE mint_address = %s"
                            cursor.execute(check_query, (token_dict['mint_address'],))
                            existing = cursor.fetchone()
                            
                            if not existing:
                                # This is a new token from Node.js, add it to our coins table
                                logger.info(f"Adding Node.js created token to coins table: {token_dict['name']} ({token_dict['mint_address']})")
                                
                                # Default tokenomics matching Mind9 requirements
                                tokenomics = json.dumps({
                                    "liquidityPool": 70,
                                    "tradingFund": 20,
                                    "creator": 5,
                                    "luckyTrader": 3, 
                                    "systemOperations": 2
                                })
                                
                                # Insert into coins table
                                insert_query = """
                                    INSERT INTO coins 
                                    (name, symbol, mint_address, description, tokenomics, 
                                     timestamp, minted, user_mintable)
                                    VALUES (%s, %s, %s, %s, %s, %s, TRUE, TRUE)
                                    RETURNING *
                                """
                                
                                desc = token_dict.get('description', f"Mind9 autonomous token: {token_dict['name']}")
                                timestamp = token_dict.get('timestamp', datetime.now())
                                
                                cursor.execute(insert_query, (
                                    token_dict['name'],
                                    token_dict['symbol'],
                                    token_dict['mint_address'],
                                    desc,
                                    tokenomics,
                                    timestamp
                                ))
                                
                                self.connection.commit()
                                
                                # Get the newly created coin and add to new_coins
                                new_coin = cursor.fetchone()
                                if new_coin:
                                    if hasattr(new_coin, 'keys') and callable(getattr(new_coin, 'keys')):
                                        new_coin_dict = {key: new_coin[key] for key in new_coin.keys()}
                                    elif isinstance(new_coin, dict):
                                        new_coin_dict = new_coin
                                    else:
                                        continue
                                        
                                    # Add to results
                                    new_coins.append(new_coin_dict)
                                    
                                    # Add to tracked coins
                                    if 'id' in new_coin_dict and new_coin_dict['id'] is not None:
                                        self.tracked_coins.append(int(new_coin_dict['id']))
                                    
                                    nodejs_token_count += 1
                    
                    if nodejs_token_count > 0:
                        logger.info(f"Added {nodejs_token_count} new tokens from Node.js system")
            except Exception as nodejs_error:
                logger.error(f"Error checking for Node.js tokens: {nodejs_error}")
                # This is non-critical, so we continue
            
            # Save the updated tracked coins
            self.save_tracked_coins()
            
            # Close cursor
            cursor.close()
            
            if new_coins:
                logger.info(f"Found {len(new_coins)} new coins to announce")
                return new_coins
            else:
                logger.info("No new coins to announce")
                return []
        except Exception as e:
            logger.error(f"Error checking for new coins: {e}")
            import traceback
            logger.error(traceback.format_exc())
            
            # Try to reconnect for next attempt if there was a connection issue
            if "connection" in str(e).lower() or "closed" in str(e).lower():
                logger.info("Connection issue detected, will attempt to reconnect on next check")
                self.connection = None
            return []
    
    def is_coin_minted(self, coin):
        """Check if a coin is actually minted on Solana"""
        # In production, this should make a real Solana RPC call to verify the mint
        try:
            # For now, trust the database minted flag
            return coin.get('minted', False)
        except Exception as e:
            logger.error(f"Error checking if coin is minted: {e}")
            return False
    
    def is_coin_user_mintable(self, coin):
        """Check if users can mint this coin"""
        try:
            # Check the database flag
            return coin.get('user_mintable', False)
        except Exception as e:
            logger.error(f"Error checking if coin is user mintable: {e}")
            return False
    
    def add_test_coin(self, name, symbol, description="A test coin", minted=True, user_mintable=True):
        """Add a test coin to the database for testing"""
        try:
            if not self.connection:
                logger.error("No database connection")
                return None
                
            cursor = self.connection.cursor(cursor_factory=RealDictCursor)
            
            # Generate a fake mint address for testing
            test_mint_address = f"TEST{datetime.now().timestamp()}"
            
            # Default tokenomics matching Mind9 requirements
            tokenomics = json.dumps({
                "liquidityPool": 70,
                "tradingFund": 20,
                "creator": 5,
                "luckyTrader": 3, 
                "systemOperations": 2
            })
            
            cursor.execute("""
                INSERT INTO coins 
                (name, symbol, mint_address, description, tokenomics, 
                 timestamp, minted, user_mintable, lucky_trader_wallet)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
            """, (
                name, symbol, test_mint_address, description, tokenomics,
                datetime.now(), minted, user_mintable, "TEST_WALLET"
            ))
            
            self.connection.commit()
            coin = cursor.fetchone()
            if coin is None:
                return None
                
            # Handle different cursor return types
            if isinstance(coin, dict):
                return coin
            else:
                return dict(coin)
        except Exception as e:
            logger.error(f"Error adding test coin: {e}")
            if self.connection:
                self.connection.rollback()
            return None
            
# For testing
if __name__ == "__main__":
    checker = CoinChecker()
    
    # Test adding a coin
    # test_coin = checker.add_test_coin("TestCoin", "TEST", "A test coin for Mind9")
    # if test_coin:
    #     print(f"Added test coin: {test_coin['name']} ({test_coin['symbol']})")
    
    # Check for new coins
    new_coins = checker.check_for_new_coins()
    if new_coins:
        print(f"Found {len(new_coins)} new coins:")
        for coin in new_coins:
            print(f"- {coin['name']} ({coin['symbol']})")
            print(f"  Mint Address: {coin['mint_address']}")
            print(f"  Minted: {coin['minted']}")
            print(f"  User Mintable: {coin['user_mintable']}")
    else:
        print("No new coins found")