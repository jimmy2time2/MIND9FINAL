#!/bin/bash

echo "========================================"
echo "    Mind9 VM Deployment Script"
echo "========================================"
echo ""

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Step 1: Installing required dependencies...${NC}"
echo ""

# Check for npm and install if needed
if ! command -v npm &> /dev/null; then
    echo "Installing Node.js and npm..."
    curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
    sudo apt-get install -y nodejs
else
    echo -e "${GREEN}✓ npm already installed${NC}"
fi

# Check for PM2 and install if needed
if ! command -v pm2 &> /dev/null; then
    echo "Installing PM2 for process management..."
    sudo npm install -g pm2
else
    echo -e "${GREEN}✓ PM2 already installed${NC}"
fi

# Make sure Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Installing Python..."
    sudo apt-get update
    sudo apt-get install -y python3 python3-pip
else
    echo -e "${GREEN}✓ Python already installed${NC}"
fi

echo ""
echo -e "${YELLOW}Step 2: Setting up permissions...${NC}"
echo ""

# Make scripts executable
chmod +x start_vm.sh
chmod +x start_mind9.sh
chmod +x start_twitter_bot.sh
chmod +x stop_twitter_bot.sh

echo -e "${GREEN}✓ Scripts are now executable${NC}"

echo ""
echo -e "${YELLOW}Step 3: Setting up systemd service...${NC}"
echo ""

# Copy the service file to the systemd directory
if [ -f "mind9.service" ]; then
    sudo cp mind9.service /etc/systemd/system/
    sudo systemctl daemon-reload
    sudo systemctl enable mind9.service
    echo -e "${GREEN}✓ Systemd service installed and enabled${NC}"
else
    echo -e "${RED}× mind9.service file not found${NC}"
fi

echo ""
echo -e "${YELLOW}Step 4: Starting Mind9 services...${NC}"
echo ""

# Stop any running instances first
pm2 delete all &> /dev/null

# Start with PM2
echo "Starting all Mind9 services with PM2..."
pm2 start ecosystem.config.js
pm2 save
pm2 startup

echo ""
echo -e "${GREEN}✓ Mind9 services have been started successfully!${NC}"

# Display information
echo ""
echo -e "${YELLOW}========================================"
echo "    Mind9 Deployment Information"
echo "========================================"
echo ""
echo "Website should be accessible at: http://<your-vm-ip>:5000"
echo ""
echo "To view logs:"
echo "  - PM2 logs: pm2 logs"
echo "  - Main app: pm2 logs mind9-web"
echo "  - Twitter bot: pm2 logs mind9-twitter"
echo ""
echo "Services will automatically restart if they crash"
echo "and will start on system boot.${NC}"
echo ""
echo -e "${GREEN}Deployment completed successfully!${NC}"