#!/usr/bin/env python3
"""
Mind9 24/7 Deployment Helper
This script implements all the necessary changes for 24/7 operation on a Reserved VM
"""

import os
import sys
import subprocess
import json

print("======================================================")
print("  Mind9 24/7 Deployment Helper")
print("======================================================\n")

# Step 1: Create .replit file
try:
    print("Step 1: Creating .replit file...")
    replit_content = """run = "node dist/index.js"

[deployment]
deploymentTarget = "reservedvm"
build = ["sh", "-c", "npm ci && npm run build"]
run   = ["sh", "-c", "./start_persistent.sh"]

[[ports]]
localPort     = 5000
externalPort  = 80
name          = "Mind9-App"
protocol      = "http"
"""
    
    try:
        with open(".replit", "w") as f:
            f.write(replit_content)
        print("✓ .replit file created")
    except Exception as e:
        print(f"Error writing .replit file: {str(e)}")
        print("You will need to create this file manually using the content from DEPLOYMENT_INSTRUCTIONS.md")
        
except Exception as e:
    print(f"Error in Step 1: {str(e)}")

# Step 2: Create replit.nix file
try:
    print("\nStep 2: Creating replit.nix file...")
    nix_content = """{ pkgs }: {
  deps = [
    pkgs.nodejs-20
    pkgs.libpng pkgs.cairo pkgs.pango pkgs.librsvg
    pkgs.pkg-config
  ];
}
"""
    
    try:
        with open("replit.nix", "w") as f:
            f.write(nix_content)
        print("✓ replit.nix file created")
    except Exception as e:
        print(f"Error writing replit.nix file: {str(e)}")
        print("You will need to create this file manually using the content from DEPLOYMENT_INSTRUCTIONS.md")
        
except Exception as e:
    print(f"Error in Step 2: {str(e)}")

# Step 3: Create start_persistent.sh
try:
    print("\nStep 3: Creating start_persistent.sh...")
    script_content = """#!/usr/bin/env bash
# Keep background workers + web server alive
npx pm2-runtime dist/index.js
"""
    
    try:
        with open("start_persistent.sh", "w") as f:
            f.write(script_content)
            
        try:
            subprocess.run(["chmod", "+x", "start_persistent.sh"], check=True)
            print("✓ start_persistent.sh created and made executable")
        except Exception as e:
            print(f"Error making start_persistent.sh executable: {str(e)}")
            print("Please run: chmod +x start_persistent.sh")
            
    except Exception as e:
        print(f"Error writing start_persistent.sh: {str(e)}")
        
except Exception as e:
    print(f"Error in Step 3: {str(e)}")

# Step 4: Canvas dependency information
print("\nStep 4: Canvas dependency...")
print("You need to update your Canvas dependency by running:")
print("  npm uninstall canvas")
print("  npm install --save npm:@napi-rs/canvas@^0.1.37 --force")

# Step 5: Check package.json build script
try:
    print("\nStep 5: Checking package.json build script...")
    
    try:
        with open("package.json", "r") as f:
            try:
                package_data = json.load(f)
                
                has_correct_scripts = True
                if not package_data.get("scripts") or not package_data.get("scripts", {}).get("build"):
                    print("⚠️ Missing build script in package.json")
                    has_correct_scripts = False
                
                if not package_data.get("scripts") or not package_data.get("scripts", {}).get("start"):
                    print("⚠️ Missing start script in package.json")
                    has_correct_scripts = False
                
                if has_correct_scripts:
                    print("✓ package.json scripts look good")
                else:
                    print("Make sure package.json has these scripts:")
                    print('  "build": "vite build",')
                    print('  "start": "node dist/index.js"')
                    
            except json.JSONDecodeError:
                print("Error: package.json is not valid JSON")
    except Exception as e:
        print(f"Error reading package.json: {str(e)}")
        
except Exception as e:
    print(f"Error in Step 5: {str(e)}")

# Step 6: Environment secrets
print("\nStep 6: Environment variables check...")
print("Make sure you have these secrets set in Replit Secrets:")
print("  OPENAI_API_KEY")
print("  SOLANA_PRIVATEKEY")
print("  TWITTER_BEARER")

# Final instructions
print("\n======================================================")
print("  Next Steps:")
print("======================================================")
print("1. Run the Canvas dependency update commands")
print("2. Add the required secrets in Replit Secrets")
print("3. Commit your changes:")
print("   git add -A")
print('   git commit -m "♻️ One-file manifest, Reserved VM, nix libs, prebuilt canvas"')
print("4. Deploy to a Reserved VM using the Replit deployment interface")
print("   (Select 0.5 GB tier or higher)")
print("5. Verify your deployment with:")
print("   curl -I https://<your-project>.replit.app")
print("======================================================\n")