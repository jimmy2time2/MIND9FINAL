# Mind9 Replit Persistence Guide

## Overview

This guide explains how to ensure Mind9's services run 24/7 on Replit without interruption. We've implemented multiple layers of persistence to ensure the system runs autonomously.

## Key Components

1. **Twitter Bot**: Automatically posts tweets about market conditions and announces new tokens
2. **Coin Promoter**: Regularly promotes all available coins with minting links
3. **Mind9 Core**: The autonomous system that analyzes markets and creates tokens
4. **Watchdog Monitor**: Restarts any services that stop running

## Important Scripts

- `workflow_startup.sh`: Main startup script for Replit workflow
- `deploy_replit_services.sh`: Complete setup script for Replit environment
- `start_twitter_bot.sh`: Starts the Twitter bot as a background process
- `health_monitor_replit.sh`: Continuously monitors and restarts any stopped services

## How Persistence Works

Mind9 achieves persistence through multiple mechanisms:

1. **Workflow Persistence**: The `.replit.autobots` configuration automatically starts services when Replit boots
2. **Process Monitoring**: The watchdog process continuously checks all services and restarts them if they crash
3. **Status Files**: `.mind9_running`, `.twitter_bot_running`, etc. track the status of each service
4. **Background Processes**: All services run as detached processes (using `nohup`) to continue after terminal sessions end

## Ensuring 24/7 Operation

To ensure Mind9 runs 24/7 on Replit:

1. **Enable "Always On"**:
   - Go to the Tools tab in the Replit sidebar
   - Turn on the "Always on" toggle
   - This keeps your Repl running even when you close your browser

2. **Verify Services**:
   - Run `ps aux | grep -E "twitter|coin|main.py"` to check running services
   - Look for multiple processes running each service
   - The Twitter bot should have at least one process running

3. **Check Logs**:
   - All logs are stored in the `logs/` directory
   - `twitter_bot.log`: Twitter bot logs
   - `coin_promoter.log`: Coin promoter logs
   - `mind9.log`: Mind9 core system logs
   - `watchdog.log`: Service monitoring logs

## Rate Limits and Expected Behavior

- **Twitter Rate Limits**: The Twitter bot respects API rate limits and will pause when limits are reached
- You'll occasionally see "429 Too Many Requests" errors in the logs - this is normal behavior
- The system will automatically wait and retry when rate limits reset
- The tweet schedule has been optimized to prevent exceeding limits

## Troubleshooting

If services stop running:

1. Run `./deploy_replit_services.sh` to redeploy all services
2. Check logs in `logs/` directory for specific errors
3. Verify Twitter API credentials are set correctly in `.env`
4. Ensure PostgreSQL database is running and accessible

## Redeploying All Services

To completely redeploy all Mind9 services:

```bash
# Stop any existing services
./stop_twitter_bot.sh

# Deploy all services with Replit-specific settings
./deploy_replit_services.sh
```

## Testing Twitter Integration

To test the Twitter bot without waiting for scheduled posts:

```bash
# Force immediate coin promotion tweets
python -c 'from coin_promoter import CoinPromoter; CoinPromoter().promote_all_coins(True)'
```